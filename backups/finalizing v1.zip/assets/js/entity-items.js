// FrozoFun Admin - Entity: Items JS  
// Handles dynamic UI for items list, AJAX CRUD, image preview, etc.
// Uses UnifiedModals for modal handling

document.addEventListener("DOMContentLoaded", function () {
    // Example: Load items list via AJAX
    if (document.getElementById('items-list')) {
        fetchItemsList();
    }

    // Image preview for item form (entity-specific functionality)
    const itemImageInput = document.querySelector('input[name="item_image"]');
    if (itemImageInput) {
        itemImageInput.addEventListener('change', function () {
            const [file] = itemImageInput.files;
            if (file) {
                const imgPreview = document.getElementById('item-image-preview');
                if (imgPreview) {
                    imgPreview.src = URL.createObjectURL(file);
                    imgPreview.style.display = 'block';
                }
            }
        });
    }
});

function fetchItemsList() {
    fetch('/api/items.php?action=list')
        .then(r => r.json())
        .then(data => {
            const listDiv = document.getElementById('items-list');
            if (!data.items || !Array.isArray(data.items)) {
                listDiv.innerHTML = "<p>No items found.</p>";
                return;
            }
            let html = '<table><thead><tr><th>Code</th><th>Name</th><th>Price</th><th>Pack Size</th><th>Category</th><th>Actions</th></tr></thead><tbody>';
            data.items.forEach(item => {
                html += `<tr>
                    <td>${item.code}</td>
                    <td>${item.name}</td>
                    <td>${item.price_per_unit ?? ''}</td>
                    <td>${item.default_pack_size ?? ''}</td>
                    <td>${item.category_name ?? ''}</td>
                    <td>
                        <a href="details.php?id=${item.id}">Details</a> |
                        <a href="form.php?id=${item.id}">Edit</a> |
                        <a href="#" onclick="deleteItem(${item.id});return false;">Delete</a>
                    </td>
                </tr>`;
            });
            html += '</tbody></table>';
            listDiv.innerHTML = html;
        });
}

function deleteItem(id) {
    showConfirm("Delete this item?", "Confirm Delete", function() {
        fetch('/api/items.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=delete&id=${id}`
        }).then(r => r.json()).then(data => {
            if (data.success) {
                showSuccess("Item deleted successfully");
                fetchItemsList();
            } else {
                showError(data.error || "Delete failed");
            }
        }).catch(error => {
            showError("Network error occurred while deleting item");
        });
    });
}