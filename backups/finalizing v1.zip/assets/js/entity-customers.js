// FrozoFun Admin - Entity: Customers JS
// Handles dynamic UI for customers list, AJAX CRUD, payment dialog, etc.
// Uses UnifiedModals for modal handling

document.addEventListener("DOMContentLoaded", function () {
    if (document.getElementById('customers-list')) {
        fetchCustomersList();
    }
});

function fetchCustomersList() {
    fetch('/api/customers.php?action=list')
        .then(r => r.json())
        .then(data => {
            const listDiv = document.getElementById('customers-list');
            if (!data.customers || !Array.isArray(data.customers)) {
                listDiv.innerHTML = "<p>No customers found.</p>";
                return;
            }
            let html = '<table><thead><tr><th>Name</th><th>Contact</th><th>Balance</th><th>City</th><th>Actions</th></tr></thead><tbody>';
            data.customers.forEach(customer => {
                html += `<tr>
                    <td>${customer.name}</td>
                    <td>${customer.contact}</td>
                    <td>${customer.balance ?? ''}</td>
                    <td>${customer.city ?? ''}</td>
                    <td>
                        <a href="details.php?id=${customer.id}">Details</a> |
                        <a href="form.php?id=${customer.id}">Edit</a> |
                        <a href="#" onclick="deleteCustomer(${customer.id});return false;">Delete</a>
                        ${customer.balance > 0 ? ' | <a href="#" onclick="openPaymentModal('+customer.id+');return false;">Payment</a>' : ''}
                    </td>
                </tr>`;
            });
            html += '</tbody></table>';
            listDiv.innerHTML = html;
        });
}

function deleteCustomer(id) {
    showConfirm("Delete this customer?", "Confirm Delete", function() {
        fetch('/api/customers.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=delete&id=${id}`
        }).then(r => r.json()).then(data => {
            if (data.success) {
                showSuccess("Customer deleted successfully");
                fetchCustomersList();
            } else {
                showError(data.error || "Delete failed");
            }
        }).catch(error => {
            showError("Network error occurred while deleting customer");
        });
    });
}

function openPaymentModal(customerId) {
    // Create and show payment modal using UnifiedModals
    const modalHtml = `
        <div class="modal fade" id="paymentModal" tabindex="-1" 
             aria-labelledby="paymentModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="paymentModalLabel">Record Payment</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Payment processing for customer ID: ${customerId}</p>
                        <p><em>FIFO allocation of orders will be implemented here.</em></p>
                        <form id="paymentForm" class="entity-form" data-refresh-on-success="true">
                            <input type="hidden" name="customer_id" value="${customerId}">
                            <div class="mb-3">
                                <label for="paymentAmount" class="form-label">Payment Amount</label>
                                <input type="number" class="form-control" id="paymentAmount" name="amount" step="0.01" required>
                            </div>
                            <div class="mb-3">
                                <label for="paymentMethod" class="form-label">Payment Method</label>
                                <select class="form-control" id="paymentMethod" name="method" required>
                                    <option value="">Select Method</option>
                                    <option value="cash">Cash</option>
                                    <option value="bank">Bank Transfer</option>
                                    <option value="card">Card</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" form="paymentForm" class="btn btn-primary">Record Payment</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove any existing payment modal
    const existingModal = document.getElementById('paymentModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Add modal to DOM
    document.body.insertAdjacentHTML('beforeend', modalHtml);
    
    // Show modal using UnifiedModals
    window.UnifiedModals.show('paymentModal');
    
    // Handle form submission (placeholder for now) 
    document.getElementById('paymentForm').addEventListener('submit', function(e) {
        e.preventDefault();
        // TODO: Implement AJAX submission with FIFO allocation
        showInfo('Payment form submitted for customer ' + customerId + ' (AJAX implementation pending)');
        window.UnifiedModals.hide('paymentModal');
    });
}