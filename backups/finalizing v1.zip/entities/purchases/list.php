<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../includes/functions.php';
$pageTitle = "Purchases";
include __DIR__ . '/../../includes/header.php';

$pdo = $pdo ?? require __DIR__ . '/../../includes/db_connection.php';

// Fetch all purchases with vendor name and payment count
$stmt = $pdo->prepare("
    SELECT p.*, v.name AS vendor_name,
        (SELECT COUNT(*) FROM purchase_payments pp WHERE pp.purchase_id = p.id AND pp.deleted_at IS NULL) AS payment_count
    FROM purchases p
    LEFT JOIN vendors v ON p.vendor_id = v.id
    WHERE p.deleted_at IS NULL
    ORDER BY p.date DESC, p.created_at DESC
");
$stmt->execute();
$purchases = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate paid/unpaid status and amount paid for each purchase
$purchase_ids = array_column($purchases, 'id');
$amount_paid = [];
if ($purchase_ids) {
    $in = implode(',', array_fill(0, count($purchase_ids), '?'));
    $payStmt = $pdo->prepare("SELECT purchase_id, SUM(amount) AS paid FROM purchase_payments WHERE purchase_id IN ($in) AND deleted_at IS NULL GROUP BY purchase_id");
    $payStmt->execute($purchase_ids);
    foreach ($payStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $amount_paid[$row['purchase_id']] = $row['paid'];
    }
}

// Fetch applied advances for visible purchases
$advances_by_purchase = [];
if ($purchase_ids) {
    $in = implode(',', array_fill(0, count($purchase_ids), '?'));
    $advStmt = $pdo->prepare("SELECT id, amount, applied_to_purchase_id FROM vendor_advances WHERE applied_to_purchase_id IN ($in)");
    $advStmt->execute($purchase_ids);
    foreach ($advStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $pid = $row['applied_to_purchase_id'];
        if (!isset($advances_by_purchase[$pid])) $advances_by_purchase[$pid] = [];
        $advances_by_purchase[$pid][] = $row;
    }
}
?>

<div class="page-content-wrapper">
    <div class="container mt-3">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2 class="text-primary"><i class="fa fa-shopping-cart me-2"></i> Purchases</h2>
            </div>
            <div class="col-md-4 text-end">
                <button class="btn btn-primary btn-3d" onclick="showPurchaseModal()">
                    <i class="fa fa-plus me-1"></i> Add Purchase
                </button>
            </div>
        </div>
<div class="alert alert-info max-width-700 mb-4">
    <strong>Manage vendor purchases and payments.</strong> Use <strong>Add Purchase</strong> to record purchases from vendors.<br>
    Track payment status and apply vendor advances. Use <strong>Trash</strong> to view deleted purchases.
</div>
<div class="mb-3 header-buttons-secondary">
    <a class="btn btn-outline-danger btn-3d" href="trash.php" title="View Trash">
        <i class="fa fa-trash me-1"></i> Trash
    </a>
</div>

<div id="purchases-list-wrap">
    <table class="entity-table table table-striped table-hover table-consistent" id="purchases-table">
        <thead class="table-light">
            <tr>
                <th>Date</th>
                <th>Vendor</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Description</th>
                <th>Advance Applied</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($purchases as $p):
            $paid = isset($amount_paid[$p['id']]) ? floatval($amount_paid[$p['id']]) : 0;
            $status = ($paid >= floatval($p['amount'])) ? 'Paid' : ($paid > 0 ? 'Partial' : 'Unpaid');
            $badgeClass = $status === 'Paid' ? 'badge-surplus' : ($status === 'Partial' ? 'badge-settled' : 'badge-outstanding');
            $adv_list = isset($advances_by_purchase[$p['id']]) ? $advances_by_purchase[$p['id']] : [];
        ?>
            <tr data-purchase-id="<?= $p['id'] ?>"
                data-purchase='<?= h(json_encode($p)) ?>'
                data-payment-count="<?= $p['payment_count'] ?>">
                <td data-label="Date"><?= h(date('Y-m-d', strtotime($p['date']))) ?></td>
                <td data-label="Vendor"><?= h($p['vendor_name']) ?></td>
                <td data-label="Type">
                  <span class="badge <?= $p['type']=='credit'?'badge-outstanding':'badge-surplus' ?>">
                    <?= ucfirst($p['type']) ?>
                  </span>
                </td>
                <td data-label="Amount"><?= format_currency($p['amount']) ?></td>
                <td data-label="Description"><?= h($p['description']) ?></td>
                <td data-label="Advance Applied">
                  <?php if ($adv_list): ?>
                    <span class="badge badge-surplus">
                        <?= implode(", ", array_map(function($a){ return format_currency($a['amount']); }, $adv_list)) ?>
                    </span>
                  <?php else: ?>
                    <span class="badge badge-settled">-</span>
                  <?php endif; ?>
                </td>
                <td data-label="Status">
                    <span class="badge <?= $badgeClass ?>">
                        <?= h($status) ?><?= $status !== 'Paid' && $paid > 0 ? " ($paid paid)" : "" ?>
                    </span>
                </td>
                <td data-label="Actions">
                    <div class="btn-group btn-group-sm action-icons" role="group">
                        <button class="btn btn-outline-primary btn-3d" title="Details" onclick="PurchaseUI.openDetails(<?= $p['id'] ?>)">
                            <i class="fa fa-eye"></i>
                        </button>
                        <button class="btn btn-outline-warning btn-3d" title="Edit" onclick="showPurchaseModal(<?= $p['id'] ?>)">
                            <i class="fa fa-edit"></i>
                        </button>
                        <form method="post" action="actions.php" class="ajax-delete-purchase d-inline">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= $p['id'] ?>">
                            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                            <button class="btn btn-outline-danger btn-3d" title="Delete" type="submit">
                                <i class="fa fa-trash"></i>
                            </button>
                        </form>
                        <?php if($status !== 'Paid'): ?>
                            <button class="btn btn-outline-success btn-3d" title="Pay" onclick="PurchaseUI.openPaymentModal(<?= $p['id'] ?>, <?= $p['amount']-$paid ?>)">
                                <i class="fa fa-money-bill-wave"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
</div>

<!-- Error Modal for Delete -->
<!-- Delete Error Modal -->
<div class="modal fade" id="delete-error-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="deleteErrorModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteErrorModalLabel">Error</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="delete-error-message" class="fs-5 text-danger"></div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" data-bs-dismiss="modal">OK</button>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap Modals for PurchaseUI (details and payments only) -->
<div class="modal fade" id="purchase-details-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="purchaseDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Content will be loaded dynamically -->
        </div>
    </div>
</div>

<div class="modal fade" id="purchase-payment-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="purchasePaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Content will be loaded dynamically -->
        </div>
    </div>
</div>


<script src="js/purchases.js"></script>
<script>
// Initialize DataTable with UnifiedTables
$(document).ready(function() {
    if ($('#purchases-table').length && window.UnifiedTables) {
        UnifiedTables.init('#purchases-table', 'purchases');
    }
});
</script>
<?php include __DIR__ . '/../../includes/footer.php'; ?>