<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../includes/db_connection.php';

// Get order id from query string
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch order details from DB (adapted to use sales_orders and order_items)
$order = null;
$order_items = [];
$customer_name = '';
if ($order_id > 0) {
    $pdo = $GLOBALS['pdo'];
    $order_stmt = $pdo->prepare("SELECT * FROM sales_orders WHERE id = ?");
    $order_stmt->execute([$order_id]);
    $order = $order_stmt->fetch(PDO::FETCH_ASSOC);

    // Fetch customer name only (for datalist display)
    if ($order && $order['customer_id']) {
        $cstmt = $pdo->prepare("SELECT name FROM customers WHERE id = ?");
        $cstmt->execute([$order['customer_id']]);
        $c = $cstmt->fetch(PDO::FETCH_ASSOC);
        if ($c) {
            $customer_name = $c['name'];
        }
    }

    $items_stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
    $items_stmt->execute([$order_id]);
    $order_items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch each item's name for display
    foreach ($order_items as &$item) {
        $istmt = $pdo->prepare("SELECT name FROM items WHERE id = ?");
        $istmt->execute([$item['item_id']]);
        $i = $istmt->fetch(PDO::FETCH_ASSOC);
        $item['item_name'] = $i ? $i['name'] : $item['item_id'];
    }
    unset($item);
}

// Get customer list for datalist
$customer_list = $GLOBALS['pdo']->query("SELECT id, name FROM customers ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
// Get item list for datalist
$item_list = $GLOBALS['pdo']->query("SELECT id, name, default_pack_size, price_per_unit, code FROM items ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>


<div class="container mt-4">
    <div class="order-heading-row justify-content-center text-center">
        <h2 class="text-center w-100 m-0">Edit Sales Order</h2>
    </div>
    <form id="order-form" autocomplete="off" data-edit="1" data-order-id="<?= $order_id ?>">
        <div class="customer-row order-summary-fields justify-content-center align-items-center">
            <div class="order-summary-row w-100 justify-content-center mb-0">
                <label for="customer-input" class="form-label min-width-140px">Customer</label>
                <input list="customer-list" id="customer-input" name="customer_name" class="form-control max-width-420px" autocomplete="off" value="<?= htmlspecialchars($customer_name) ?>" />
                <datalist id="customer-list">
                    <?php foreach ($customer_list as $c): ?>
                    <option value="<?= htmlspecialchars($c['name']) ?>" data-id="<?= $c['id'] ?>"></option>
                    <?php endforeach ?>
                </datalist>
                <button type="button" class="add-customer-icon btn-ico ms-2" id="add-customer-btn" title="Add New Customer">
                    <i class="fa fa-user-plus"></i>
                </button>
            </div>
        </div>
        <div class="order-items-section" id="order-items-section">
            <table class="table table-bordered align-middle" id="order-items-table">
                <thead>
                    <tr>
                        <th class="width-24">Item</th>
                        <th class="width-10">Qty</th>
                        <th class="width-12">Pack Size</th>
                        <th class="width-14">Price/Unit</th>
                        <th class="width-16">Total</th>
                        <th class="width-10">Action</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
            <div class="add-item-icons-row">
                <button type="button" class="add-item-icon-btn btn-ico" id="add-item-row" title="Add Item"><i class="fa fa-plus"></i></button>
                <!-- Use the same trigger as list.php: inline onclick -->
                <button type="button" class="add-item-icon-btn btn-ico" id="add-new-item-btn" title="Add New Item"><i class="fa fa-box-open"></i></button>
            </div>
        </div>
        <div class="order-summary-section margin-bottom-05rem">
            <div class="order-summary-row justify-content-flex-end margin-bottom-0">
                <span class="round-discount-label margin-right-05rem">Rounding</span>
                <button type="button" class="round-discount-btn btn-ico" id="apply-round-discount-btn" title="Apply rounding discount"><i class="fa fa-magic"></i></button>
            </div>
        </div>
        <div class="order-summary-section">
            <div class="order-summary-fields">
                <div class="order-summary-row">
                    <label>Order Amount:</label>
                    <span id="order-amount" class="fw-bold">0.00</span>
                </div>
                <div class="order-summary-row">
                    <label>Discount (Rs.):</label>
                    <input type="number" id="discount-amount" name="discount_amount" class="form-control"
                        value="<?= $order ? htmlspecialchars($order['discount']) : 0 ?>" min="0">
                </div>
                <div class="order-summary-row">
                    <label>Discount (%):</label>
                    <input type="number" id="discount-percent" name="discount_percent" class="form-control" value="0" min="0" max="100">
                </div>
                <div class="order-summary-row">
                    <label>Delivery Charges:</label>
                    <input type="number" id="delivery-charges" name="delivery_charges" class="form-control"
                        value="<?= $order ? htmlspecialchars($order['delivery_charges']) : 0 ?>" min="0">
                </div>
                <div class="order-summary-row">
                    <label>Grand Total:</label>
                    <span id="grand-total" class="fw-bold">0.00</span>
                </div>
            </div>
        </div>
        <div class="order-actions-center">
            <button type="submit" class="btn btn-success">Update Order</button>
            <a href="orders_list.php" class="btn btn-outline-secondary">Back to Orders List</a>
        </div>
    </form>
</div>

<!-- Hidden datalist for items, used for every row -->
<datalist id="item-list">
    <?php foreach ($item_list as $item): ?>
    <option value="<?= htmlspecialchars($item['name']) ?>"
        data-id="<?= $item['id'] ?>"
        data-pack="<?= $item['default_pack_size'] ?>"
        data-price="<?= $item['price_per_unit'] ?>">
    </option>
    <?php endforeach ?>
</datalist>

<!-- Customer Modal for Add/Edit -->
<div id="customer-modal" class="modal" style="display:none"></div>
<!-- Item Modal for Add/Edit (reuse from items page logic) -->
<div id="item-modal" class="modal" style="display:none"></div>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>


<script src="js/edit_order_form.js"></script>
<!-- Add CustomerUI from customers module -->
<script src="/entities/customers/js/customers.js"></script>
<!-- Add ItemUI from items module -->
<script src="/entities/items/js/items.js"></script>
<script>
window._orderEditData = <?= json_encode([
    'order' => $order,
    'customer_name' => $customer_name,
    'order_items' => $order_items
]) ?>;
window._customerList = <?= json_encode($customer_list) ?>;
window._itemList = <?= json_encode($item_list) ?>;
</script>