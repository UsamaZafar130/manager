<div class="modal fade" id="add-customer-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="addCustomerModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form class="modal-content" id="add-customer-form">
      <div class="modal-header">
        <h5 class="modal-title" id="addCustomerModalLabel">Add New Customer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="add-customer-msg" class="mb-2 text-danger"></div>
        <div class="mb-3">
          <label class="form-label">Name *</label>
          <input type="text" class="form-control" name="name" required maxlength="128">
        </div>
        <div class="mb-3">
          <label class="form-label">Contact *</label>
          <input type="text" class="form-control" name="contact" required maxlength="32">
        </div>
        <div class="mb-3">
          <label class="form-label">House #</label>
          <input type="text" class="form-control" name="house_no" maxlength="64">
        </div>
        <div class="mb-3">
          <label class="form-label">Area</label>
          <input type="text" class="form-control" name="area" maxlength="128">
        </div>
        <div class="mb-3">
          <label class="form-label">City</label>
          <input type="text" class="form-control" name="city" maxlength="64">
        </div>
        <div class="mb-3">
          <label class="form-label">Location Link</label>
          <input type="url" class="form-control" name="location" maxlength="255" placeholder="Google Maps URL">
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Add Customer</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
$(function(){
  $('#add-customer-form').on('submit', function(e){
    e.preventDefault();
    $('#add-customer-msg').text('');
    $.post('api/customers.php?action=add', $(this).serialize(), function(resp){
      if(resp.status=='success'){
        $('#add-customer-modal').modal('hide');
        // Add to select2 dropdown and select it
        let newOption = new Option($('input[name="name"]').val(), resp.id, true, true);
        $('#customer-select').append(newOption).trigger('change');
        $('#add-customer-form')[0].reset();
      } else {
        $('#add-customer-msg').text(resp.message);
      }
    },'json');
  });
  $('#add-customer-modal').on('hidden.bs.modal', function(){
    $('#add-customer-form')[0].reset();
    $('#add-customer-msg').text('');
  });
});
</script>