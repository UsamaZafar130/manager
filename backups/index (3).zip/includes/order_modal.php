<?php
// Reusable Order Modal Component
// This can be included in any page that needs the Add New Order modal functionality
?>

<!-- Order Modal (add/edit order) -->
<div class="modal fade" id="orderModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="orderModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="orderModalLabel">New Sales Order</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="order-modal-body">
                <div class="text-center p-4">Loading form...</div>
            </div>
        </div>
    </div>
</div>

<script>
// Global function to show the order modal (reusable across pages)
// Only define if not already defined (to avoid conflicts with orders_list.js)
if (typeof window.showOrderModal === 'undefined') {
    window.showOrderModal = function(orderId = null) {
        const modal = document.getElementById('orderModal');
        const modalTitle = document.getElementById('orderModalLabel');
        const modalBody = document.getElementById('order-modal-body');
        
        if (!modal || !modalTitle || !modalBody) {
            console.error('Order modal elements not found');
            return;
        }
        
        modalTitle.textContent = orderId ? 'Edit Sales Order' : 'New Sales Order';
        modalBody.innerHTML = '<div class="text-center p-4">Loading form...</div>';
        
        let url = '/entities/sales/new_order.php?inline=1';
        if(orderId) url += '&id=' + encodeURIComponent(orderId);

        // Use UnifiedModals for consistent behavior
        if (typeof window.UnifiedModals !== 'undefined') {
            window.UnifiedModals.loadAndShow('orderModal', url, {
                onLoaded: function(modal, bsModal) {
                    if(typeof window.initOrderFormJS === 'function') {
                        window.initOrderFormJS(orderId ? { order_id: parseInt(orderId) } : null);
                    }
                }
            });
        } else {
            // Fallback implementation using fetch API
            fetch(url)
                .then(response => response.text())
                .then(html => {
                    modalBody.innerHTML = html;
                    
                    // Show modal using Bootstrap 5 API
                    const bootstrapModal = new bootstrap.Modal(modal, {
                        backdrop: 'static',
                        keyboard: true
                    });
                    bootstrapModal.show();
                    
                    if(typeof window.initOrderFormJS === 'function') {
                        window.initOrderFormJS(orderId ? { order_id: parseInt(orderId) } : null);
                    }
                })
                .catch(error => {
                    console.error('Error loading order form:', error);
                    modalBody.innerHTML = '<div class="alert alert-danger">Failed to load order form. Please try again.</div>';
                    
                    if (typeof showError === 'function') {
                        showError('Failed to load order form');
                    }
                });
        }
    };
}
</script>