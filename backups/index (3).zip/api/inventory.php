<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db_connection.php';
require_once __DIR__ . '/../includes/functions.php';

// Simple REST-like API for Inventory entity.

header('Content-Type: application/json');

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

switch ($action) {
    case 'list':
        // TODO: Fetch and return inventory records (with filters, current stock)
        echo json_encode(['success' => true, 'inventory' => []]);
        break;

    case 'get':
        $id = intval($_GET['id'] ?? 0);
        // TODO: Get single inventory record by id
        echo json_encode(['success' => true, 'record' => null]);
        break;

    case 'create':
        // TODO: Record inventory (add/remove/fulfil)
        echo json_encode(['success' => true, 'message' => 'Inventory recorded']);
        break;

    case 'update':
        // TODO: Update inventory record by id
        echo json_encode(['success' => true, 'message' => 'Inventory updated']);
        break;

    case 'delete':
        $id = intval($_POST['id'] ?? 0);
        // TODO: Delete inventory record
        echo json_encode(['success' => true, 'message' => 'Inventory record deleted']);
        break;

    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
}