<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db_connection.php';
require_once __DIR__ . '/../includes/functions.php';
header('Content-Type: application/json');
// Select2 search: fetch customers for dropdown
if (!empty($_POST['q'])) {
    $q = trim($_POST['q']);
    $stmt = $pdo->prepare("SELECT id, name FROM customers WHERE (name LIKE :q OR contact LIKE :q OR area LIKE :q OR city LIKE :q) AND deleted_at IS NULL ORDER BY name LIMIT 20");
    $stmt->execute([':q' => "%$q%"]);
    $results = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $results[] = [
            'id' => $row['id'],
            'text' => $row['name']
        ];
    }
    echo json_encode(['results' => $results]);
    exit;
}

// Fetch full customer details (for order form or details view)
if (isset($_POST['id'])) {
    $id = intval($_POST['id']);
    // 1. Get customer details
    $stmt = $pdo->prepare("SELECT * FROM customers WHERE id=? AND deleted_at IS NULL LIMIT 1");
    $stmt->execute([$id]);
    $customer = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$customer) {
        echo json_encode(['success' => false, 'error' => 'Customer not found']);
        exit;
    }

    // 2. Outstanding balance calculation
    // Get total delivered (completed) orders for this customer
    $orderStmt = $pdo->prepare("SELECT COALESCE(SUM(grand_total), 0) AS total_delivered FROM orders WHERE customer_id=? AND status='delivered' AND deleted_at IS NULL");
    $orderStmt->execute([$id]);
    $delivered_total = floatval($orderStmt->fetchColumn());

    // Get total payments received for this customer
    $payStmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) AS total_paid FROM customer_payments WHERE customer_id=?");
    $payStmt->execute([$id]);
    $paid_total = floatval($payStmt->fetchColumn());

    $outstanding = $delivered_total - $paid_total;

    // 3. Return all details
    echo json_encode([
        'success' => true,
        'customer' => [
            'id' => $customer['id'],
            'name' => $customer['name'],
            'contact' => $customer['contact'],
            'area' => $customer['area'],
            'city' => $customer['city'],
            'house_no' => $customer['house_no'],
            'location' => $customer['location'],
            'created_at' => $customer['created_at'],
            'updated_at' => $customer['updated_at'],
            'outstanding_balance' => round($outstanding, 2),
            'total_delivered_orders' => round($delivered_total, 2),
            'total_paid' => round($paid_total, 2)
        ]
    ]);
    exit;
}

// If invalid request
echo json_encode(['success' => false, 'error' => 'Invalid request']);
exit;