<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db_connection.php';
require_once __DIR__ . '/../includes/functions.php';

// Simple REST-like API for Items entity.
// Actions: list, get, create, update, delete

header('Content-Type: application/json');

$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

switch ($action) {
    case 'list':
        // TODO: Fetch and return items (with optional filters, pagination)
        // Example: SELECT id, code, name, price_per_unit FROM items WHERE deleted_at IS NULL
        echo json_encode(['success' => true, 'items' => []]);
        break;

    case 'get':
        // TODO: Get single item by id
        $id = intval($_GET['id'] ?? 0);
        echo json_encode(['success' => true, 'item' => null]);
        break;

    case 'create':
        // TODO: Create new item (validate fields)
        // Fields: code, name, price_per_unit, default_pack_size, category_id, image upload
        echo json_encode(['success' => true, 'message' => 'Item created']);
        break;

    case 'update':
        // TODO: Update item (by id)
        echo json_encode(['success' => true, 'message' => 'Item updated']);
        break;

    case 'delete':
        // TODO: Soft delete item (set deleted_at)
        $id = intval($_POST['id'] ?? 0);
        echo json_encode(['success' => true, 'message' => 'Item deleted']);
        break;

    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
}