<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json');

$pdo = $pdo ?? require __DIR__ . '/../includes/db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get inventory closing data
    $response = [
        'items' => [],
        'lastClosing' => null
    ];

    try {
        if ($pdo) {
            // Create inventory_closing table if it doesn't exist
            $pdo->exec("CREATE TABLE IF NOT EXISTS inventory_closing (
                id INT AUTO_INCREMENT PRIMARY KEY,
                item_id INT NOT NULL,
                closing_date DATE NOT NULL,
                closing_qty DECIMAL(10,2) NOT NULL DEFAULT 0,
                unit_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
                total_value DECIMAL(12,2) NOT NULL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_item_date (item_id, closing_date),
                INDEX idx_closing_date (closing_date)
            ) ENGINE=InnoDB DEFAULT CHARSET=latin1");

            // Get last closing date
            $stmt = $pdo->query("SELECT closing_date, COUNT(*) as total_items FROM inventory_closing ORDER BY closing_date DESC LIMIT 1");
            $lastClosing = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($lastClosing && $lastClosing['closing_date']) {
                $response['lastClosing'] = $lastClosing;
            }

            // Get current month's closing date
            $currentMonth = date('Y-m-01');
            
            // Get all items with their costs and last closing quantities
            $stmt = $pdo->prepare("
                SELECT 
                    i.id,
                    i.name,
                    c.name as category,
                    i.cost_per_unit,
                    COALESCE(ic.closing_qty, 0) as last_closing_qty,
                    COALESCE(il.current_stock, 0) as suggested_qty
                FROM items i
                LEFT JOIN categories c ON i.category_id = c.id
                LEFT JOIN inventory_closing ic ON i.id = ic.item_id AND ic.closing_date = (
                    SELECT MAX(closing_date) FROM inventory_closing WHERE item_id = i.id
                )
                LEFT JOIN (
                    SELECT 
                        item_id,
                        SUM(CASE WHEN type = 'in' THEN quantity ELSE -quantity END) as current_stock
                    FROM inventory_ledger 
                    GROUP BY item_id
                ) il ON i.id = il.item_id
                WHERE i.deleted_at IS NULL
                ORDER BY i.name
            ");
            $stmt->execute();
            $response['items'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (Exception $e) {
        error_log('Inventory closing GET error: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Database error']);
        exit;
    }

    echo json_encode($response);

} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Save inventory closing data
    $response = ['success' => false, 'message' => ''];

    try {
        $closingDataJson = $_POST['closing_data'] ?? '';
        $closingDate = $_POST['closing_date'] ?? date('Y-m-d');
        
        if (empty($closingDataJson)) {
            throw new Exception('No closing data provided');
        }

        $closingData = json_decode($closingDataJson, true);
        if (!$closingData) {
            throw new Exception('Invalid closing data format');
        }

        if ($pdo) {
            // Create table if not exists
            $pdo->exec("CREATE TABLE IF NOT EXISTS inventory_closing (
                id INT AUTO_INCREMENT PRIMARY KEY,
                item_id INT NOT NULL,
                closing_date DATE NOT NULL,
                closing_qty DECIMAL(10,2) NOT NULL DEFAULT 0,
                unit_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
                total_value DECIMAL(12,2) NOT NULL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_item_date (item_id, closing_date),
                INDEX idx_closing_date (closing_date)
            ) ENGINE=InnoDB DEFAULT CHARSET=latin1");

            // Check if closing already exists for this date
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM inventory_closing WHERE closing_date = ?");
            $stmt->execute([$closingDate]);
            $existingCount = $stmt->fetchColumn();

            if ($existingCount > 0) {
                // Update existing closing
                $stmt = $pdo->prepare("DELETE FROM inventory_closing WHERE closing_date = ?");
                $stmt->execute([$closingDate]);
            }

            // Start transaction
            $pdo->beginTransaction();

            // Insert new closing data
            $stmt = $pdo->prepare("
                INSERT INTO inventory_closing (item_id, closing_date, closing_qty, unit_cost, total_value) 
                VALUES (?, ?, ?, ?, ?)
            ");

            $totalItems = 0;
            foreach ($closingData as $item) {
                $stmt->execute([
                    $item['item_id'],
                    $closingDate,
                    $item['closing_qty'],
                    $item['unit_cost'],
                    $item['total_value']
                ]);
                $totalItems++;
            }

            // Commit transaction
            $pdo->commit();

            $response['success'] = true;
            $response['message'] = "Inventory closing saved successfully. $totalItems items recorded for $closingDate.";
        } else {
            throw new Exception('Database connection failed');
        }

    } catch (Exception $e) {
        if ($pdo && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Inventory closing POST error: ' . $e->getMessage());
        $response['message'] = $e->getMessage();
    }

    echo json_encode($response);

} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
?>