#!/bin/bash

# Modal Audit Automation Script for FrozoFun Admin
# Usage: ./modal_audit_weekly.sh
# Run from the project root directory

echo "=== FrozoFun Admin Modal Audit Report ==="
echo "Date: $(date)"
echo "========================================"
echo

# Check if we're in the right directory
if [ ! -f "index.php" ] && [ ! -d "entities" ]; then
    echo "Error: Please run this script from the project root directory"
    exit 1
fi

echo "1. INLINE STYLE ISSUES (HIGH PRIORITY)"
echo "======================================"
echo "Finding modal elements with inline styles..."
inline_styles=$(grep -r "style.*modal\|modal.*style" --include="*.php" --include="*.html" . 2>/dev/null | wc -l)
if [ $inline_styles -gt 0 ]; then
    echo "❌ Found $inline_styles files with inline modal styles:"
    grep -r "style.*modal\|modal.*style" --include="*.php" --include="*.html" . 2>/dev/null
    echo
else
    echo "✅ No inline modal styles found"
    echo
fi

echo "2. LEGACY JQUERY MODAL USAGE"
echo "============================"
echo "Finding jQuery modal method calls..."
jquery_modals=$(grep -r '\$.*modal(' --include="*.js" --include="*.php" . 2>/dev/null | wc -l)
if [ $jquery_modals -gt 0 ]; then
    echo "⚠️ Found $jquery_modals jQuery modal calls (should use Bootstrap 5 API):"
    grep -r '\$.*modal(' --include="*.js" --include="*.php" . 2>/dev/null | head -10
    if [ $jquery_modals -gt 10 ]; then
        echo "... and $(($jquery_modals - 10)) more"
    fi
    echo
else
    echo "✅ No legacy jQuery modal calls found"
    echo
fi

echo "3. BOOTSTRAP VERSION CONSISTENCY"
echo "==============================="
echo "Checking for Bootstrap 4 patterns..."
bs4_patterns=$(grep -r 'data-toggle="modal"\|data-dismiss="modal"' --include="*.php" --include="*.html" . 2>/dev/null | wc -l)
if [ $bs4_patterns -gt 0 ]; then
    echo "❌ Found $bs4_patterns Bootstrap 4 patterns (should be data-bs-*):"
    grep -r 'data-toggle="modal"\|data-dismiss="modal"' --include="*.php" --include="*.html" . 2>/dev/null
    echo
else
    echo "✅ No Bootstrap 4 patterns found"
    echo
fi

echo "4. ALERT() USAGE (SHOULD USE NOTIFICATION MODAL)"
echo "=============================================="
alert_calls=$(grep -r 'alert(' --include="*.js" --include="*.php" . 2>/dev/null | grep -v console | wc -l)
if [ $alert_calls -gt 0 ]; then
    echo "⚠️ Found $alert_calls alert() calls (should use showError/showSuccess/showWarning):"
    grep -r 'alert(' --include="*.js" --include="*.php" . 2>/dev/null | grep -v console | head -5
    if [ $alert_calls -gt 5 ]; then
        echo "... and $(($alert_calls - 5)) more"
    fi
    echo
else
    echo "✅ No alert() calls found"
    echo
fi

echo "5. INCONSISTENT EVENT HANDLERS"
echo "============================="
echo "Finding onclick attributes with modal actions..."
onclick_modals=$(grep -r 'onclick.*modal\|onclick.*Modal' --include="*.php" --include="*.html" . 2>/dev/null | wc -l)
if [ $onclick_modals -gt 0 ]; then
    echo "⚠️ Found $onclick_modals onclick handlers (prefer event delegation):"
    grep -r 'onclick.*modal\|onclick.*Modal' --include="*.php" --include="*.html" . 2>/dev/null | head -5
    if [ $onclick_modals -gt 5 ]; then
        echo "... and $(($onclick_modals - 5)) more"
    fi
    echo
else
    echo "✅ No onclick modal handlers found"
    echo
fi

echo "6. MODAL INVENTORY"
echo "================="
echo "Complete list of files containing modal references:"
modal_files=$(find . -name "*.php" -o -name "*.html" -o -name "*.js" | xargs grep -l "modal" 2>/dev/null | wc -l)
echo "Total files with modal references: $modal_files"
echo

echo "Key modal files:"
echo "- Templates: $(find . -path "*/templates/*" -name "*modal*" | wc -l) files"
echo "- Includes: $(find . -path "*/includes/*" -name "*modal*" | wc -l) files"
echo "- Entity modals: $(find . -path "*/entities/*/modals/*" | wc -l) files"
echo "- JavaScript: $(find . -name "*.js" | xargs grep -l "modal" 2>/dev/null | wc -l) files"
echo

echo "7. SUMMARY"
echo "=========="
total_issues=$((inline_styles + jquery_modals + bs4_patterns + alert_calls + onclick_modals))
if [ $total_issues -eq 0 ]; then
    echo "✅ No major modal issues found! System appears to be following standards."
elif [ $total_issues -lt 10 ]; then
    echo "⚠️ Minor issues found: $total_issues total issues"
    echo "   Recommended: Address during normal development cycle"
else
    echo "❌ Significant issues found: $total_issues total issues"
    echo "   Recommended: Prioritize modal standardization work"
fi

echo
echo "High Priority Issues:"
if [ $inline_styles -gt 0 ]; then
    echo "- Remove $inline_styles inline style attributes from modal elements"
fi
if [ $bs4_patterns -gt 0 ]; then
    echo "- Update $bs4_patterns Bootstrap 4 patterns to Bootstrap 5"
fi

echo
echo "Medium Priority Issues:"
if [ $jquery_modals -gt 0 ]; then
    echo "- Migrate $jquery_modals jQuery modal calls to Bootstrap 5 API"
fi
if [ $onclick_modals -gt 0 ]; then
    echo "- Refactor $onclick_modals onclick handlers to use event delegation"
fi

echo
echo "Low Priority Issues:"
if [ $alert_calls -gt 0 ]; then
    echo "- Replace $alert_calls alert() calls with NotificationModal system"
fi

echo
echo "For detailed issue descriptions and fix instructions, see:"
echo "cleanup/modals_audit.md"
echo
echo "========================================"
echo "Audit completed at $(date)"
echo "========================================"