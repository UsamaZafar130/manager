/**
 * Unified Modal Handler for FrozoFun Admin
 * 
 * Provides consistent modal behavior across the entire application:
 * - Static backdrop (no closing by clicking outside)
 * - ESC key enabled for closing
 * - Consistent close/cancel button behavior
 * - Unified show/hide methods
 * - Form handling integration
 */

window.UnifiedModals = {
    
    /**
     * Configuration for all modals
     */
    config: {
        backdrop: 'static',
        keyboard: true,
        focus: true
    },

    /**
     * Show a modal with unified configuration
     * @param {string|HTMLElement} modalId - Modal ID or element
     * @param {Object} options - Additional Bootstrap modal options
     */
    show: function(modalId, options = {}) {
        const modal = typeof modalId === 'string' ? document.getElementById(modalId) : modalId;
        if (!modal) {
            console.error('Modal not found:', modalId);
            return null;
        }

        // Ensure the modal element is properly attached to DOM
        if (!modal.isConnected) {
            console.error('Modal element not connected to DOM:', modalId);
            return null;
        }

        // Ensure consistent modal attributes
        modal.setAttribute('data-bs-backdrop', 'static');
        modal.setAttribute('data-bs-keyboard', 'true');

        // Merge config with options and ensure rootElement is properly set
        const config = Object.assign({}, this.config, options);
        
        // Ensure we don't pass any null rootElement
        if (config.rootElement === null || config.rootElement === undefined) {
            delete config.rootElement;
        }
        
        // Create and show Bootstrap modal
        const bsModal = new bootstrap.Modal(modal, config);
        bsModal.show();

        // Set up unified event handlers
        this._setupModalEvents(modal, bsModal);

        return bsModal;
    },

    /**
     * Hide a modal
     * @param {string|HTMLElement} modalId - Modal ID or element
     */
    hide: function(modalId) {
        const modal = typeof modalId === 'string' ? document.getElementById(modalId) : modalId;
        if (!modal) return;

        const bsModal = bootstrap.Modal.getInstance(modal);
        if (bsModal) {
            bsModal.hide();
        }
    },

    /**
     * Load content into a modal and show it
     * @param {string} modalId - Modal ID
     * @param {string} url - URL to fetch content from
     * @param {Object} options - Additional options
     */
    loadAndShow: function(modalId, url, options = {}) {
        const modal = document.getElementById(modalId);
        if (!modal) {
            console.error('Modal not found:', modalId);
            return;
        }

        const modalContent = modal.querySelector('.modal-content');
        if (!modalContent) {
            console.error('Modal content container not found in:', modalId);
            return;
        }

        // Show loading state
        modalContent.innerHTML = `
            <div class="modal-header">
                <h5 class="modal-title">Loading...</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        `;

        // Fetch and load content
        fetch(url)
            .then(response => response.text())
            .then(html => {
                modalContent.innerHTML = html;
                
                // Show modal with unified configuration
                const bsModal = this.show(modal, options);
                
                // Set up form handlers if needed
                this._setupFormHandlers(modal);
                
                // Call custom callback if provided
                if (options.onLoaded) {
                    options.onLoaded(modal, bsModal);
                }
            })
            .catch(error => {
                console.error('Error loading modal content:', error);
                modalContent.innerHTML = `
                    <div class="modal-header">
                        <h5 class="modal-title">Error</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-danger">
                            Failed to load content. Please try again.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                `;
                this.show(modal, options);
            });
    },

    /**
     * Set up unified event handlers for a modal
     * @private
     */
    _setupModalEvents: function(modal, bsModal) {
        // Ensure ESC key closes modal
        modal.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                bsModal.hide();
            }
        });

        // Ensure all close buttons work consistently
        modal.querySelectorAll('[data-bs-dismiss="modal"]').forEach(btn => {
            btn.addEventListener('click', function() {
                bsModal.hide();
            });
        });

        // Clean up on hide
        modal.addEventListener('hidden.bs.modal', function() {
            // Reset any form if present
            const form = modal.querySelector('form');
            if (form) {
                form.reset();
                // Clear any error messages
                modal.querySelectorAll('.text-danger, .alert-danger').forEach(el => {
                    el.textContent = '';
                    el.classList.add('d-none-important');
                });
            }
        });
    },

    /**
     * Set up form handlers for forms within modals
     * @private
     */
    _setupFormHandlers: function(modal) {
        const forms = modal.querySelectorAll('form.entity-form');
        forms.forEach(form => {
            // Skip if form already has a handler (entity-specific handlers take precedence)
            // Check for onsubmit property, data-custom-handler attribute, or if entity-specific handler was already set
            if (form.onsubmit || 
                form.hasAttribute('data-custom-handler') ||
                form.hasAttribute('data-entity-handler-set')) {
                return;
            }
            
            // Only set up basic AJAX form handling for forms without existing handlers
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const action = form.getAttribute('action') || window.location.pathname.replace(/\/[^\/]*$/, '/actions.php');
                const formData = new FormData(form);
                
                // Add action based on form data-editing attribute
                if (!formData.has('action')) {
                    const editing = form.getAttribute('data-editing') === '1';
                    formData.append('action', editing ? 'edit' : 'add');
                }

                fetch(action, {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Show success message briefly before closing
                        let successElement = modal.querySelector('.modal-success-message');
                        if (!successElement) {
                            successElement = document.createElement('div');
                            successElement.className = 'alert alert-success modal-success-message';
                            form.insertBefore(successElement, form.firstChild);
                        }
                        successElement.textContent = data.message || 'Operation completed successfully!';
                        successElement.classList.remove('d-none-important');
                        
                        // Hide the modal after a brief delay
                        setTimeout(() => {
                            UnifiedModals.hide(modal);
                            // Check if page should be refreshed
                            if (form.getAttribute('data-refresh-on-success') === 'true') {
                                location.reload();
                            }
                        }, 1500);
                    } else {
                        // Show error message
                        let errorElement = modal.querySelector('.modal-error-message');
                        if (!errorElement) {
                            errorElement = document.createElement('div');
                            errorElement.className = 'alert alert-danger modal-error-message';
                            form.insertBefore(errorElement, form.firstChild);
                        }
                        errorElement.textContent = data.error || data.message || 'An error occurred';
                        errorElement.classList.remove('d-none-important');
                    }
                })
                .catch(error => {
                    console.error('Form submission error:', error);
                    // Use notification modal system instead of alert()
                    if (typeof showError === 'function') {
                        showError('An error occurred while submitting the form');
                    } else {
                        // Fallback for environments where notification modal is not available
                        console.error('Notification system not available, using alert as fallback');
                        alert('An error occurred while submitting the form');
                    }
                });
            });
        });
    },

    /**
     * Initialize unified modal behavior for all modals on the page
     */
    initializeAll: function() {
        document.querySelectorAll('.modal').forEach(modal => {
            // Ensure consistent attributes
            modal.setAttribute('data-bs-backdrop', 'static');
            modal.setAttribute('data-bs-keyboard', 'true');
            
            // Set up event listeners
            modal.addEventListener('show.bs.modal', function() {
                // Focus first input when modal is shown
                setTimeout(() => {
                    const firstInput = modal.querySelector('input:not([type="hidden"]), textarea, select');
                    if (firstInput) {
                        firstInput.focus();
                    }
                }, 150);
            });
        });
    }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    UnifiedModals.initializeAll();
});

// Make it globally available
window.showModal = UnifiedModals.show;
window.hideModal = UnifiedModals.hide;
window.loadModal = UnifiedModals.loadAndShow;

// Utility function for backward compatible error display
window.safeAlert = function(message, isError = true) {
    if (typeof showError === 'function' && isError) {
        showError(message);
    } else if (typeof showInfo === 'function' && !isError) {
        showInfo(message);
    } else {
        // Fallback to browser alert if notification system is not available
        alert(message);
    }
};