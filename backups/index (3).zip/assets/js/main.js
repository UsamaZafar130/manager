// FrozoFun Admin - Main JS
// Handles global UI, theme switch, modals, persistent state, tomselect, etc.
document.addEventListener('keydown', function(e) {
    // Ctrl+O
    if (e.ctrlKey && e.key === 'o') {
        e.preventDefault();
        // Open modal (same as clicking button)
        document.getElementById('show-add-order').click();
        // Autofocus barcode field (if you have one)
        setTimeout(function() {
            let barcodeInput = document.getElementById('barcode-input');
            if (barcodeInput) barcodeInput.focus();
        }, 500);
    }
});
document.addEventListener("DOMContentLoaded", function () {
    // Flash messages (fade out)
    const flash = document.querySelector('.flash-message');
    if (flash) {
        setTimeout(() => flash.classList.add('d-none-important'), 4000);
    }

    // --- Initialize .tom-select on all selects present at page load (Tom Select replaces Select2) ---
    if (window.TomSelect) {
        document.querySelectorAll('select.tom-select').forEach(function(sel) {
            if (!sel.tomselect) {
                new TomSelect(sel, {
                    create: false,
                    sortField: {field: "text", direction: "asc"},
                    dropdownParent: sel.closest('.modal-content') || document.body
                });
            }
        });

        // Dynamically added selects (e.g., in modals)
        if (window.MutationObserver) {
            const observer = new MutationObserver(function(mutations) {
                mutations.forEach(function(mutation) {
                    mutation.addedNodes.forEach(function(node) {
                        if (node.nodeType === 1) {
                            // If the node itself is a tom-select or it contains them
                            const selects = node.matches && node.matches('select.tom-select') ? [node] : node.querySelectorAll ? node.querySelectorAll('select.tom-select') : [];
                            selects.forEach(function(sel) {
                                if (!sel.tomselect) {
                                    new TomSelect(sel, {
                                        create: false,
                                        sortField: {field: "text", direction: "asc"},
                                        dropdownParent: sel.closest('.modal-content') || document.body
                                    });
                                }
                            });
                        }
                    });
                });
            });
            observer.observe(document.body, {childList: true, subtree: true});
        }
    }

    // --- Bootstrap modal event handlers for state preservation and refresh ---
    if (window.jQuery) {
        // Handle modal hidden event for state preservation and page refresh
        $(document).on('hidden.bs.modal', '.modal', function () {
            const scrollPos = window.scrollY || window.pageYOffset || document.documentElement.scrollTop || 0;
            let page = null;
            if (window.jQuery && window.jQuery.fn.dataTable) {
                const tableIds = ['#orders-table', '#batches-table', '#customers-table', '#items-table', '#vendors-table', '#inventory-table'];
                for (let id of tableIds) {
                    if ($(id).length && $.fn.DataTable.isDataTable(id)) {
                        page = $(id).DataTable().page();
                        break;
                    }
                }
            }
            if (page !== null) localStorage.setItem('lastDataTablePage', page);
            localStorage.setItem('lastScrollPos', scrollPos);
            
            // Check if modal was closed due to successful form submission
            const modal = $(this);
            if (modal.data('refresh-on-close')) {
                setTimeout(() => location.reload(), 50);
                modal.removeData('refresh-on-close');
            }
        });

        // Handle successful form submissions in modals
        $(document).on('submit', '.modal form[data-refresh-on-success="true"]', function(e) {
            const modal = $(this).closest('.modal');
            modal.data('refresh-on-close', true);
        });
    }

    // --- Restore scroll/page on reload ---
    if(localStorage.getItem('lastScrollPos')) {
        window.scrollTo(0, parseInt(localStorage.getItem('lastScrollPos')));
        localStorage.removeItem('lastScrollPos');
    }
    if(localStorage.getItem('lastDataTablePage')) {
        const page = parseInt(localStorage.getItem('lastDataTablePage'));
        // Wait for DataTable to initialize, then set page
        setTimeout(function() {
            ['#orders-table','#batches-table','#customers-table','#items-table','#vendors-table','#inventory-table'].forEach(function(id){
                if ($(id).length && $.fn.DataTable.isDataTable(id)) {
                    $(id).DataTable().page(page).draw(false);
                }
            });
            localStorage.removeItem('lastDataTablePage');
        }, 300);
    }
});


// Note: DataTables initialization is handled by unified-tables.js