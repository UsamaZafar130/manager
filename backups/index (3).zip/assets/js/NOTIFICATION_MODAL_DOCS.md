# Notification Modal System Documentation

The NotificationModal system provides a consistent, site-wide modal-based notification system to replace JavaScript alerts and provide better user experience.

## Features

- **Consistent Design**: All modals use Bootstrap styling with consistent color schemes
- **Multiple Types**: Success, Error, Warning, Info, and Confirmation modals
- **Site-wide Availability**: Once included in header.php, available on all pages
- **Non-blocking**: Modals don't block the page and can be closed with ESC key
- **Responsive**: Works well on desktop and mobile devices

## Usage

### Basic Notifications

```javascript
// Success notification
showSuccess('Operation completed successfully!');
showSuccess('Order updated', 'Success');

// Error notification  
showError('Something went wrong!');
showError('Invalid data provided', 'Validation Error');

// Warning notification
showWarning('Please save your changes before proceeding');
showWarning('This action cannot be undone', 'Warning');

// Info notification
showInfo('New features are available');
showInfo('System maintenance scheduled', 'Information');
```

### Confirmation Dialog

```javascript
showConfirm(
    'Are you sure you want to delete this item?',
    'Confirm Deletion',
    function() {
        // User clicked Yes - perform action
        console.log('User confirmed');
    },
    function() {
        // User clicked No - optional callback
        console.log('User cancelled');
    }
);
```

### Advanced Usage

```javascript
// Using the NotificationModal object directly
NotificationModal.error('Custom error message', 'Custom Title', function() {
    // Optional callback when modal is closed
    window.location.reload();
});
```

## Implementation

The system is automatically initialized when the page loads. It creates a single modal element that gets reused for all notifications, reducing DOM overhead.

## Integration

The notification modal system is included in `includes/header.php` and is available on all pages that use the standard header. No additional setup is required.

## Styling

Modals automatically use the appropriate Bootstrap color scheme:
- **Success**: Green header with checkmark icon
- **Error**: Red header with exclamation icon  
- **Warning**: Yellow header with warning triangle icon
- **Info**: Blue header with info icon
- **Confirm**: Yellow header with question icon, Yes/No buttons

## Migration from Alerts

Replace existing JavaScript alerts:

```javascript
// Old way
alert('Please select an item');

// New way
showWarning('Please select an item');

// Old way
if (confirm('Delete this item?')) {
    deleteItem();
}

// New way
showConfirm('Delete this item?', 'Confirm', function() {
    deleteItem();
});
```