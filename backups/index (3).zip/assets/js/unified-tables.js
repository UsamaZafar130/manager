/**
 * Unified Table Initialization for FrozoFun Admin Panel
 * Enhanced DataTables configuration with Bootstrap 5 integration
 */

// Unified table configuration for Bootstrap 5
window.UnifiedTables = {
    // Default configuration for all tables with Bootstrap 5
    defaultConfig: {
        responsive: true,
        paging: true,
        searching: true,
        info: true,
        lengthChange: true,
        pageLength: 50,
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
        autoWidth: false,
        // Custom DOM structure: entries dropdown left, pagination centered, search right
        dom: '<"row mb-3"<"col-md-3"l><"col-md-6 d-flex justify-content-center"p><"col-md-3"f>>' +
             '<"row"<"col-sm-12"tr>>' +
             '<"row mt-3"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7 d-flex justify-content-center"p>>',
        columnDefs: [
            { responsivePriority: 1, targets: 0 },
            { responsivePriority: 2, targets: 1 },
            { responsivePriority: 3, targets: -1 },
            { orderable: true, targets: '_all' }  // Enable sorting on all columns
        ],
        language: {
            search: "Search:",
            lengthMenu: "Show _MENU_ entries",
            info: "Showing _START_ to _END_ of _TOTAL_ entries",
            infoEmpty: "No entries found",
            zeroRecords: "No matching entries found",
            paginate: {
                first: "First",
                last: "Last",
                next: "Next",
                previous: "Previous"
            }
        }
    },

    // Enhanced configuration for orders table
    ordersConfig: function() {
        return $.extend(true, {}, this.defaultConfig, {
            order: [[1, 'desc']],
            columnDefs: [
                { orderable: true, targets: '_all' },  // Enable sorting on all columns
                { responsivePriority: 1, targets: 0 },
                { responsivePriority: 2, targets: 2 },
                { responsivePriority: 3, targets: 1 },
                { responsivePriority: 4, targets: -1 },
                { className: "text-center", targets: [0, 4, 7, 8, -1] },
                { type: "num", targets: [3, 5, 6, 7] }
            ],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ orders",
                info: "Showing _START_ to _END_ of _TOTAL_ orders",
                infoEmpty: "No orders found",
                zeroRecords: "No matching orders found"
            }
        });
    },

    // Enhanced configuration for customers table
    customersConfig: function() {
        return $.extend(true, {}, this.defaultConfig, {
            columnDefs: [
                { orderable: true, targets: '_all' },  // Enable sorting on all columns
                { responsivePriority: 1, targets: 0 },
                { responsivePriority: 2, targets: 1 },
                { responsivePriority: 3, targets: -1 },
                { className: "text-center", targets: [-1] }
            ],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ customers",
                info: "Showing _START_ to _END_ of _TOTAL_ customers",
                infoEmpty: "No customers found",
                zeroRecords: "No matching customers found"
            }
        });
    },

    // Enhanced configuration for vendors table
    vendorsConfig: function() {
        return $.extend(true, {}, this.defaultConfig, {
            columnDefs: [
                { orderable: true, targets: '_all' },  // Enable sorting on all columns
                { responsivePriority: 1, targets: 0 },
                { responsivePriority: 2, targets: 1 },
                { responsivePriority: 3, targets: 4 },
                { responsivePriority: 4, targets: -1 },
                { className: "text-center", targets: [4, -1] }
            ],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ vendors",
                info: "Showing _START_ to _END_ of _TOTAL_ vendors",
                infoEmpty: "No vendors found",
                zeroRecords: "No matching vendors found"
            }
        });
    },

    // Enhanced configuration for items table
    itemsConfig: function() {
        return $.extend(true, {}, this.defaultConfig, {
            columnDefs: [
                { orderable: true, targets: '_all' },  // Enable sorting on all columns
                { responsivePriority: 1, targets: 0 },
                { responsivePriority: 2, targets: 1 },
                { responsivePriority: 3, targets: -1 },
                { className: "text-center", targets: [-1] },
                { type: "num", targets: [2, 3, 4] }
            ],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ items",
                info: "Showing _START_ to _END_ of _TOTAL_ items",
                infoEmpty: "No items found",
                zeroRecords: "No matching items found"
            }
        });
    },

    // Enhanced configuration for expenses table
    expensesConfig: function() {
        return $.extend(true, {}, this.defaultConfig, {
            columnDefs: [
                { orderable: true, targets: '_all' },  // Enable sorting on all columns
                { responsivePriority: 1, targets: 0 },
                { responsivePriority: 2, targets: 1 },
                { responsivePriority: 3, targets: -1 },
                { className: "text-center", targets: [-1, -2] },
                { type: "num", targets: [3] }
            ],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ expenses",
                info: "Showing _START_ to _END_ of _TOTAL_ expenses",
                infoEmpty: "No expenses found",
                zeroRecords: "No matching expenses found"
            }
        });
    },

    // Enhanced configuration for purchases table
    purchasesConfig: function() {
        return $.extend(true, {}, this.defaultConfig, {
            columnDefs: [
                { orderable: true, targets: '_all' },  // Enable sorting on all columns
                { responsivePriority: 1, targets: 0 },
                { responsivePriority: 2, targets: 1 },
                { responsivePriority: 3, targets: -1 },
                { className: "text-center", targets: [-1, -2] },
                { type: "num", targets: [3] }
            ],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ purchases",
                info: "Showing _START_ to _END_ of _TOTAL_ purchases",
                infoEmpty: "No purchases found",
                zeroRecords: "No matching purchases found"
            }
        });
    },

    // Enhanced configuration for batches table
    batchesConfig: function() {
        return $.extend(true, {}, this.defaultConfig, {
            columnDefs: [
                { orderable: true, targets: '_all' },  // Enable sorting on all columns
                { responsivePriority: 1, targets: 0 },
                { responsivePriority: 2, targets: 1 },
                { responsivePriority: 3, targets: -1 },
                { className: "text-center", targets: [-1] }
            ],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ batches",
                info: "Showing _START_ to _END_ of _TOTAL_ batches",
                infoEmpty: "No batches found",
                zeroRecords: "No matching batches found"
            }
        });
    },

    // Enhanced configuration for stock requirements table
    stockRequirementsConfig: function() {
        return $.extend(true, {}, this.defaultConfig, {
            columnDefs: [
                { orderable: true, targets: '_all' },  // Enable sorting on all columns
                { responsivePriority: 1, targets: 1 },
                { responsivePriority: 2, targets: 2 },
                { responsivePriority: 3, targets: -1 },
                { className: "text-center", targets: [0, 3, 4, 5, -1] },
                { type: "num", targets: [3, 4] }
            ],
            language: {
                search: "Search:",
                lengthMenu: "Show _MENU_ items",
                info: "Showing _START_ to _END_ of _TOTAL_ items",
                infoEmpty: "No items found",
                zeroRecords: "No matching items found"
            }
        });
    },

    // Initialize table with specific configuration
    init: function(tableSelector, configType) {
        configType = configType || 'default';
        
        let config;
        switch(configType) {
            case 'orders':
                config = this.ordersConfig();
                break;
            case 'customers':
                config = this.customersConfig();
                break;
            case 'vendors':
                config = this.vendorsConfig();
                break;
            case 'items':
                config = this.itemsConfig();
                break;
            case 'expenses':
                config = this.expensesConfig();
                break;
            case 'purchases':
                config = this.purchasesConfig();
                break;
            case 'batches':
                config = this.batchesConfig();
                break;
            case 'stock-requirements':
                config = this.stockRequirementsConfig();
                break;
            default:
                config = this.defaultConfig;
        }

        // Destroy existing DataTable if it exists
        if ($.fn.DataTable.isDataTable(tableSelector)) {
            $(tableSelector).DataTable().destroy();
        }

        // Initialize new DataTable with Bootstrap 5 styling
        return $(tableSelector).DataTable(config);
    },

    // Enhanced responsive display for mobile with Bootstrap classes
    enhanceMobileDisplay: function() {
        // Custom responsive handling for very small screens
        $(window).on('resize', function() {
            const width = $(window).width();
            
            if (width < 768) {
                // Mobile optimizations with Bootstrap classes
                $('.dataTables_length').addClass('mb-2');
                $('.dataTables_filter').addClass('mb-2');
                $('.dataTables_info').addClass('text-center');
                $('.dataTables_paginate').addClass('text-center');
            } else {
                // Desktop layout
                $('.dataTables_length').removeClass('mb-2');
                $('.dataTables_filter').removeClass('mb-2');
                $('.dataTables_info').removeClass('text-center');
                $('.dataTables_paginate').removeClass('text-center');
            }
        }).trigger('resize');
    },

    // Apply Bootstrap 5 enhanced styling
    applyBootstrapStyling: function() {
        // Add custom CSS for Bootstrap 5 DataTables integration
        if (!$('#bootstrap-tables-style').length) {
            $('<style id="bootstrap-tables-style">')
                .html(`
                    /* Bootstrap 5 DataTables Integration */
                    .dataTables_wrapper {
                        font-size: 0.9rem;
                    }
                    
                    /* Custom layout: entries left, pagination center, search right */
                    .dataTables_wrapper .row:first-child .col-md-3:first-child {
                        text-align: left;
                    }
                    
                    .dataTables_wrapper .row:first-child .col-md-6 {
                        text-align: center;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                    }
                    
                    .dataTables_wrapper .row:first-child .col-md-3:last-child {
                        text-align: right;
                    }
                    
                    .dataTables_filter {
                        text-align: right;
                    }
                    
                    .dataTables_filter input {
                        margin-left: 0.5rem;
                    }
                    
                    .dataTables_filter input,
                    .dataTables_length select {
                        border: 1px solid var(--bs-border-color);
                        border-radius: var(--bs-border-radius);
                        padding: 0.375rem 0.75rem;
                        background-color: var(--bs-body-bg);
                        color: var(--bs-body-color);
                    }
                    
                    .dataTables_filter input:focus,
                    .dataTables_length select:focus {
                        border-color: var(--bs-primary);
                        box-shadow: 0 0 0 0.25rem rgba(var(--bs-primary-rgb), 0.25);
                        outline: 0;
                    }
                    
                    /* Table styling */
                    .table-striped > tbody > tr:nth-of-type(odd) > td,
                    .table-striped > tbody > tr:nth-of-type(odd) > th {
                        background-color: var(--bs-gray-100);
                    }
                    
                    .entity-table tr:nth-child(even) {
                        background-color: var(--bs-gray-100);
                    }
                    
                    .entity-table tr:nth-child(odd) {
                        background-color: var(--bs-body-bg);
                    }
                    
                    /* Pagination styling */
                    .dataTables_paginate .pagination {
                        margin-bottom: 0;
                    }
                    
                    .dataTables_paginate .page-link {
                        color: var(--bs-primary);
                        border-color: var(--bs-border-color);
                    }
                    
                    .dataTables_paginate .page-link:hover {
                        color: var(--bs-primary);
                        background-color: var(--bs-primary-bg-subtle);
                        border-color: var(--bs-primary);
                    }
                    
                    .dataTables_paginate .page-item.active .page-link {
                        background-color: var(--bs-primary);
                        border-color: var(--bs-primary);
                        color: white;
                    }
                    
                    .dataTables_paginate .page-item.disabled .page-link {
                        color: var(--bs-secondary);
                        background-color: var(--bs-light);
                        border-color: var(--bs-border-color);
                    }
                    
                    /* Responsive mobile styling */
                    @media (max-width: 767.98px) {
                        .dataTables_wrapper .row {
                            margin: 0;
                        }
                        
                        .dataTables_wrapper .col-md-6 {
                            padding: 0;
                            margin-bottom: 1rem;
                        }
                        
                        .dataTables_filter {
                            text-align: left !important;
                        }
                        
                        .dataTables_paginate {
                            text-align: center !important;
                        }
                        
                        .dataTables_paginate .pagination {
                            justify-content: center;
                            flex-wrap: wrap;
                        }
                        
                        .pagination .page-item {
                            margin: 1px;
                        }
                    }
                `)
                .appendTo('head');
        }
    }
};

// Auto-initialize on document ready
$(document).ready(function() {
    UnifiedTables.applyBootstrapStyling();
    UnifiedTables.enhanceMobileDisplay();
});