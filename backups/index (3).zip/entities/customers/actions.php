<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../includes/functions.php';
$pdo = $pdo ?? require __DIR__ . '/../../includes/db_connection.php';
header('Content-Type: application/json');
$response = ['success' => false];
try {
    $action = $_POST['action'] ?? '';
    if ($action === 'add' || $action === 'edit') {
        $id = intval($_POST['id'] ?? 0);
        $data = [
            'name'      => trim($_POST['name'] ?? ''),
            'contact'   => trim($_POST['contact'] ?? ''),
            'house_no'  => trim($_POST['house_no'] ?? ''),
            'area'      => trim($_POST['area'] ?? ''),
            'city'      => trim($_POST['city'] ?? ''),
            'location'  => trim($_POST['location'] ?? ''),
        ];
        $data['contact'] = normalize_contact($data['contact']);
        $data['contact_normalized'] = get_contact_normalized($data['contact']);

        $dup_q = "SELECT id, name FROM customers WHERE contact_normalized=? AND deleted_at IS NULL";
        $dup_args = [$data['contact_normalized']];
        if ($action === 'edit') {
            $dup_q .= " AND id != ?";
            $dup_args[] = $id;
        }
        $stmt = $pdo->prepare($dup_q);
        $stmt->execute($dup_args);
        $dup = $stmt->fetch();
        if ($dup) {
            throw new Exception("Customer already exists with name '{$dup['name']}'");
        }

        if ($action === 'add') {
            $stmt = $pdo->prepare("INSERT INTO customers (name, contact, contact_normalized, house_no, area, city, location, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([
                $data['name'], $data['contact'], $data['contact_normalized'],
                $data['house_no'], $data['area'], $data['city'], $data['location']
            ]);
            $response['success'] = true;
            $response['id'] = $pdo->lastInsertId();
            $response['message'] = 'Customer added successfully!';
        } else {
            $stmt = $pdo->prepare("UPDATE customers SET name=?, contact=?, contact_normalized=?, house_no=?, area=?, city=?, location=? WHERE id=?");
            $stmt->execute([
                $data['name'], $data['contact'], $data['contact_normalized'],
                $data['house_no'], $data['area'], $data['city'], $data['location'], $id
            ]);
            $response['success'] = true;
            $response['id'] = $id;
            $response['message'] = 'Customer updated successfully!';
        }
        // Return latest customer data for live update
        $stmt = $pdo->prepare("SELECT * FROM customers WHERE id=?");
        $stmt->execute([$response['id']]);
        $response['customer'] = $stmt->fetch(PDO::FETCH_ASSOC);

        // For compatibility with reloadCustomerList, always include the name at top-level
        if (isset($response['customer']['name'])) {
            $response['name'] = $response['customer']['name'];
        }
    }
    elseif ($action === 'delete') {
        $id = intval($_POST['id']);
        $stmt = $pdo->prepare("UPDATE customers SET deleted_at=NOW() WHERE id=?");
        $stmt->execute([$id]);
        $response['success'] = true;
    }
    // Restore customer
    elseif ($action === 'restore') {
        $id = intval($_POST['id']);
        $stmt = $pdo->prepare("UPDATE customers SET deleted_at=NULL WHERE id=?");
        $stmt->execute([$id]);
        $response['success'] = true;
    }
    // Permanent delete
    elseif ($action === 'delete_permanent') {
        $id = intval($_POST['id']);
        $stmt = $pdo->prepare("DELETE FROM customers WHERE id=?");
        $stmt->execute([$id]);
        $response['success'] = true;
    }
    elseif ($action === 'payment') {
        $id = intval($_POST['id']);
        $amount = floatval($_POST['amount']);
        if ($amount <= 0) throw new Exception("Invalid amount");
        $stmt = $pdo->prepare("INSERT INTO customer_payments (customer_id, amount, paid_at) VALUES (?, ?, NOW())");
        $stmt->execute([$id, $amount]);
        $response['success'] = true;
    }
    else {
        throw new Exception("Unknown action.");
    }

} catch (Exception $e) {
    $response['error'] = $e->getMessage();
}

echo json_encode($response);
exit;