<?php
// Actions handler for meals (similar to other entities)
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../includes/functions.php';
$pdo = require __DIR__ . '/../../includes/db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'load_form':
            $type = $_POST['type'] ?? 'add';
            $meal_id = isset($_POST['meal_id']) ? intval($_POST['meal_id']) : 0;
            
            if ($type === 'edit' && $meal_id) {
                // Load meal data for editing
                try {
                    $stmt = $pdo->prepare("SELECT * FROM meals WHERE id = ?");
                    $stmt->execute([$meal_id]);
                    $mealData = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if (!$mealData) {
                        echo json_encode(['success' => false, 'message' => 'Meal not found']);
                        exit;
                    }
                    
                    ob_start();
                    include 'form.php';
                    $html = ob_get_clean();
                    
                    echo json_encode(['success' => true, 'html' => $html]);
                } catch (Exception $e) {
                    echo json_encode(['success' => false, 'message' => 'Error loading meal: ' . $e->getMessage()]);
                }
            } else {
                // Load form for adding new meal
                ob_start();
                include 'form.php';
                $html = ob_get_clean();
                
                echo json_encode(['success' => true, 'html' => $html]);
            }
            break;
            
        case 'load_details':
            $meal_id = isset($_POST['meal_id']) ? intval($_POST['meal_id']) : 0;
            
            if (!$meal_id) {
                echo json_encode(['success' => false, 'message' => 'Meal ID required']);
                exit;
            }
            
            try {
                // Get meal details with items
                $stmt = $pdo->prepare("
                    SELECT m.*, 
                           COUNT(mi.id) as item_count
                    FROM meals m
                    LEFT JOIN meal_items mi ON m.id = mi.meal_id
                    WHERE m.id = ?
                    GROUP BY m.id
                ");
                $stmt->execute([$meal_id]);
                $meal = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$meal) {
                    echo json_encode(['success' => false, 'message' => 'Meal not found']);
                    exit;
                }
                
                // Get meal items
                $stmt = $pdo->prepare("
                    SELECT mi.qty, mi.pack_size, i.name as item_name, i.price_per_unit
                    FROM meal_items mi
                    JOIN items i ON mi.item_id = i.id
                    WHERE mi.meal_id = ?
                    ORDER BY i.name
                ");
                $stmt->execute([$meal_id]);
                $meal_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
                
                ob_start();
                include 'details.php';
                $html = ob_get_clean();
                
                echo json_encode(['success' => true, 'html' => $html]);
            } catch (Exception $e) {
                echo json_encode(['success' => false, 'message' => 'Error loading meal details: ' . $e->getMessage()]);
            }
            break;
            
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}