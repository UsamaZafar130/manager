// Handles edit order form logic: dynamic rows, calculation, add customer/item modals, submission (AJAX)
$(function() {
    const $orderForm = $('#order-form');
    const $itemsTable = $('#order-items-table');
    let items = [];
    let lastRoundingDiscount = 0;
    // Initial data for edit
    const editData = window._orderEditData || {};
    const order = editData.order || {};
    const orderItems = editData.order_items || [];
    const customerName = editData.customer_name || "";

    // --- PATCH: Use CustomerUI for add new customer, like new_order.php ---
    $('#add-customer-btn').off('click').on('click', function() {
        if (typeof CustomerUI !== "undefined" && CustomerUI.openAddModal) {
            CustomerUI.openAddModal();
        } else {
            // fallback/modal
            $('#add-customer-modal').modal('show');
        }
    });

    // PATCH: Use ItemUI for add new item, like new_order.php
    $('#add-new-item-btn').off('click').on('click', function() {
        if (typeof ItemUI !== "undefined" && ItemUI.openAddModal) {
            ItemUI.openAddModal();
        } else {
            $('#add-item-modal').modal('show');
        }
    });

    // --- CUSTOMER FIELD: Use datalist instead of select2 ---
    let customerListHtml = '';
    if (window._customerList && Array.isArray(window._customerList)) {
        window._customerList.forEach(function(c) {
            customerListHtml += `<option value="${c.name.replace(/"/g, '&quot;')}" data-id="${c.id}"></option>`;
        });
    }
    // Insert datalist if not present
    if ($('#customer-list').length === 0) {
        $('<datalist id="customer-list"></datalist>').appendTo('body');
    }
    $('#customer-list').html(customerListHtml);

    // Replace select2 <select> with <input list="customer-list">
    if ($('#customer-select').length) {
        // Remove select2 if present
        $('#customer-select').replaceWith(
            `<input list="customer-list" id="customer-input" name="customer_name" class="form-control" autocomplete="off" value="${customerName.replace(/"/g, '&quot;')}" />`
        );
    }

    // Cache for default_pack_size
    const itemPackSizeCache = {};

    function roundToNearest5(n) {
        return Math.round(n / 5) * 5;
    }

    function roundDownToNearest50or100(n) {
        if (n % 100 === 0 || n % 50 === 0) return n;
        const lower100 = Math.floor(n / 100) * 100;
        const lower50 = Math.floor(n / 50) * 50;
        if (n - lower100 <= n - lower50) {
            return lower100;
        } else {
            return lower50;
        }
    }

    // Add item row (edit friendly) -- patch: use datalist for items
    function addItemRow(item = {}) {
        let idx = items.length;
        items.push(item);
        let row = `<tr data-idx="${idx}">
            <td>
                <input list="item-list" class="item-input form-control" name="items[${idx}][item_name]" autocomplete="off" value="${item.item_name ? item.item_name.replace(/"/g, '&quot;') : ''}" />
            </td>
            <td><input type="number" min="1" class="qty form-control" name="items[${idx}][qty]" value="${item.qty || 1}" /></td>
            <td><input type="number" min="1" class="pack-size form-control" name="items[${idx}][pack_size]" value="${item.pack_size || 1}" /></td>
            <td><input type="number" min="0" step="0.01" class="price-per-unit form-control" name="items[${idx}][price_per_unit]" value="${item.price_per_unit || 0}" /></td>
            <td><input type="number" min="0" step="0.01" class="total form-control" name="items[${idx}][total]" value="${item.total || 0}" /></td>
            <td><button type="button" class="remove-row icon-btn" title="Remove Row">
            <i class="fa fa-trash"></i>
        </button></td>
        </tr>`;
        $itemsTable.append(row);

        // When item is selected, fill price/pack if available
        let $input = $itemsTable.find('tr').last().find('.item-input');
        $input.on('change', function() {
            let name = $(this).val();
            let $tr = $(this).closest('tr');
            if (itemsData[name]) {
                $tr.find('.price-per-unit').val(itemsData[name].price_per_unit);
                $tr.find('.pack-size').val(itemsData[name].pack_size);
                updateRowTotal($tr);
            }
        });
    }

    // Items datalist index (rebuild on reload)
    let itemsData = {};
    function buildItemsData() {
        itemsData = {};
        $('#item-list option').each(function() {
            const name = $(this).val();
            itemsData[name] = {
                id: $(this).data('id'),
                pack_size: $(this).data('pack'),
                price_per_unit: $(this).data('price')
            };
        });
    }
    buildItemsData();

    $('#add-item-row').on('click', function() {
        addItemRow();
    });

    $itemsTable.on('input', '.qty, .pack-size, .price-per-unit', function() {
        let $tr = $(this).closest('tr');
        let qty = parseFloat($tr.find('.qty').val()) || 1;
        let price = parseFloat($tr.find('.price-per-unit').val()) || 0;
        let total = qty * price;
        let roundedTotal = roundToNearest5(total);
        $tr.find('.total').val(roundedTotal.toFixed(2));
        updateOrderTotals();
    });

    $itemsTable.on('input', '.total', function() {
        let $tr = $(this).closest('tr');
        let qty = parseFloat($tr.find('.qty').val()) || 1;
        let total = parseFloat($(this).val()) || 0;
        $tr.find('.price-per-unit').val(qty > 0 ? (total / qty).toFixed(2) : 0);
        updateOrderTotals();
    });

    $itemsTable.on('click', '.remove-row', function() {
        $(this).closest('tr').remove();
        updateOrderTotals();
    });

    function updateRowTotal($tr) {
        let qty = parseFloat($tr.find('.qty').val()) || 1;
        let price = parseFloat($tr.find('.price-per-unit').val()) || 0;
        let total = qty * price;
        let roundedTotal = roundToNearest5(total);
        $tr.find('.total').val(roundedTotal.toFixed(2));
        updateOrderTotals();
    }

    function updateOrderTotals() {
        let orderAmount = 0;
        $itemsTable.find('tr').each(function() {
            let total = parseFloat($(this).find('.total').val()) || 0;
            orderAmount += total;
        });
        $('#order-amount').text(orderAmount.toFixed(2));

        let userDiscount = parseFloat($('#discount-amount').val()) || 0;
        let delivery = parseFloat($('#delivery-charges').val()) || 0;

        if (lastRoundingDiscount > 0) {
            userDiscount -= lastRoundingDiscount;
            if (userDiscount < 0) userDiscount = 0;
        }

        let grandTotal = orderAmount - userDiscount + delivery;
        $('#grand-total').text(grandTotal.toFixed(2));
    }

    $('#apply-round-discount-btn').on('click', function() {
        let orderAmount = parseFloat($('#order-amount').text()) || 0;
        let userDiscount = parseFloat($('#discount-amount').val()) || 0;
        let delivery = parseFloat($('#delivery-charges').val()) || 0;

        if (lastRoundingDiscount > 0) {
            userDiscount -= lastRoundingDiscount;
            if (userDiscount < 0) userDiscount = 0;
        }

        let grandTotalRaw = orderAmount - userDiscount + delivery;
        let roundedGrandTotal = roundDownToNearest50or100(grandTotalRaw);

        let discountAdded = 0;
        if (roundedGrandTotal !== grandTotalRaw) {
            discountAdded = grandTotalRaw - roundedGrandTotal;
        }

        let totalDiscount = userDiscount + discountAdded;
        $('#discount-amount').val(totalDiscount.toFixed(2));
        lastRoundingDiscount = discountAdded;

        $('#grand-total').text(roundedGrandTotal.toFixed(2));
    });

    $('#discount-percent').on('input', function() {
        let percent = parseFloat($(this).val()) || 0;
        let orderAmount = parseFloat($('#order-amount').text()) || 0;
        let discount = (orderAmount * percent / 100);
        $('#discount-amount').val(discount.toFixed(2)).trigger('input');
    });
    $('#discount-amount, #delivery-charges').on('input', function() {
        lastRoundingDiscount = 0;
        updateOrderTotals();
    });

    // Submit order AJAX (update mode)
    $orderForm.on('submit', function(e) {
        e.preventDefault();
        let itemsArr = [];
        $itemsTable.find('tr').each(function() {
            let name = $(this).find('.item-input').val();
            let data = itemsData[name] || {};
            let qty = $(this).find('.qty').val();
            let pack_size = $(this).find('.pack-size').val();
            let price_per_unit = $(this).find('.price-per-unit').val();
            let total = $(this).find('.total').val();
            if (name && qty && pack_size) {
                itemsArr.push({
                    item_id: data.id || null,
                    item_name: name,
                    qty,
                    pack_size,
                    price_per_unit,
                    total
                });
            }
        });
        // Get customer id by name
        let customerName = $('#customer-input').val();
        let customerId = null;
        $('#customer-list option').each(function() {
            if ($(this).val() === customerName) {
                customerId = $(this).data('id');
            }
        });
        let postData = {
            order_id: $orderForm.data('order-id'),
            customer_id: customerId,
            customer_name: customerName,
            amount: parseFloat($('#order-amount').text()) || 0,
            discount: parseFloat($('#discount-amount').val()) || 0,
            delivery_charges: parseFloat($('#delivery-charges').val()) || 0,
            grand_total: parseFloat($('#grand-total').text()) || 0,
            items: itemsArr
        };
        $.ajax({
            url: 'api/orders.php?action=edit',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(postData),
            dataType: 'json',
            success: function(resp) {
                if (resp.status === 'success') {
                    alert('Order updated!');
                    window.location.href = 'orders_list.php';
                } else {
                    alert(resp.message);
                }
            }
        });
    });

    // --- INIT FORM WITH EXISTING ORDER DATA ---
    function loadOrderItems() {
        if (!orderItems.length) {
            addItemRow();
            return;
        }
        orderItems.forEach(function(item) {
            addItemRow({
                item_id: item.item_id,
                item_name: item.item_name, // use this for option text
                qty: item.qty,
                pack_size: item.pack_size,
                price_per_unit: item.price_per_unit,
                total: item.total
            });
        });
        setTimeout(updateOrderTotals, 500);
    }
    if (order) {
        $('#discount-amount').val(order.discount || 0);
        $('#delivery-charges').val(order.delivery_charges || 0);
    }
    loadOrderItems();
    setTimeout(updateOrderTotals, 1000);

    // --- PATCH: Listen for global list reload triggers after adding new customer/item ---
    window.reloadCustomerList = function(newCustomer) {
        // AJAX reload the datalist for edit form
        $.getJSON('new_order.php?ajax=customer_list', function(list) {
            // Update all customer-list datalists (for multi-form/tabs support)
            $('datalist#customer-list').each(function() {
                let $datalist = $(this);
                $datalist.empty();
                list.forEach(function(c) {
                    $datalist.append(
                        $('<option>')
                            .attr('value', c.name)
                            .attr('data-id', c.id)
                    );
                });
            });
            if(newCustomer && newCustomer.name) {
                $('#customer-input').val(newCustomer.name);
            }
        });
    };
    window.reloadItemList = function(newItem) {
        // AJAX reload the datalist for edit form
        $.getJSON('new_order.php?ajax=item_list', function(list) {
            let $datalist = $('#item-list');
            $datalist.empty();
            list.forEach(function(it) {
                $datalist.append(
                    $('<option>')
                        .attr('value', it.name)
                        .attr('data-id', it.id)
                        .attr('data-pack', it.default_pack_size)
                        .attr('data-price', it.price_per_unit)
                );
            });
            buildItemsData();
            // Optionally select the new item in the last added row (not implemented here)
        });
    };
});