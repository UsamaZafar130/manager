$(function(){
    function loadOrders(){
        $.get('api/orders.php?action=list&undelivered=1', function(resp){
            if(resp.status==='success'){
                let rows = '';
                resp.orders.forEach(function(order){
                    let statusBadge = '';
                    if(order.cancelled) statusBadge = '<span class="badge bg-danger">Cancelled</span>';
                    else if(order.paid && !order.delivered) statusBadge = '<span class="badge bg-primary">Paid</span>';
                    else statusBadge = '<span class="badge bg-warning text-dark">Unpaid</span>';

                    rows += `<tr>
                        <td><input type="checkbox" class="order-checkbox" value="${order.id}"></td>
                        <td>${order.formatted_order_number}</td>
                        <td>${order.order_date.split(' ')[0]}</td>
                        <td>${order.formatted_customer}</td>
                        <td>${parseFloat(order.amount).toFixed(2)}</td>
                        <td>${parseFloat(order.discount).toFixed(2)}</td>
                        <td>${parseFloat(order.delivery_charges).toFixed(2)}</td>
                        <td>${parseFloat(order.grand_total).toFixed(2)}</td>
                        <td>${statusBadge}</td>
                        <td>
                            <a href="edit_order.php?id=${order.id}" class="btn btn-sm btn-info">Edit</a>
                            <a href="print_invoice.php?id=${order.id}" class="btn btn-sm btn-secondary" target="_blank">Invoice</a>
                            <button class="btn btn-sm btn-success mark-paid" data-id="${order.id}">Mark Paid</button>
                            <button class="btn btn-sm btn-warning mark-delivered" data-id="${order.id}">Mark Delivered</button>
                            <button class="btn btn-sm btn-danger cancel-order" data-id="${order.id}">Cancel</button>
                        </td>
                    </tr>`;
                });
                $('#undelivered-orders-table tbody').html(rows);
            }else{
                alert(resp.message);
            }
        },'json');
    }
    loadOrders();

    $('#select-all-orders').on('change', function(){
        $('.order-checkbox').prop('checked', this.checked);
    });

    $('#undelivered-orders-table').on('click', '.mark-paid', function(){
        let id = $(this).data('id');
        let amount = prompt('Enter paid amount:');
        if(amount && parseFloat(amount)>0){
            $.post('api/orders.php?action=mark_paid', {id, amount}, function(resp){
                if(resp.status==='success'){ loadOrders(); }
                else{ alert(resp.message); }
            },'json');
        }
    });

    $('#undelivered-orders-table').on('click', '.mark-delivered', function(){
        let id = $(this).data('id');
        if(confirm('Mark this order as delivered?')){
            $.post('api/orders.php?action=mark_delivered', {id}, function(resp){
                if(resp.status==='success'){ loadOrders(); }
                else{ alert(resp.message); }
            },'json');
        }
    });

    $('#undelivered-orders-table').on('click', '.cancel-order', function(){
        let id = $(this).data('id');
        if(confirm('Cancel this order?')){
            $.post('api/orders.php?action=cancel', {id}, function(resp){
                if(resp.status==='success'){ loadOrders(); }
                else{ alert(resp.message); }
            },'json');
        }
    });

    function getSelectedIds(){
        return $('.order-checkbox:checked').map(function(){ return this.value; }).get();
    }

    $('#bulk-mark-paid').on('click', function(){
        let ids = getSelectedIds();
        if(!ids.length) return alert('Select orders first!');
        let amount = prompt('Enter amount to mark as paid for all selected orders:');
        if(!amount || parseFloat(amount)<=0) return;
        ids.forEach(function(id){
            $.post('api/orders.php?action=mark_paid', {id, amount}, function(resp){
                if(resp.status==='success'){ loadOrders(); }
            },'json');
        });
    });

    $('#bulk-mark-delivered').on('click', function(){
        let ids = getSelectedIds();
        if(!ids.length) return alert('Select orders first!');
        if(confirm('Mark all selected as delivered?')){
            ids.forEach(function(id){
                $.post('api/orders.php?action=mark_delivered', {id}, function(resp){
                    if(resp.status==='success'){ loadOrders(); }
                },'json');
            });
        }
    });

    $('#bulk-cancel').on('click', function(){
        let ids = getSelectedIds();
        if(!ids.length) return alert('Select orders first!');
        if(confirm('Cancel all selected orders?')){
            ids.forEach(function(id){
                $.post('api/orders.php?action=cancel', {id}, function(resp){
                    if(resp.status==='success'){ loadOrders(); }
                },'json');
            });
        }
    });
});