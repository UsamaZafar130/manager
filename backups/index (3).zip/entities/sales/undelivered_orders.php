<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/header.php';
?>
<link href="css/sales.css" rel="stylesheet">
<div class="container mt-4">
    <h2>Undelivered Sales Orders</h2>
    <div class="mb-2">
        <a href="orders_list.php" class="btn btn-secondary">View All Orders</a>
    </div>
    <form id="bulk-action-form" class="mb-2">
        <button type="button" class="btn btn-success" id="bulk-mark-paid">Mark Paid</button>
        <button type="button" class="btn btn-warning" id="bulk-mark-delivered">Mark Delivered</button>
        <button type="button" class="btn btn-danger" id="bulk-cancel">Cancel</button>
        <input type="checkbox" id="select-all-orders"> <label for="select-all-orders" class="fw-normal">Select All</label>
    </form>
    <table class="table table-striped" id="undelivered-orders-table">
        <thead>
            <tr>
                <th></th>
                <th>Order #</th>
                <th>Date</th>
                <th>Customer</th>
                <th>Amount</th>
                <th>Discount</th>
                <th>Delivery Charges</th>
                <th>Grand Total</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Filled by JS -->
        </tbody>
    </table>
</div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script src="js/undelivered_orders.js"></script>