<?php
require_once __DIR__ . '/../../../includes/auth_check.php';
require_once __DIR__ . '/../../../includes/db_connection.php';
header('Content-Type: application/json; charset=UTF-8');
$action = $_REQUEST['action'] ?? '';
$response = ['status' => 'error', 'message' => 'Unknown error'];

switch ($action) {
    case 'search':
        $term = $_GET['term'] ?? '';
        $stmt = $pdo->prepare("SELECT id, name, contact, city FROM customers WHERE deleted_at IS NULL AND (name LIKE ? OR contact LIKE ?) ORDER BY name ASC LIMIT 20");
        $search = "%$term%";
        $stmt->execute([$search, $search]);
        $data = [];
        while ($row = $stmt->fetch()) {
            $data[] = [
                'id' => $row['id'],
                'text' => $row['name'] . ' - ' . $row['contact'] . ($row['city'] ? " ({$row['city']})" : '')
            ];
        }
        echo json_encode(['results' => $data]);
        exit;
    case 'add':
        $name = trim($_POST['name'] ?? '');
        $contact = trim($_POST['contact'] ?? '');
        $house_no = trim($_POST['house_no'] ?? '');
        $area = trim($_POST['area'] ?? '');
        $city = trim($_POST['city'] ?? '');
        $location = trim($_POST['location'] ?? '');

        if (!$name || !$contact) {
            $response['message'] = "Name and contact are required.";
        } else {
            // Normalize contact (numbers only)
            $contact_normalized = preg_replace('/\D/', '', $contact);
            // Check if exists
            $stmt = $pdo->prepare("SELECT id FROM customers WHERE contact_normalized=? AND deleted_at IS NULL");
            $stmt->execute([$contact_normalized]);
            if ($stmt->fetch()) {
                $response['message'] = "Customer with this contact already exists.";
            } else {
                $stmt = $pdo->prepare("INSERT INTO customers (name, contact, contact_normalized, house_no, area, city, location, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
                $stmt->execute([$name, $contact, $contact_normalized, $house_no, $area, $city, $location]);
                $response = ['status' => 'success', 'message' => 'Customer added!', 'id' => $pdo->lastInsertId()];
            }
        }
        break;
    case 'get':
        $id = intval($_GET['id'] ?? 0);
        $stmt = $pdo->prepare("SELECT * FROM customers WHERE id=? AND deleted_at IS NULL");
        $stmt->execute([$id]);
        $customer = $stmt->fetch();
        if ($customer) {
            $response = ['status' => 'success', 'customer' => $customer];
        } else {
            $response['message'] = "Customer not found.";
        }
        break;
    case 'delete':
        $id = intval($_POST['id'] ?? 0);
        $stmt = $pdo->prepare("UPDATE customers SET deleted_at=NOW() WHERE id=?");
        $stmt->execute([$id]);
        $response = ['status' => 'success', 'message' => 'Customer deleted.'];
        break;
    default:
        $response['message'] = "Invalid action.";
}

echo json_encode($response);