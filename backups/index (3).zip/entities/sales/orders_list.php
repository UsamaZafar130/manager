<?php
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../includes/functions.php';
$pageTitle = "Sales Orders";

// Get filter parameter
$filter = $_GET['filter'] ?? '';
$filterTitle = '';
switch ($filter) {
    case 'today':
        $filterTitle = ' - Today\'s Orders';
        break;
    case 'pending':
        $filterTitle = ' - Pending Orders';
        break;
    case 'unpaid':
        $filterTitle = ' - Unpaid Orders';
        break;
}
$pageTitle .= $filterTitle;

require_once __DIR__ . '/../../includes/header.php';
?>
<link href="css/sales.css" rel="stylesheet">

<div class="orders-content">
    <div class="container mt-3">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2 class="text-primary"><i class="fa fa-cash-register me-2"></i> Sales Orders<?= h($filterTitle) ?></h2>
            </div>
            <div class="col-md-4 text-end">
                <a href="orders_summary.php" class="btn btn-success btn-3d me-2" title="Orders Summary">
                    <i class="fa fa-chart-bar me-1"></i> Summary
                </a>
                <button type="button" class="btn btn-primary btn-3d" id="open-order-modal" title="Create New Order">
                    <i class="fa fa-plus me-1"></i> Add Order
                </button>
            </div>
        </div>
        <div class="alert alert-info max-width-700 mb-4">
            <strong>Manage all your sales orders efficiently.</strong><br>
            Use <strong>Add Order</strong> to create new sales orders, or <strong>Summary</strong> to view sales charts and analytics.<br>
            Filter by status, search, or use bulk actions for delivery, payment, or cancellation.<br>
            All columns are searchable and sortable.
        </div>
        <div class="orders-filter-action-row">
            <select id="orders-status-filter" class="orders-filter-select">
                <option value="">All Orders</option>
                <option value="undelivered">Undelivered</option>
                <option value="delivered">Delivered</option>
                <option value="paid">Paid</option>
                <option value="partial_paid">Partial Paid</option>
                <option value="unpaid">Unpaid</option>
                <option value="cancelled">Cancelled</option>
            </select>
            <a href="#" class="orders-shipping-docs-btn" id="shipping-docs-btn" title="Shipping Docs">
                <i class="fa fa-file-lines"></i>
            </a>
        </div>
        <div class="table-responsive">
            <table class="entity-table table table-striped table-hover table-consistent" id="orders-table">
                <thead class="table-light">
                    <tr>
                        <th class="no-sort" data-priority="9"><input type="checkbox" id="select-all-orders"></th>
                        <th data-priority="2">Order #</th>
                        <th data-priority="1">Customer</th>
                        <th data-priority="3">Grand Total</th>
                        <th data-priority="4">Status</th>
                        <th data-priority="5">Amount</th>
                        <th data-priority="6">Discount</th>
                        <th data-priority="7">Delivery Charges</th>
                        <th data-priority="8">Paid</th>
                        <th class="no-sort">
                            <div class="orders-bulk-row-inside-table">
                                <button type="button" class="orders-bulk-btn" id="bulk-delivered-btn" title="Mark Delivered"><i class="fa fa-truck"></i></button>
                                <button type="button" class="orders-bulk-btn" id="bulk-paid-btn" title="Mark Paid"><i class="fa fa-check-circle"></i></button>
                                <button type="button" class="orders-bulk-btn" id="bulk-cancel-btn" title="Cancel"><i class="fa fa-ban"></i></button>
                            </div>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <!-- JS will fill this -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Order Modal (add/edit order) -->
<div class="modal fade" id="orderModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="orderModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="orderModalLabel">New Sales Order</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="order-modal-body">
                <div class="text-center p-4">Loading form...</div>
            </div>
        </div>
    </div>
</div>

<!-- Payment On Delivery After Delivery Modal (Prompt: Yes/No) -->
<div class="modal fade" id="paymentOnDeliveryAfterDeliveryModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="paymentOnDeliveryAfterDeliveryModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="paymentOnDeliveryAfterDeliveryModalLabel">Payment on Delivery</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="payment-on-delivery-after-delivery-body">
        <!-- JS will fill this prompt -->
      </div>
    </div>
  </div>
</div>

<!-- Payment On Delivery Modal (Form after prompt) -->
<div class="modal fade" id="paymentOnDeliveryModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="paymentOnDeliveryModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="paymentOnDeliveryModalLabel">Payment on Delivery</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="payment-on-delivery-body">
        <!-- JS will fill this form -->
      </div>
    </div>
  </div>
</div>

<!-- Mark Payment Modal (direct Mark Paid button) -->
<div class="modal fade" id="markPaymentModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="markPaymentModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="markPaymentModalLabel">Mark Payment for Order</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="mark-payment-modal-body">
        <!-- JS will fill this form -->
      </div>
    </div>
  </div>
</div>

<!-- Modal for Bulk Delivery Result -->
<div class="modal fade" id="bulkDeliveryResultModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="bulkDeliveryResultModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="bulkDeliveryResultModalLabel">Bulk Delivery Result</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- JS will fill this -->
            </div>
        </div>
    </div>
</div>
<script>
$(function() {
    if (window.location.search.indexOf('open_order_modal=1') !== -1) {
        setTimeout(function() {
            $('#open-order-modal').trigger('click');
        }, 300);
    }

    // --- Shipping Docs Icon Click: Open with selected order IDs only ---
    $('#shipping-docs-btn').on('click', function(e) {
        e.preventDefault();
        let ids = $('.order-select-box:checked').map(function(){ return $(this).val(); }).get();
        if (ids.length === 0) {
            showWarning('Please select at least one order to generate shipping docs.');
            return;
        }
        window.open('shipping_docs.php?ids=' + encodeURIComponent(ids.join(',')), '_blank');
    });

    // Set filter parameter for API calls
    window.ordersFilter = '<?= h($filter) ?>';

    // Note: DataTable initialization is handled by orders_list.js
});
</script>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>
<script src="js/orders_list.js"></script>
<script src="js/order_form.js"></script>