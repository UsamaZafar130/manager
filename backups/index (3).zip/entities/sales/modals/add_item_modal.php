<div class="modal fade" id="add-item-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="addItemModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="add-item-form" class="entity-form" autocomplete="off" data-refresh-on-success="false">
      <div class="modal-header">
        <h5 class="modal-title" id="addItemModalLabel">Add New Item</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="add-item-msg" class="mb-2 text-danger"></div>
        <div class="mb-3">
          <label class="form-label">Name *</label>
          <input type="text" class="form-control" name="name" required maxlength="128">
        </div>
        <div class="mb-3">
          <label class="form-label">Code *</label>
          <input type="text" class="form-control" name="code" required maxlength="64">
        </div>
        <div class="mb-3">
          <label class="form-label">Default Pack Size *</label>
          <input type="number" class="form-control" name="default_pack_size" min="1" value="1" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Price Per Unit *</label>
          <input type="number" class="form-control" name="price_per_unit" min="0" step="0.01" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Category</label>
          <input type="text" class="form-control" name="category_id">
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Add Item</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
      </div>
      </form>
    </div>
  </div>
</div>
<script>
// Modern vanilla JS implementation using UnifiedModals and fetch API
document.addEventListener('DOMContentLoaded', function() {
  const modal = document.getElementById('add-item-modal');
  const form = document.getElementById('add-item-form');
  
  // Set up custom form handler since this needs special Select2 integration
  form.setAttribute('data-custom-handler', 'true');
  
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Clear previous error messages
    const errorMsg = document.getElementById('add-item-msg');
    if (errorMsg) errorMsg.textContent = '';
    
    const formData = new FormData(form);
    
    fetch('api/items.php?action=add', {
      method: 'POST',
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      },
      body: formData
    })
    .then(response => response.json())
    .then(resp => {
      if (resp.status === 'success') {
        // Hide modal using UnifiedModals
        UnifiedModals.hide(modal);
        
        // Refresh all .item-select select2 elements
        const itemSelects = document.querySelectorAll('.item-select');
        const nameInput = form.querySelector('input[name="name"]');
        
        itemSelects.forEach(select => {
          // Get the new item data for Select2
          fetch('api/items.php?action=search&term=' + encodeURIComponent(nameInput.value))
            .then(response => response.json())
            .then(data => {
              if (data && data.results && data.results.length) {
                const newOption = new Option(data.results[0].text, data.results[0].id, true, true);
                select.appendChild(newOption);
                
                // Trigger change event for Select2
                if (window.jQuery && jQuery(select).hasClass('select2-hidden-accessible')) {
                  jQuery(select).trigger('change');
                } else {
                  select.dispatchEvent(new Event('change'));
                }
              }
            })
            .catch(error => console.error('Error refreshing item select:', error));
        });
        
        // Reset form
        form.reset();
        
        // Show success notification if available
        if (typeof showSuccess === 'function') {
          showSuccess('Item added successfully!');
        }
      } else {
        // Show error message
        if (errorMsg) {
          errorMsg.textContent = resp.message || 'An error occurred';
        } else if (typeof showError === 'function') {
          showError(resp.message || 'An error occurred');
        }
      }
    })
    .catch(error => {
      console.error('Error adding item:', error);
      if (typeof showError === 'function') {
        showError('An error occurred while adding the item');
      } else if (errorMsg) {
        errorMsg.textContent = 'An error occurred while adding the item';
      }
    });
  });
  
  // Clean up on modal hide (using Bootstrap 5 event)
  modal.addEventListener('hidden.bs.modal', function() {
    form.reset();
    const errorMsg = document.getElementById('add-item-msg');
    if (errorMsg) errorMsg.textContent = '';
  });
});
</script>