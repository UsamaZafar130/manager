<div class="modal fade" id="add-customer-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="addCustomerModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="add-customer-form" class="entity-form" data-refresh-on-success="false">
      <div class="modal-header">
        <h5 class="modal-title" id="addCustomerModalLabel">Add New Customer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="add-customer-msg" class="mb-2 text-danger"></div>
        <div class="mb-3">
          <label class="form-label">Name *</label>
          <input type="text" class="form-control" name="name" required maxlength="128">
        </div>
        <div class="mb-3">
          <label class="form-label">Contact *</label>
          <input type="text" class="form-control" name="contact" required maxlength="32">
        </div>
        <div class="mb-3">
          <label class="form-label">House #</label>
          <input type="text" class="form-control" name="house_no" maxlength="64">
        </div>
        <div class="mb-3">
          <label class="form-label">Area</label>
          <input type="text" class="form-control" name="area" maxlength="128">
        </div>
        <div class="mb-3">
          <label class="form-label">City</label>
          <input type="text" class="form-control" name="city" maxlength="64">
        </div>
        <div class="mb-3">
          <label class="form-label">Location Link</label>
          <input type="url" class="form-control" name="location" maxlength="255" placeholder="Google Maps URL">
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Add Customer</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
      </div>
      </form>
    </div>
  </div>
</div>

<script>
// Modern vanilla JS implementation using UnifiedModals and fetch API
document.addEventListener('DOMContentLoaded', function() {
  const modal = document.getElementById('add-customer-modal');
  const form = document.getElementById('add-customer-form');
  
  // Set up custom form handler since this needs special Select2 integration
  form.setAttribute('data-custom-handler', 'true');
  
  form.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Clear previous error messages
    const errorMsg = document.getElementById('add-customer-msg');
    if (errorMsg) errorMsg.textContent = '';
    
    const formData = new FormData(form);
    
    fetch('api/customers.php?action=add', {
      method: 'POST',
      headers: {
        'X-Requested-With': 'XMLHttpRequest'
      },
      body: formData
    })
    .then(response => response.json())
    .then(resp => {
      if (resp.status === 'success') {
        // Hide modal using UnifiedModals
        UnifiedModals.hide(modal);
        
        // Add to select2 dropdown and select it
        const customerSelect = document.getElementById('customer-select');
        if (customerSelect) {
          const nameInput = form.querySelector('input[name="name"]');
          const newOption = new Option(nameInput.value, resp.id, true, true);
          customerSelect.appendChild(newOption);
          
          // Trigger change event for Select2
          if (window.jQuery && jQuery(customerSelect).hasClass('select2-hidden-accessible')) {
            jQuery(customerSelect).trigger('change');
          } else {
            customerSelect.dispatchEvent(new Event('change'));
          }
        }
        
        // Reset form
        form.reset();
        
        // Show success notification if available
        if (typeof showSuccess === 'function') {
          showSuccess('Customer added successfully!');
        }
      } else {
        // Show error message
        if (errorMsg) {
          errorMsg.textContent = resp.message || 'An error occurred';
        } else if (typeof showError === 'function') {
          showError(resp.message || 'An error occurred');
        }
      }
    })
    .catch(error => {
      console.error('Error adding customer:', error);
      if (typeof showError === 'function') {
        showError('An error occurred while adding the customer');
      } else if (errorMsg) {
        errorMsg.textContent = 'An error occurred while adding the customer';
      }
    });
  });
  
  // Clean up on modal hide (using Bootstrap 5 event)
  modal.addEventListener('hidden.bs.modal', function() {
    form.reset();
    const errorMsg = document.getElementById('add-customer-msg');
    if (errorMsg) errorMsg.textContent = '';
  });
});
</script>