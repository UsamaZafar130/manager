<?php
require_once __DIR__.'/../../includes/auth_check.php';
require_once __DIR__.'/../../includes/db_connection.php';
require_once __DIR__.'/../../includes/functions.php';

$batch_id = isset($_GET['batch_id']) ? intval($_GET['batch_id']) : 0;
if (!$batch_id) {
    echo '<div class="alert alert-danger">Batch not found.</div>';
    exit;
}

// Get orders and payments for the batch
$stmt = $pdo->prepare("
    SELECT so.id, so.grand_total, so.paid, so.delivered, c.name as customer_name,
        (SELECT payment_method FROM order_payments WHERE order_id=so.id ORDER BY paid_at DESC LIMIT 1) as payment_method,
        (SELECT SUM(amount) FROM order_payments WHERE order_id=so.id) as total_paid
    FROM shipping_batch_orders cbo
    JOIN sales_orders so ON cbo.order_id=so.id
    LEFT JOIN customers c ON so.customer_id=c.id
    WHERE cbo.batch_id=?
    ORDER BY so.id ASC
");
$stmt->execute([$batch_id]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate totals
$total_cash = 0; $total_bank = 0; $total_received = 0; $pending_count = 0;
$total_grand_total = 0; $total_payments_received = 0;
foreach ($orders as $o) {
    if ($o['paid'] && $o['payment_method'] == 'cash') $total_cash += floatval($o['total_paid']);
    if ($o['paid'] && $o['payment_method'] == 'bank') $total_bank += floatval($o['total_paid']);
    if ($o['paid']) $total_received += floatval($o['total_paid']);
    if (!$o['paid']) $pending_count++;
    // For receivable calculation
    $total_grand_total += floatval($o['grand_total']);
    $total_payments_received += floatval($o['total_paid']);
}
$total_receivable = $total_grand_total - $total_payments_received;
?>
<div class="mb-3">
    <span class="badge-order-status badge-summary badge-total-received">
        <b>Total Received:</b> <?= format_currency($total_received) ?>
    </span>
    &nbsp;
    <span class="badge-order-status badge-summary badge-bank">
        In Bank: <?= format_currency($total_bank) ?>
    </span>
    &nbsp;
    <span class="badge-order-status badge-summary badge-cash">
        In Cash: <?= format_currency($total_cash) ?>
    </span>
    &nbsp;
    <span class="badge-order-status badge-summary badge-pending">
        Pending Payment: <?= $pending_count ?>
    </span>
    &nbsp;
    <span class="badge-order-status badge-summary badge-receivable">
        Receivable: <b><?= format_currency($total_receivable) ?></b>
    </span>
</div>
<table class="table table-bordered table-striped table-consistent">
    <thead>
        <tr>
            <th>Order #</th>
            <th>Customer Name</th>
            <th>Grand Total</th>
            <th>Paid</th>
            <th>Receivable</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach($orders as $order):
            // Payment icons (bank/cash if paid, else pending)
            if ($order['paid']) {
                if ($order['payment_method'] == 'bank') {
                    $paidIcon = '<i class="fa fa-university icon-standard text-info" title="Paid by Bank"></i>';
                } else {
                    $paidIcon = '<i class="fa fa-money-bill icon-standard text-success" title="Paid by Cash"></i>';
                }
            } else {
                $paidIcon = '<i class="fa fa-exclamation-circle icon-standard text-warning" title="Payment Pending"></i>';
            }
            // Delivered: Tick if delivered, red X if not
            $deliveredIcon = $order['delivered']
                ? '<i class="fa fa-check-circle icon-standard text-success" title="Delivered"></i>'
                : '<i class="fa fa-times-circle icon-standard text-danger" title="Not Delivered"></i>';
            // Receivable for this order
            $order_total_paid = floatval($order['total_paid']);
            $order_receivable = floatval($order['grand_total']) - $order_total_paid;
        ?>
        <tr>
            <td><?= format_order_number($order['id']) ?></td>
            <td><?= htmlspecialchars($order['customer_name']) ?></td>
            <td><?= format_currency($order['grand_total']) ?></td>
            <td><?= format_currency($order_total_paid) ?></td>
            <td class="text-danger fw-bold"><?= format_currency($order_receivable) ?></td>
            <td>
                <?= $deliveredIcon ?>&nbsp;<?= $paidIcon ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>