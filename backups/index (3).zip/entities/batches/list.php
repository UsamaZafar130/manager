<?php
require_once __DIR__.'/../../includes/auth_check.php';
require_once __DIR__.'/../../includes/db_connection.php';

// AJAX endpoint for Move Order modal: return eligible batches as JSON
if (isset($_GET['ajax']) && $_GET['ajax'] == 1 && isset($_GET['eligible'])) {
    $stmt = $pdo->query("SELECT id, batch_name, status FROM shipping_batches WHERE status != 2 ORDER BY id DESC");
    $eligible = $stmt->fetchAll(PDO::FETCH_ASSOC);
    header('Content-Type: application/json');
    echo json_encode($eligible);
    exit;
}

$pageTitle = "Batches";
include_once __DIR__.'/../../includes/header.php';

// Fetch all batches
$stmt = $pdo->query("SELECT * FROM shipping_batches ORDER BY batch_date DESC, id DESC");
$batches = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<link rel="stylesheet" href="/assets/css/batches.css">
<div class="page-content-wrapper">
    <div class="container mt-3">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2 class="text-primary"><i class="fa fa-layer-group me-2"></i> Batches</h2>
            </div>
            <div class="col-md-4 text-end">
                <button class="btn btn-primary btn-3d" id="btn-create-batch"><i class="fa fa-plus me-1"></i> New Batch</button>
            </div>
        </div>
<div class="alert alert-info max-width-700 mb-4">
    <strong>Manage your shipping batches.</strong> Use <strong>New Batch</strong> to create shipping batches for orders.<br>
    Track batch status from pending to delivered. All columns are searchable and sortable.
</div>

<table class="entity-table table table-striped table-hover table-consistent" id="batches-table">
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Batch Name</th>
            <th>Date</th>
            <th>Status</th>
            <th>Orders</th>
            <th>Created</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php if (empty($batches)): ?>
        <tr><td colspan="7" class="text-center">No batches found.</td></tr>
    <?php endif; ?>
    <?php foreach($batches as $batch): ?>
        <tr data-batch-id="<?= $batch['id'] ?>">
            <td><?= $batch['id'] ?></td>
            <td><?= htmlspecialchars($batch['batch_name']) ?></td>
            <td><?= htmlspecialchars($batch['batch_date']) ?></td>
            <td>
                <?php
                $status = (int)$batch['status'];
                if ($status === 0) {
                    echo '<span class="badge-status badge-secondary">Pending</span>';
                } elseif ($status === 1) {
                    echo '<span class="badge-status badge-warning">In Process</span>';
                } elseif ($status === 2) {
                    echo '<span class="badge-status badge-success">Delivered</span>';
                } else {
                    echo '<span class="badge-status badge-secondary">Unknown</span>';
                }
                ?>
            </td>
            <td>
                <i class="fa fa-box"></i>
            </td>
            <td><?= htmlspecialchars($batch['created_at']) ?></td>
            <td>
                <div class="btn-group btn-group-sm action-icons" role="group">
                    <a href="batch.php?id=<?= $batch['id'] ?>" class="btn btn-outline-primary btn-3d" target="_blank" title="Details"><i class="fa fa-eye"></i></a>
                </div>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
    </div>
</div>

<!-- Create Batch Modal (Bootstrap Modal) -->
<div class="modal fade" id="createBatchModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="createBatchModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="createBatchModalLabel">
                    <i class="fa fa-layer-group me-2"></i>Create New Batch
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="create-batch-form" method="post" action="create.php">
                    <div class="mb-3">
                        <label for="batch_name" class="form-label">
                            Batch Name 
                            <span class="text-muted fw-normal">(leave blank for auto)</span>
                        </label>
                        <input type="text" name="batch_name" id="batch_name" class="form-control" placeholder="Batch YYYY-MM-DD #100XXX">
                    </div>
                    <div class="mb-3">
                        <label for="batch_date" class="form-label">Batch Date</label>
                        <input type="date" name="batch_date" id="batch_date" class="form-control" required>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">Create</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<script src="js/batches.js"></script>
<script>
$(function() {
    // Use UnifiedTables for DataTable initialization
    window.UnifiedTables.init('#batches-table', 'batches');
    
    // Create batch modal logic - use UnifiedModals
    $('#btn-create-batch').on('click', function(){
        window.UnifiedModals.show('createBatchModal');
    });
});
</script>
<?php include_once __DIR__.'/../../includes/footer.php'; ?>