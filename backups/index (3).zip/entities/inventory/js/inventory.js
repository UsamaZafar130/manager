// Inventory Management JS

$(document).ready(function () {
    // Select All functionality (and sync with individual checkboxes)
    $('#select-all-orders').on('change', function() {
        $('.order-checkbox').prop('checked', this.checked);
    });
    $(document).on('change', '.order-checkbox', function() {
        let allChecked = $('.order-checkbox').length === $('.order-checkbox:checked').length;
        $('#select-all-orders').prop('checked', allChecked);
    });

    // Stock Requirements button - open requirements in new tab
    $('#btn-stock-req').on('click', function() {
        let orderIds = $('.order-checkbox:checked').map(function(){ return $(this).val(); }).get();
        if (orderIds.length === 0) {
            alert('Please select at least one order!');
            return;
        }
        window.open('stock_requirements.php?order_ids=' + orderIds.join(','), '_blank');
    });

    // Packing Log button - open packing log in new tab
    $('#btn-packing-log').on('click', function() {
        let orderIds = $('.order-checkbox:checked').map(function(){ return $(this).val(); }).get();
        if (orderIds.length === 0) {
            alert('Please select at least one order!');
            return;
        }
        window.open('packing.php?order_ids=' + orderIds.join(','), '_blank');
    });

    // Packing Labels button - open packing_labels.php in new tab
    $('#btn-packing-labels').on('click', function() {
        let orderIds = $('.order-checkbox:checked').map(function(){ return $(this).val(); }).get();
        if (orderIds.length === 0) {
            alert('Please select at least one order!');
            return;
        }
        window.open('packing_labels.php?order_ids=' + orderIds.join(','), '_blank');
    });

    // Add Stock button (on both pages) - use UnifiedModals for consistency
    $('#btn-add-stock').on('click', function() {
        if (typeof window.UnifiedModals !== 'undefined') {
            openAddStockModal();
        } else {
            console.error('UnifiedModals not available');
            $('#add-stock-modal').modal('show');
        }
    });

    // Show Excess Stock button (on both pages)
    $('#btn-excess-stock').on('click', function() {
        const modal = document.getElementById('excess-stock-modal');
        if (window.UnifiedModals) {
            window.UnifiedModals.show('excess-stock-modal');
        } else {
            $('#excess-stock-modal').modal('show');
        }
        $('#excess-stock-table-container').html('<div style="padding:12px;text-align:center;">Loading...</div>');
        // AJAX fetch for excess stock
        $.get('/entities/inventory/actions.php', {action: 'get_excess_stock'}, function(resp) {
            if(!resp.success) {
                $('#excess-stock-table-container').html('<div class="alert alert-danger">'+(resp.error||'Could not fetch excess stock.')+'</div>');
                return;
            }
            if(!resp.data.length) {
                $('#excess-stock-table-container').html('<div class="alert alert-warning">No items have excess stock!</div>');
                return;
            }
            // Build table
            let table = `<table class="entity-table" id="excess-stock-table">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Category</th>
                        <th>Manufactured</th>
                        <th>Required</th>
                        <th>Excess</th>
                        <th>Price/Unit</th>
                        <th>Excess Value</th>
                    </tr>
                </thead>
                <tbody>`;
            let totalExcessValue = 0;
            resp.data.forEach(function(row){
                totalExcessValue += parseFloat(row.excess_value || 0);
                table += `<tr>
                    <td>${escapeHtml(row.name)}</td>
                    <td>${escapeHtml(row.category || 'Uncategorized')}</td>
                    <td>${parseFloat(row.manufactured).toFixed(2)}</td>
                    <td>${parseFloat(row.required).toFixed(2)}</td>
                    <td><span class="badge badge-surplus">+${parseFloat(row.excess).toFixed(2)}</span></td>
                    <td>Rs. ${parseFloat(row.price_per_unit || 0).toFixed(2)}</td>
                    <td><strong>Rs. ${parseFloat(row.excess_value || 0).toFixed(2)}</strong></td>
                </tr>`;
            });
            table += `</tbody>
                <tfoot>
                    <tr class="table-success">
                        <th colspan="6" class="text-end">Total Excess Stock Value:</th>
                        <th><strong>Rs. ${totalExcessValue.toFixed(2)}</strong></th>
                    </tr>
                </tfoot>
            </table>`;
            $('#excess-stock-table-container').html(table);
            // Init DataTables if available
            if(window.jQuery && $.fn.DataTable) {
                $('#excess-stock-table').DataTable({
                    responsive: true,
                    paging: false,
                    searching: true,
                    info: false,
                    ordering: true
                });
            }
        }, 'json');
    });

    // Copy excess list to clipboard for WhatsApp
    $(document).on('click', '#copy-excess-btn', function() {
        let rows = $('#excess-stock-table tbody tr');
        if (!rows.length) {
            alert('No excess items to copy!');
            return;
        }
        let lines = [];
        rows.each(function() {
            let item = $(this).find('td').eq(0).text().trim();
            let excess = $(this).find('td').eq(4).text().replace('+','').trim();
            if (item && excess) {
                lines.push(item + ': ' + excess);
            }
        });
        if (lines.length) {
            const textToCopy = lines.join('\n');
            navigator.clipboard.writeText(textToCopy).then(function() {
                alert('Copied to clipboard!\n\n' + textToCopy);
            }, function() {
                alert('Failed to copy!');
            });
        } else {
            alert('No excess items to copy!');
        }
    });

    // Show/hide comment field for negative stock
    $('#add-stock-modal').on('input change', '#stock-qty', function() {
        let qty = parseFloat($(this).val());
        if (!isNaN(qty) && qty < 0) {
            $('#stock-comment-row').show();
            $('#stock-comment').attr('required', true);
        } else {
            $('#stock-comment-row').hide();
            $('#stock-comment').removeAttr('required');
        }
    });

    // Initialize TomSelect for Add Stock modal when opened
    function openAddStockModal() {
        // Use UnifiedModals for consistent behavior
        if (typeof window.UnifiedModals !== 'undefined') {
            window.UnifiedModals.show('add-stock-modal');
        } else {
            // Fallback to Bootstrap 5 API
            const modal = new bootstrap.Modal(document.getElementById('add-stock-modal'));
            modal.show();
        }

        let $sel = $('#stock-item-select');

        // Destroy old TomSelect instance if exists (important for modal reuse)
        if ($sel[0].tomselect) {
            $sel[0].tomselect.destroy();
        }

        // Clear and show Loading...
        $sel.empty().append('<option value="">Loading...</option>');

        // Fetch items from the server
        $.getJSON('/entities/items/items_list.php', function(items) {
            $sel.empty().append('<option value="">Select Item</option>');
            items.forEach(function(it) {
                $sel.append('<option value="'+it.id+'">'+it.name+'</option>');
            });

            // Match Sales Module: do NOT set dropdownParent!
            if (typeof TomSelect !== "undefined") {
                new TomSelect($sel[0], {
                    create: false,
                    sortField: 'text'
                    // dropdownParent not set, matches sales module!
                });
            } else {
                // fallback: show warning if TomSelect not loaded
                console.warn("TomSelect not loaded!");
            }
        });
    }

    // Handle Add Stock form submit
    $('#add-stock-form').on('submit', function(e) {
        e.preventDefault();
        let item_id = $('#stock-item-select').val();
        let qty = $('#stock-qty').val();
        let comment = $('#stock-comment').val();
        if (!item_id || qty === "" || isNaN(qty) || parseFloat(qty) === 0) {
            $('#add-stock-feedback').addClass('alert-danger').removeClass('alert-success').text('Please select an item and enter a non-zero quantity.').show();
            return;
        }
        if (parseFloat(qty) < 0 && (!comment || comment.trim() === "")) {
            $('#add-stock-feedback').addClass('alert-danger').removeClass('alert-success').text('Please enter a comment for negative stock (reconciliation).').show();
            return;
        }
        $.post('actions.php', {action:'add_stock', item_id, qty, comment}, function(resp) {
            if (resp.success) {
                $('#add-stock-feedback').removeClass('alert-danger').addClass('alert-success').text('Stock added!').show();
                setTimeout(()=>{ 
                    const modal = document.getElementById('add-stock-modal');
                    window.UnifiedModals.hide(modal); 
                    location.reload(); 
                }, 600);
            } else {
                $('#add-stock-feedback').addClass('alert-danger').removeClass('alert-success').text(resp.error || 'Error!').show();
            }
        }, 'json');
    });

    // Inline manufactured update (on Stock Requirements page)
    $(document).on('click', '.btn-update-stock', function() {
        let $tr = $(this).closest('tr');
        let item_id = $tr.find('.row-item-id').val();
        let qty = parseFloat($tr.find('.manufactured-input').val());

        // Updated! Find Total Required by its actual column index (4th column: #, Item, Category, Total Required)
        let required = parseFloat($tr.find('td:nth-child(4)').text().replace(/,/g, ''));
        let manufactured = parseFloat($tr.find('.manufactured-val').text().replace(/,/g, ''));

        if (!item_id || isNaN(qty) || qty <= 0) {
            alert('Please enter a positive quantity.');
            return;
        }

        // Now just add stock, like the modal
        $.post('actions.php', {action:'update_manufactured', item_id, qty}, function(resp) {
            if (resp.success) {
                setTimeout(function() { location.reload(); }, 400);
            } else {
                alert(resp.error || 'Update failed');
            }
        }, 'json');
    });

    // Remove custom ESC key handling - Bootstrap modals handle this automatically

    // Utility to escape HTML in JS
    function escapeHtml(text) {
        return $('<div>').text(text).html();
    }
});