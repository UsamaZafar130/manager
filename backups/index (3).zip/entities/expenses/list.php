<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../../includes/auth_check.php';
require_once __DIR__ . '/../../includes/functions.php';
$pageTitle = "Expenses";
include __DIR__ . '/../../includes/header.php';

$pdo = $pdo ?? require __DIR__ . '/../../includes/db_connection.php';

// Fetch all expenses with vendor name and payment count
$stmt = $pdo->prepare("
    SELECT e.*, v.name AS vendor_name,
        (SELECT COUNT(*) FROM expense_payments ep WHERE ep.expense_id = e.id AND ep.deleted_at IS NULL) AS payment_count
    FROM expenses e
    LEFT JOIN vendors v ON e.vendor_id = v.id
    WHERE e.deleted_at IS NULL
    ORDER BY e.date DESC, e.created_at DESC
");
$stmt->execute();
$expenses = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Calculate paid/unpaid status and amount paid for each expense
$expense_ids = array_column($expenses, 'id');
$amount_paid = [];
if ($expense_ids) {
    $in = implode(',', array_fill(0, count($expense_ids), '?'));
    $payStmt = $pdo->prepare("SELECT expense_id, SUM(amount) AS paid FROM expense_payments WHERE expense_id IN ($in) AND deleted_at IS NULL GROUP BY expense_id");
    $payStmt->execute($expense_ids);
    foreach ($payStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $amount_paid[$row['expense_id']] = $row['paid'];
    }
}

// Fetch applied advances for visible expenses
$advances_by_expense = [];
if ($expense_ids) {
    $in = implode(',', array_fill(0, count($expense_ids), '?'));
    $advStmt = $pdo->prepare("SELECT id, amount, applied_to_expense_id FROM vendor_advances WHERE applied_to_expense_id IN ($in)");
    $advStmt->execute($expense_ids);
    foreach ($advStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $eid = $row['applied_to_expense_id'];
        if (!isset($advances_by_expense[$eid])) $advances_by_expense[$eid] = [];
        $advances_by_expense[$eid][] = $row;
    }
}
?>

<div class="page-content-wrapper">
    <div class="container mt-3">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2 class="text-primary"><i class="fa fa-money-bill me-2"></i> Expenses</h2>
            </div>
            <div class="col-md-4 text-end">
                <button class="btn btn-primary btn-3d" onclick="showExpenseModal()">
                    <i class="fa fa-plus me-1"></i> Add Expense
                </button>
            </div>
        </div>
<div class="alert alert-info max-width-700 mb-4">
    <strong>Track and manage business expenses.</strong> Use <strong>Add Expense</strong> to record vendor expenses and payments.<br>
    Monitor payment status and outstanding amounts. Use <strong>Trash</strong> to view deleted expenses.
</div>
<div class="mb-3 header-buttons-secondary">
    <a class="btn btn-outline-danger btn-3d" href="trash.php" title="View Trash">
        <i class="fa fa-trash me-1"></i> Trash
    </a>
</div>

<div id="expenses-list-wrap">
    <table class="entity-table table table-striped table-hover table-consistent" id="expenses-table">
        <thead class="table-light">
            <tr>
                <th>Date</th>
                <th>Vendor</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Description</th>
                <th>Advance Applied</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($expenses as $e):
            $paid = isset($amount_paid[$e['id']]) ? floatval($amount_paid[$e['id']]) : 0;
            $status = ($paid >= floatval($e['amount'])) ? 'Paid' : ($paid > 0 ? 'Partial' : 'Unpaid');
            $badgeClass = $status === 'Paid' ? 'badge-surplus' : ($status === 'Partial' ? 'badge-settled' : 'badge-outstanding');
            $adv_list = isset($advances_by_expense[$e['id']]) ? $advances_by_expense[$e['id']] : [];
        ?>
            <tr data-expense-id="<?= $e['id'] ?>"
                data-expense='<?= h(json_encode($e)) ?>'
                data-payment-count="<?= $e['payment_count'] ?>">
                <td data-label="Date"><?= h(date('Y-m-d', strtotime($e['date']))) ?></td>
                <td data-label="Vendor"><?= h($e['vendor_name']) ?></td>
                <td data-label="Type">
                  <span class="badge <?= $e['type']=='credit'?'badge-outstanding':'badge-surplus' ?>">
                    <?= ucfirst($e['type']) ?>
                  </span>
                </td>
                <td data-label="Amount"><?= format_currency($e['amount']) ?></td>
                <td data-label="Description"><?= h($e['description']) ?></td>
                <td data-label="Advance Applied">
                  <?php if ($adv_list): ?>
                    <span class="badge badge-surplus">
                        <?= implode(", ", array_map(function($a){ return format_currency($a['amount']); }, $adv_list)) ?>
                    </span>
                  <?php else: ?>
                    <span class="badge badge-settled">-</span>
                  <?php endif; ?>
                </td>
                <td data-label="Status">
                    <span class="badge <?= $badgeClass ?>">
                        <?= h($status) ?><?= $status !== 'Paid' && $paid > 0 ? " ($paid paid)" : "" ?>
                    </span>
                </td>
                <td data-label="Actions">
                    <div class="btn-group btn-group-sm action-icons" role="group">
                        <button class="btn btn-outline-primary btn-3d" title="Details" onclick="ExpenseUI.openDetails(<?= $e['id'] ?>)">
                            <i class="fa fa-eye"></i>
                        </button>
                        <?php if($status !== 'Paid'): ?>
                            <button class="btn btn-outline-warning btn-3d" title="Edit" onclick="showExpenseModal(<?= $e['id'] ?>)">
                                <i class="fa fa-edit"></i>
                            </button>
                        <?php endif; ?>
                        <form method="post" action="actions.php" class="ajax-delete-expense" style="display:inline;">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= $e['id'] ?>">
                            <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">
                            <button class="btn btn-outline-danger btn-3d" title="Delete" type="submit">
                                <i class="fa fa-trash"></i>
                            </button>
                        </form>
                        <?php if($status !== 'Paid'): ?>
                            <button class="btn btn-outline-success btn-3d" title="Pay" onclick="ExpenseUI.openPaymentModal(<?= $e['id'] ?>, <?= $e['amount']-$paid ?>)">
                                <i class="fa fa-money-bill-wave"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
</div>
</div>

<!-- Bootstrap Modals for ExpenseUI (details and payments only) -->
<!-- Add Expense Modal -->
<div class="modal fade" id="expense-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="expenseModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <!-- Content will be loaded dynamically -->
        </div>
    </div>
</div>

<div class="modal fade" id="delete-error-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="deleteErrorModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteErrorModalLabel">Error</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="delete-error-message" class="fs-5 text-danger"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">OK</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="expense-details-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="expenseDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Content will be loaded dynamically -->
        </div>
    </div>
</div>

<div class="modal fade" id="expense-payment-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="expensePaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Content will be loaded dynamically -->
        </div>
    </div>
</div>


<script src="js/expenses.js"></script>
<script>
// Initialize DataTable with UnifiedTables
$(document).ready(function() {
    if ($('#expenses-table').length && window.UnifiedTables) {
        UnifiedTables.init('#expenses-table', 'expenses');
    }
});
</script>
<?php include __DIR__ . '/../../includes/footer.php'; ?>