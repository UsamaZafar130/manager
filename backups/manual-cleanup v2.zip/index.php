<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/includes/auth_check.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/dashboard_stats.php';
$pageTitle = "FrozoFun Admin Dashboard";

// Load user dashboard preferences
$dashboardPrefs = [];
try {
    $pdo = null;
    @include __DIR__ . '/includes/db_connection.php';
    if ($pdo && !empty($_SESSION['user_id'])) {
        $stmt = $pdo->prepare("SELECT widget_id, is_visible, sort_order FROM user_dashboard_prefs WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $prefs = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach ($prefs as $pref) {
            $dashboardPrefs[$pref['widget_id']] = [
                'visible' => (bool)$pref['is_visible'],
                'order' => (int)$pref['sort_order']
            ];
        }
    }
} catch (Exception $e) {
    error_log('Error loading dashboard preferences: ' . $e->getMessage());
}

// Set defaults for widgets not in preferences
$defaultWidgets = [
    'stats-cards' => ['visible' => true, 'order' => 1],
    'business-metrics' => ['visible' => true, 'order' => 2],
    'financial-metrics' => ['visible' => true, 'order' => 3],
    'module-cards' => ['visible' => true, 'order' => 4],
    'analytics-dashboard' => ['visible' => true, 'order' => 5]
];

foreach ($defaultWidgets as $widgetId => $default) {
    if (!isset($dashboardPrefs[$widgetId])) {
        $dashboardPrefs[$widgetId] = $default;
    }
}

// Sort widgets by order
uasort($dashboardPrefs, function($a, $b) {
    return $a['order'] - $b['order'];
});

include __DIR__ . '/includes/header.php';

// Get dashboard statistics and activity
$stats = [];
$activity = [];
$stockRequirements = ['items' => [], 'batch_id' => null];
try {
    $pdo = null;
    @include __DIR__ . '/includes/db_connection.php';
    if ($pdo) {
        $stats = getDashboardStats($pdo);
        $activity = getRecentActivity($pdo);
        $stockRequirements = getCurrentBatchStockRequirements($pdo, 3);
    } else {
        // No database connection, use defaults
        throw new Exception('No database connection');
    }
} catch (Throwable $e) {
    // If database connection fails, show zeros with appropriate message
    $stats = [
        'items' => 0, 
        'customers' => 0, 
        'orders' => 0, 
        'vendors' => 0,
        'batches' => 0, 
        'purchases' => 0, 
        'expenses' => 0, 
        'users' => 0
    ];
    $activity = [
        'orders_today' => 0,
        'pending_orders' => 0, 
        'current_batch_total' => 0,
        'total_receivables' => 0,
        'total_payables' => 0
    ];
    error_log('Dashboard stats error: ' . $e->getMessage());
}

// Get upcoming batch for shortcut
$batchShortcutId = null;
try {
    if ($pdo) {
        $stmt = $pdo->prepare("SELECT id FROM shipping_batches WHERE batch_date >= CURDATE() ORDER BY batch_date ASC, id ASC LIMIT 1");
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row && !empty($row['id'])) {
            $batchShortcutId = (int)$row['id'];
        }
    }
} catch (Throwable $e) {
    // Ignore DB errors for dashboard, just don't show shortcut if fails
    $batchShortcutId = null;
}

// Original dashboard card layout (single loop)
$entities = [
    [
        'name' => 'Items',
        'desc' => 'Manage products, pricing, and categories.',
        'icon' => 'fa fa-box',
        'color' => 'accent1',
        'url' => '/entities/items/list.php'
    ],
    [
        'name' => 'Customers',
        'desc' => 'View, add, and manage your customers, balances, and orders.',
        'icon' => 'fa fa-users',
        'color' => 'accent2',
        'url' => '/entities/customers/list.php'
    ],
    [
        'name' => 'Sales',
        'desc' => 'Create and manage orders, shipping, and invoices.',
        'icon' => 'fa fa-cash-register',
        'color' => 'accent5',
        'url' => '/entities/sales/orders_list.php'
    ],
    [
        'name' => 'Batches',
        'desc' => 'Group orders, manage delivery, print docs & bulk operations.',
        'icon' => 'fa fa-layer-group',
        'color' => 'accent10',
        'url' => '/entities/batches/list.php'
    ],
    [
        'name' => 'Purchases',
        'desc' => 'Record and review purchases and expenses.',
        'icon' => 'fa fa-shopping-cart',
        'color' => 'accent4',
        'url' => '/entities/purchases/list.php'
    ],
    [
        'name' => 'Expenses',
        'desc' => 'Manage and track your business expenses.',
        'icon' => 'fa fa-credit-card',
        'color' => 'accent9',
        'url' => '/entities/expenses/list.php'
    ],
    [
        'name' => 'Vendors',
        'desc' => 'Track vendors, payments, and outstanding balances.',
        'icon' => 'fa fa-truck',
        'color' => 'accent3',
        'url' => '/entities/vendors/list.php'
    ],
    [
        'name' => 'Inventory',
        'desc' => 'Stock management, packing, and fulfilment.',
        'icon' => 'fa fa-warehouse',
        'color' => 'accent6',
        'url' => '/entities/inventory/list.php'
    ],
    [
        'name' => 'Users',
        'desc' => 'User management and permissions.',
        'icon' => 'fa fa-user-shield',
        'color' => 'accent7',
        'url' => '/entities/users/list.php'
    ],
    [
        'name' => 'Reports',
        'desc' => 'Business analytics and comprehensive reporting dashboard.',
        'icon' => 'fa fa-chart-line',
        'color' => 'accent8',
        'url' => '/entities/reports/index.php'
    ],
];
?>

<div class="container-fluid">
    <!-- Modern Dashboard Hero Section -->
    <div class="dashboard-hero animate-fade-in-up">
        <div class="row align-items-center">
            <div class="col-lg-8 col-md-12">
                <div class="hero-content">
                    <h1>FrozoFun Business Suite</h1>
                    <p class="lead">Transform your business operations with our comprehensive management platform. Monitor performance, track inventory, and grow your business with intelligent insights.</p>
                    <div class="hero-actions">
                        <button id="edit-layout-btn" class="btn btn-modern btn-outline-light">
                            <i class="fas fa-edit me-2"></i>Customize Dashboard
                        </button>
                        <a href="/entities/reports/index.php" class="btn btn-modern bg-glass">
                            <i class="fas fa-chart-line me-2"></i>View Reports
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12 text-center animate-slide-in-right">
                <div class="hero-stats p-4">
                    <div class="row text-center">
                        <div class="col-6">
                            <div class="h3 fw-bold mb-1"><?= number_format($stats['orders']) ?></div>
                            <div class="small opacity-75">Total Orders</div>
                        </div>
                        <div class="col-6">
                            <div class="h3 fw-bold mb-1"><?= number_format($stats['customers']) ?></div>
                            <div class="small opacity-75">Customers</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Quick Tip Notice -->
    <div class="alert alert-info alert-dismissible fade show" role="alert">
        <i class="fas fa-lightbulb me-2"></i>
        <strong>Dashboard Tips:</strong> Use "Customize Dashboard" to rearrange cards by dragging them. Access Settings to show/hide widget categories and personalize your workspace.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>

    <!-- Row-Based Dashboard Cards Container -->
    <div id="dashboard-rows">
        <?php
        // Define dashboard rows and their cards with individual card preferences
        $rows = [];
        
        // Function to check if an individual card should be visible
        function isCardVisible($cardId) {
            global $dashboardPrefs;
            // Check individual card preferences first
            if (isset($dashboardPrefs[$cardId])) {
                return $dashboardPrefs[$cardId]['visible'];
            }
            // Fallback to grouped preferences for backwards compatibility
            $groupMappings = [
                'stat-items' => 'stats-cards',
                'stat-customers' => 'stats-cards', 
                'stat-orders' => 'stats-cards',
                'stat-vendors' => 'stats-cards',
                'metric-orders-today' => 'business-metrics',
                'metric-pending-orders' => 'business-metrics',
                'metric-current-batch' => 'business-metrics',
                'financial-receivables' => 'financial-metrics',
                'financial-payables' => 'financial-metrics',
                'financial-stock-required' => 'financial-metrics',
                'analytics-dashboard' => 'analytics-dashboard'
            ];
            
            if (strpos($cardId, 'module-') === 0) {
                $groupMappings[$cardId] = 'module-cards';
            }
            
            $groupId = $groupMappings[$cardId] ?? null;
            if ($groupId && isset($dashboardPrefs[$groupId])) {
                return $dashboardPrefs[$groupId]['visible'];
            }
            return true; // Default to visible
        }
        
        // Function to create card HTML with empty space preservation
        function createCardHtml($cardId, $content, $isVisible = true) {
            if ($isVisible) {
                return $content;
            } else {
                // Return empty space with same column width to preserve layout
                preg_match('/class="(col-[^"]*)"/', $content, $matches);
                $colClass = $matches[1] ?? 'col-xl-3 col-lg-4 col-md-6 col-sm-6';
                return '<div class="' . $colClass . ' mb-3"><div class="dashboard-card-placeholder" data-card-id="' . $cardId . '"></div></div>';
            }
        }
        
        // Row 1: Statistics Cards (4 cards) - made clickable with anchors
        $row1Cards = [
            'stat-items' => [
                'visible' => isCardVisible('stat-items'),
                'html' => '
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                        <div class="dashboard-card h-100" data-card-id="stat-items">
                            <a href="/entities/items/list.php" class="text-decoration-none" onclick="if(window.isEditMode){event.preventDefault();return false;}">
                                <div class="card stat-card modern-card h-100">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <div class="icon-container-sm">
                                                <i class="fas fa-cube text-white"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <div class="fw-bold h4 mb-0 text-gradient">' . number_format($stats['items']) . '</div>
                                            <div class="text-muted small">Total Items</div>
                                        </div>
                                        <div class="drag-handle d-none">
                                            <i class="fas fa-grip-vertical"></i>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>'
            ],
            'stat-customers' => [
                'visible' => isCardVisible('stat-customers'),
                'html' => '
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                        <div class="dashboard-card h-100" data-card-id="stat-customers">
                            <a href="/entities/customers/list.php" class="text-decoration-none" onclick="if(window.isEditMode){event.preventDefault();return false;}">
                                <div class="card stat-card modern-card h-100">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <div class="icon-container-sm icon-container-success">
                                                <i class="fas fa-users text-white"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <div class="fw-bold h4 mb-0 text-gradient">' . number_format($stats['customers']) . '</div>
                                            <div class="text-muted small">Total Customers</div>
                                        </div>
                                        <div class="drag-handle d-none">
                                            <i class="fas fa-grip-vertical"></i>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>'
            ],
            'stat-orders' => [
                'visible' => isCardVisible('stat-orders'),
                'html' => '
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                        <div class="dashboard-card h-100" data-card-id="stat-orders">
                            <a href="/entities/sales/orders_list.php" class="text-decoration-none" onclick="if(window.isEditMode){event.preventDefault();return false;}">
                                <div class="card stat-card modern-card h-100">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <div class="icon-container-sm icon-container-info">
                                                <i class="fas fa-shopping-cart text-white"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <div class="fw-bold h4 mb-0 text-gradient">' . number_format($stats['orders']) . '</div>
                                            <div class="text-muted small">Total Orders</div>
                                        </div>
                                        <div class="drag-handle d-none">
                                            <i class="fas fa-grip-vertical"></i>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>'
            ],
            'stat-vendors' => [
                'visible' => isCardVisible('stat-vendors'),
                'html' => '
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                        <div class="dashboard-card h-100" data-card-id="stat-vendors">
                            <a href="/entities/vendors/list.php" class="text-decoration-none" onclick="if(window.isEditMode){event.preventDefault();return false;}">
                                <div class="card stat-card modern-card h-100">
                                    <div class="card-body d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <div class="icon-container-sm icon-container-warning">
                                                <i class="fas fa-truck text-white"></i>
                                            </div>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <div class="fw-bold h4 mb-0 text-gradient">' . number_format($stats['vendors']) . '</div>
                                            <div class="text-muted small">Total Vendors</div>
                                        </div>
                                        <div class="drag-handle d-none">
                                            <i class="fas fa-grip-vertical"></i>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>'
            ]
        ];
        
        // Row 2: Business Metrics Cards (3 cards + 1 empty slot)
        $batchLink = $stockRequirements['batch_id'] 
            ? "/entities/batches/batch.php?id=" . $stockRequirements['batch_id']
            : "/entities/batches/list.php";
        $batchText = $stockRequirements['batch_id'] ? "View Batch" : "View Batches";
        
        $row2Cards = [
            'metric-orders-today' => [
                'visible' => isCardVisible('metric-orders-today'),
                'html' => '
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                        <div class="dashboard-card h-100" data-card-id="metric-orders-today">
                            <div class="card metric-card modern-card h-100">
                                <div class="card-body text-center">
                                    <div class="mb-3">
                                        <div class="icon-container-md icon-container-success">
                                            <i class="fas fa-calendar-day text-white h4 mb-0"></i>
                                        </div>
                                    </div>
                                    <h5 class="card-title">Orders Today</h5>
                                    <p class="card-text display-6 fw-bold text-success">' . number_format($activity['orders_today']) . '</p>
                                    <a href="/entities/sales/orders_list.php?filter=today" class="btn btn-modern btn-outline-success">View Today\'s Orders</a>
                                    <div class="drag-handle d-none">
                                        <i class="fas fa-grip-vertical"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>'
            ],
            'metric-pending-orders' => [
                'visible' => isCardVisible('metric-pending-orders'),
                'html' => '
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                        <div class="dashboard-card h-100" data-card-id="metric-pending-orders">
                            <div class="card metric-card modern-card h-100">
                                <div class="card-body text-center">
                                    <div class="mb-3">
                                        <div class="icon-container-md icon-container-warning">
                                            <i class="fas fa-clock text-white h4 mb-0"></i>
                                        </div>
                                    </div>
                                    <h5 class="card-title">Pending Orders</h5>
                                    <p class="card-text display-6 fw-bold text-warning">' . number_format($activity['pending_orders']) . '</p>
                                    <a href="/entities/sales/orders_list.php?filter=pending" class="btn btn-modern btn-outline-warning">View Pending</a>
                                    <div class="drag-handle d-none">
                                        <i class="fas fa-grip-vertical"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>'
            ],
            'metric-current-batch' => [
                'visible' => isCardVisible('metric-current-batch'),
                'html' => '
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                        <div class="dashboard-card h-100" data-card-id="metric-current-batch">
                            <div class="card metric-card modern-card h-100">
                                <div class="card-body text-center">
                                    <div class="mb-3">
                                        <div class="icon-container-md">
                                            <i class="fas fa-boxes text-white h4 mb-0"></i>
                                        </div>
                                    </div>
                                    <h5 class="card-title">Current Batch</h5>
                                    <p class="card-text display-6 fw-bold text-primary">' . format_currency($activity['current_batch_total']) . '</p>
                                    <a href="' . $batchLink . '" class="btn btn-modern btn-outline-primary">' . $batchText . '</a>
                                    <div class="drag-handle d-none">
                                        <i class="fas fa-grip-vertical"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>'
            ],
            'empty-slot-1' => [
                'visible' => false,
                'html' => '<div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3"><div class="dashboard-card-placeholder"></div></div>'
            ]
        ];
        
        // Row 3: Financial Metrics Cards (3 cards + 1 empty slot)
        $stockDisplay = count($stockRequirements['items']) > 0 
            ? '<p class="card-text display-6 fw-bold text-warning">' . count($stockRequirements['items']) . '</p>
               <button class="btn btn-outline-secondary btn-sm" id="view-stock-requirements">View All</button>'
            : '<p class="card-text display-6 fw-bold text-success">0</p>
               <span class="text-muted small">All items in stock!</span>';
        
        $row3Cards = [
            'financial-receivables' => [
                'visible' => isCardVisible('financial-receivables'),
                'html' => '
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                        <div class="dashboard-card h-100" data-card-id="financial-receivables">
                            <div class="card metric-card modern-card h-100">
                                <div class="card-body text-center">
                                    <div class="mb-3">
                                        <div class="icon-container-md icon-container-info">
                                            <i class="fas fa-money-bill-wave text-white h4 mb-0"></i>
                                        </div>
                                    </div>
                                    <h5 class="card-title">Total Receivables</h5>
                                    <p class="card-text display-6 fw-bold text-info">' . format_currency($activity['total_receivables']) . '</p>
                                    <a href="/entities/sales/orders_list.php?filter=unpaid" class="btn btn-modern btn-outline-info">View Unpaid</a>
                                    <div class="drag-handle d-none">
                                        <i class="fas fa-grip-vertical"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>'
            ],
            'financial-payables' => [
                'visible' => isCardVisible('financial-payables'),
                'html' => '
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                        <div class="dashboard-card h-100" data-card-id="financial-payables">
                            <div class="card metric-card modern-card h-100">
                                <div class="card-body text-center">
                                    <div class="mb-3">
                                        <div class="icon-container-md icon-container-danger">
                                            <i class="fas fa-file-invoice-dollar text-white h4 mb-0"></i>
                                        </div>
                                    </div>
                                    <h5 class="card-title">Total Payables</h5>
                                    <p class="card-text display-6 fw-bold text-danger">' . format_currency($activity['total_payables']) . '</p>
                                    <a href="/entities/purchases/list.php" class="btn btn-modern btn-outline-danger">View Payables</a>
                                    <div class="drag-handle d-none">
                                        <i class="fas fa-grip-vertical"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>'
            ],
            'financial-stock-required' => [
                'visible' => isCardVisible('financial-stock-required'),
                'html' => '
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                        <div class="dashboard-card h-100" data-card-id="financial-stock-required">
                            <div class="card metric-card modern-card h-100">
                                <div class="card-body">
                                    <div class="text-center mb-3">
                                        <div class="icon-container-md bg-secondary">
                                            <i class="fas fa-list-alt text-white h4 mb-0"></i>
                                        </div>
                                    </div>
                                    <h5 class="card-title text-center">Stock Required</h5>
                                    <div class="text-center">
                                        ' . $stockDisplay . '
                                    </div>
                                    <div class="drag-handle d-none">
                                        <i class="fas fa-grip-vertical"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>'
            ],
            'empty-slot-2' => [
                'visible' => false,
                'html' => '<div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3"><div class="dashboard-card-placeholder"></div></div>'
            ]
        ];
        
        // Row 4: Module Cards (10 cards in multiple sub-rows)
        $moduleCards = [];
        $moduleOrder = 1;
        foreach ($entities as $entity) {
            $cardId = 'module-' . strtolower(str_replace(' ', '-', $entity['name']));
            $moduleCards[$cardId] = [
                'visible' => isCardVisible($cardId),
                'html' => '
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-3">
                        <div class="dashboard-card h-100" data-card-id="' . $cardId . '">
                            <a href="' . h($entity['url']) . '" class="text-decoration-none">
                                <div class="card module-card modern-card h-100">
                                    <div class="card-body d-flex flex-column">
                                        <div class="d-flex align-items-center mb-3">
                                            <div class="flex-shrink-0">
                                                <i class="' . h($entity['icon']) . ' h3 mb-0 text-primary"></i>
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h5 class="card-title mb-0">' . h($entity['name']) . '</h5>
                                            </div>
                                            ' . ($entity['url'] === '/entities/reports/index.php' ? '<span class="badge bg-success rounded-pill">New</span>' : '') . '
                                        </div>
                                        <p class="card-text text-muted small flex-grow-1">' . h($entity['desc']) . '</p>
                                        <div class="drag-handle d-none">
                                            <i class="fas fa-grip-vertical"></i>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>'
            ];
            $moduleOrder++;
        }
        
        // Split module cards into rows of 4
        $moduleRows = array_chunk($moduleCards, 4, true);
        
        // Row 5: Analytics Dashboard (full width) - Inventory Closing removed
        $analyticsRow = [
            'analytics-dashboard' => [
                'visible' => isCardVisible('analytics-dashboard'),
                'html' => '
                    <div class="col-12 mb-4">
                        <div class="dashboard-card h-100" data-card-id="analytics-dashboard">
                            <div class="card analytics-card modern-card">
                                <div class="card-header">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h5 class="mb-0">
                                            <i class="fas fa-chart-pie me-2 text-gradient"></i>Business Analytics Dashboard
                                        </h5>
                                        <div class="d-flex align-items-center">
                                            <a href="/entities/reports/index.php" class="btn btn-modern btn-outline-primary btn-sm me-2">
                                                <i class="fas fa-external-link-alt me-1"></i>All Reports
                                            </a>
                                            <div class="drag-handle d-none">
                                                <i class="fas fa-grip-vertical"></i>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row" id="business-analytics-content">
                                        <!-- Analytics widgets will be loaded here -->
                                        <div class="col-12 text-center py-4">
                                            <div class="loading-shimmer border-radius-modern p-4">
                                                <i class="fas fa-spinner fa-spin me-2 text-primary"></i>
                                                <span class="text-muted">Loading comprehensive analytics...</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>'
            ]
        ];
        
        // Combine all rows
        $allRows = [
            ['id' => 'stats-row', 'title' => 'Statistics', 'cards' => $row1Cards],
            ['id' => 'business-row', 'title' => 'Business Metrics', 'cards' => $row2Cards],
            ['id' => 'financial-row', 'title' => 'Financial Metrics', 'cards' => $row3Cards]
        ];
        
        // Add module rows
        foreach ($moduleRows as $index => $moduleRow) {
            $allRows[] = ['id' => 'modules-row-' . ($index + 1), 'title' => 'Business Modules ' . ($index + 1), 'cards' => $moduleRow];
        }
        
        // Add analytics row
        $allRows[] = ['id' => 'analytics-row', 'title' => 'Analytics', 'cards' => $analyticsRow];
        
        // Output all rows
        foreach ($allRows as $row) {
            echo '<div class="dashboard-row mb-4" data-row-id="' . $row['id'] . '">';
            echo '<div class="row-drag-handle d-none align-items-center mb-2" style="display: none !important;">';
            echo '<i class="fas fa-grip-horizontal me-2"></i>';
            echo '<small class="text-muted">' . $row['title'] . ' Row</small>';
            echo '</div>';
            echo '<div class="row dashboard-row-content" data-row-content="' . $row['id'] . '">';
            
            foreach ($row['cards'] as $cardId => $card) {
                echo createCardHtml($cardId, $card['html'], $card['visible']);
            }
            
            echo '</div>';
            echo '</div>';
        }
        ?>
    </div>
    </div>
</div>

<?php
// Include the reusable order modal component
include_once __DIR__ . '/includes/order_modal.php';
?>

<script src="/entities/sales/js/order_form.js"></script>
<script src="/assets/js/dashboard.js"></script>

<?php include __DIR__ . '/includes/footer.php'; ?>