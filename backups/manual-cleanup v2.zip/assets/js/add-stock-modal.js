/**
 * Unified Add Stock Modal Logic (Slim Version)
 * --------------------------------------------
 * Relies on /assets/js/unified-modals.js for:
 *  - Consistent show/hide (UnifiedModals.show / UnifiedModals.hide)
 *  - Static backdrop + ESC handling
 *  - Generic form reset on hide
 *
 * This file now ONLY provides:
 *  - Config & state
 *  - Item list population (TomSelect support)
 *  - Negative quantity comment toggle
 *  - Validation & POST submission
 *  - Success feedback + optional reload
 *
 * Exposed API: window.AddStockModal.open()
 */

(function (window, $) {
    'use strict';
    if (!window) return;

    const defaultConfig = {
        modalId: 'add-stock-modal',
        formId: 'add-stock-form',
        itemSelectId: 'stock-item-select',
        qtyInputId: 'stock-qty',
        commentRowId: 'stock-comment-row',
        commentInputId: 'stock-comment',
        feedbackId: 'add-stock-feedback',

        postEndpoint: null, // auto-infer if null
        itemsListEndpoint: '/entities/items/items_list.php',
        actionName: 'add_stock',

        reloadOnSuccess: true,
        successHideDelay: 600
    };

    const externalCfg = window.AddStockModalConfig || {};
    const cfg = Object.assign({}, defaultConfig, externalCfg);

    let initialized = false;
    let loadingItems = false;

    function el(id) { return document.getElementById(id); }

    function inferPostEndpoint() {
        if (cfg.postEndpoint) return cfg.postEndpoint;
        if (window.location.pathname.includes('/entities/inventory/')) {
            return 'actions.php';
        }
        return '/entities/inventory/actions.php';
    }

    function toggleCommentRow(show) {
        const row = el(cfg.commentRowId);
        const input = el(cfg.commentInputId);
        if (!row) return;
        if (show) {
            row.classList.remove('d-none-important');
            row.style.display = '';
            if (input) input.setAttribute('required', 'required');
        } else {
            row.style.display = 'none';
            row.classList.add('d-none-important');
            if (input) input && input.removeAttribute('required');
        }
    }

    function clearFeedback() {
        const fb = el(cfg.feedbackId);
        if (!fb) return;
        fb.className = 'alert d-none-important';
        fb.style.display = 'none';
        fb.textContent = '';
    }

    function showFeedback(msg, ok) {
        const fb = el(cfg.feedbackId);
        if (!fb) return;
        fb.classList.remove('d-none-important');
        fb.style.display = '';
        fb.className = 'alert ' + (ok ? 'alert-success' : 'alert-danger');
        fb.textContent = msg;
    }

    function destroyTomSelect(selectEl) {
        if (selectEl && selectEl.tomselect) {
            try { selectEl.tomselect.destroy(); } catch(e){ /* noop */ }
        }
    }

    function initTomSelect(selectEl) {
        if (!selectEl || typeof TomSelect === 'undefined') return;
        new TomSelect(selectEl, { create: false, sortField: 'text' });
    }

    function loadItems() {
        if (loadingItems) return;
        const selectEl = el(cfg.itemSelectId);
        if (!selectEl) return;

        loadingItems = true;
        destroyTomSelect(selectEl);
        selectEl.innerHTML = '<option value="">Loading...</option>';

        $.getJSON(cfg.itemsListEndpoint, function(items){
            selectEl.innerHTML = '<option value="">Select Item</option>';
            items.forEach(it => {
                const opt = document.createElement('option');
                opt.value = it.id;
                opt.textContent = it.name;
                selectEl.appendChild(opt);
            });
            initTomSelect(selectEl);
        }).fail(xhr => {
            console.error('Items load failed', xhr.status);
            selectEl.innerHTML = '<option value="">Error loading items</option>';
        }).always(() => loadingItems = false);
    }

    function validate(itemId, qtyVal, commentVal) {
        if (!itemId || qtyVal === '' || isNaN(qtyVal) || parseFloat(qtyVal) === 0) {
            return 'Please select an item and enter a non-zero quantity.';
        }
        if (parseFloat(qtyVal) < 0 && (!commentVal || commentVal.trim() === '')) {
            return 'Please enter a comment for negative stock (reconciliation).';
        }
        return null;
    }

    function resetForm() {
        const form = el(cfg.formId);
        if (form) form.reset();
        toggleCommentRow(false);
        clearFeedback();
        const selectEl = el(cfg.itemSelectId);
        destroyTomSelect(selectEl); // force re-population each open
    }

    function submit(e) {
        if (e) e.preventDefault();
        const itemId = $('#' + cfg.itemSelectId).val();
        const qty = $('#' + cfg.qtyInputId).val();
        const comment = $('#' + cfg.commentInputId).val();

        const err = validate(itemId, qty, comment);
        if (err) { showFeedback(err, false); return; }

        const endpoint = inferPostEndpoint();
        clearFeedback();

        $.post(endpoint, {
            action: cfg.actionName,
            item_id: itemId,
            qty: qty,
            comment: comment
        }, function(resp){
            if (resp && resp.success) {
                showFeedback('Stock added successfully!', true);
                setTimeout(() => {
                    if (window.UnifiedModals) {
                        UnifiedModals.hide(cfg.modalId);
                    } else {
                        const modalEl = el(cfg.modalId);
                        if (modalEl) {
                            const inst = bootstrap.Modal.getInstance(modalEl);
                            if (inst) inst.hide();
                        }
                    }
                    if (cfg.reloadOnSuccess) {
                        window.location.reload();
                    } else {
                        resetForm();
                    }
                }, cfg.successHideDelay);
            } else {
                showFeedback((resp && resp.error) || 'Error adding stock!', false);
            }
        }, 'json').fail(xhr => {
            showFeedback('Server error (' + xhr.status + ').', false);
        });
    }

    function bindEvents() {
        // Negative qty comment toggle
        $(document).on('input change', '#' + cfg.qtyInputId, function(){
            const v = parseFloat(this.value);
            toggleCommentRow(!isNaN(v) && v < 0);
        });

        // Form submission
        $(document).on('submit', '#' + cfg.formId, submit);
    }

    function open() {
        const modalEl = el(cfg.modalId);
        if (!modalEl) {
            console.warn('[AddStockModal] Modal element #' + cfg.modalId + ' not found.');
            return;
        }
        resetForm();
        if (window.UnifiedModals) {
            UnifiedModals.show(modalEl);
        } else {
            (bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl, {
                backdrop:'static', keyboard:true
            })).show();
        }
        loadItems();
        setTimeout(() => {
            const selectEl = el(cfg.itemSelectId);
            if (selectEl) {
                if (selectEl.tomselect) selectEl.tomselect.focus();
                else selectEl.focus();
            }
        }, 180);
    }

    function init() {
        if (initialized) return;
        initialized = true;
        bindEvents();
    }

    window.AddStockModal = {
        open,
        init,
        refreshItems: loadItems,
        reset: resetForm,
        config: cfg
    };

    $(init);

})(window, window.jQuery);