/**
 * Common Utilities for FrozoFun Admin
 * 
 * Provides reusable utilities to reduce code duplication:
 * - AJAX request handling with consistent error management
 * - Form validation utilities  
 * - Table selection and bulk operations
 * - Button handler patterns
 */

window.CommonUtils = {
    
    /**
     * Standard AJAX request handler with consistent error handling
     * @param {Object} options - Request configuration
     */
    request: function(options) {
        const defaults = {
            method: 'POST',
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            showLoading: true,
            loadingTarget: null
        };
        
        const config = Object.assign({}, defaults, options);
        
        // Show loading state if requested
        if (config.showLoading && config.loadingTarget) {
            this._showLoading(config.loadingTarget);
        }
        
        return fetch(config.url, {
            method: config.method,
            headers: config.headers,
            body: config.body
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            return response.json();
        })
        .then(data => {
            // Hide loading state
            if (config.showLoading && config.loadingTarget) {
                this._hideLoading(config.loadingTarget);
            }
            
            if (config.onSuccess) {
                config.onSuccess(data);
            }
            return data;
        })
        .catch(error => {
            // Hide loading state
            if (config.showLoading && config.loadingTarget) {
                this._hideLoading(config.loadingTarget);
            }
            
            const errorMessage = error.message || 'An error occurred';
            
            if (config.onError) {
                config.onError(errorMessage);
            } else {
                this.showError(errorMessage);
            }
            
            console.error('AJAX Request Error:', error);
            throw error;
        });
    },
    
    /**
     * Submit form via AJAX with standard handling
     * @param {HTMLFormElement} form - Form element
     * @param {Object} options - Additional options
     */
    submitForm: function(form, options = {}) {
        const defaults = {
            action: form.getAttribute('action') || 'actions.php',
            onSuccess: null,
            onError: null,
            refreshOnSuccess: true,
            showSuccessMessage: true
        };
        
        const config = Object.assign({}, defaults, options);
        const formData = new FormData(form);
        
        // Add action if not present
        if (!formData.has('action')) {
            const editing = form.getAttribute('data-editing') === '1';
            formData.append('action', editing ? 'edit' : 'add');
        }
        
        return this.request({
            url: config.action,
            method: 'POST',
            body: formData,
            loadingTarget: form,
            onSuccess: (data) => {
                if (data.success) {
                    if (config.showSuccessMessage) {
                        this.showSuccess(data.message || 'Operation completed successfully!');
                    }
                    
                    if (config.onSuccess) {
                        config.onSuccess(data);
                    } else if (config.refreshOnSuccess) {
                        setTimeout(() => location.reload(), 1000);
                    }
                } else {
                    this.showError(data.error || data.message || 'Operation failed');
                    if (config.onError) {
                        config.onError(data);
                    }
                }
            },
            onError: config.onError
        });
    },
    
    /**
     * Standard delete confirmation and action
     * @param {string} entityType - Type of entity (item, customer, etc.)
     * @param {string|number} id - Entity ID
     * @param {string} name - Entity name for confirmation
     * @param {Object} options - Additional options
     */
    confirmDelete: function(entityType, id, name, options = {}) {
        const defaults = {
            action: 'actions.php',
            confirmMessage: `Are you sure you want to delete this ${entityType}?`,
            successMessage: `${entityType} deleted successfully`,
            onSuccess: () => location.reload()
        };
        
        const config = Object.assign({}, defaults, options);
        
        if (!confirm(config.confirmMessage)) {
            return Promise.resolve(false);
        }
        
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', id);
        
        return this.request({
            url: config.action,
            method: 'POST',
            body: formData,
            onSuccess: (data) => {
                if (data.success) {
                    this.showSuccess(config.successMessage);
                    if (config.onSuccess) {
                        config.onSuccess(data);
                    }
                } else {
                    this.showError(data.error || 'Delete failed');
                }
            }
        });
    },
    
    /**
     * Table checkbox selection utilities
     */
    TableSelection: {
        /**
         * Initialize select-all functionality for a table
         * @param {string} tableSelector - Table selector
         * @param {string} selectAllSelector - Select all checkbox selector  
         * @param {string} rowCheckboxSelector - Row checkbox selector
         */
        init: function(tableSelector, selectAllSelector, rowCheckboxSelector) {
            const table = document.querySelector(tableSelector);
            if (!table) return;
            
            // Select all functionality
            const selectAllCheckbox = table.querySelector(selectAllSelector);
            if (selectAllCheckbox) {
                selectAllCheckbox.addEventListener('change', function() {
                    const rowCheckboxes = table.querySelectorAll(rowCheckboxSelector);
                    rowCheckboxes.forEach(cb => cb.checked = this.checked);
                });
            }
            
            // Individual checkbox functionality
            table.addEventListener('change', function(e) {
                if (e.target.matches(rowCheckboxSelector)) {
                    const allCheckboxes = table.querySelectorAll(rowCheckboxSelector);
                    const checkedCheckboxes = table.querySelectorAll(rowCheckboxSelector + ':checked');
                    
                    if (selectAllCheckbox) {
                        selectAllCheckbox.checked = allCheckboxes.length === checkedCheckboxes.length;
                    }
                }
            });
        },
        
        /**
         * Get selected row IDs
         * @param {string} tableSelector - Table selector
         * @param {string} rowCheckboxSelector - Row checkbox selector
         * @returns {Array} Array of selected IDs
         */
        getSelected: function(tableSelector, rowCheckboxSelector) {
            const table = document.querySelector(tableSelector);
            if (!table) return [];
            
            const checkedBoxes = table.querySelectorAll(rowCheckboxSelector + ':checked');
            return Array.from(checkedBoxes).map(cb => cb.value);
        },
        
        /**
         * Require at least one selection
         * @param {Array} selectedIds - Selected IDs array
         * @param {string} message - Error message if none selected
         * @returns {boolean} True if selection is valid
         */
        requireSelection: function(selectedIds, message = 'Please select at least one item') {
            if (!selectedIds.length) {
                CommonUtils.showError(message);
                return false;
            }
            return true;
        }
    },
    
    /**
     * Form validation utilities
     */
    Validation: {
        /**
         * Validate required fields
         * @param {HTMLFormElement} form - Form element
         * @returns {boolean} True if valid
         */
        validateRequired: function(form) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.classList.add('is-invalid');
                    isValid = false;
                } else {
                    field.classList.remove('is-invalid');
                }
            });
            
            return isValid;
        },
        
        /**
         * Validate email format
         * @param {string} email - Email to validate
         * @returns {boolean} True if valid
         */
        validateEmail: function(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        },
        
        /**
         * Normalize phone/contact number
         * @param {string} contact - Contact number
         * @returns {string} Normalized contact
         */
        normalizeContact: function(contact) {
            if (!contact) return '';
            
            // Remove all non-digit characters except +
            let normalized = contact.replace(/[^\d+]/g, '');
            
            // If starts with 0, replace with +92
            if (normalized.startsWith('0')) {
                normalized = '+92' + normalized.substr(1);
            }
            
            // If starts with 92 (without +), add +
            if (/^92\d{10}$/.test(normalized)) {
                normalized = '+' + normalized;
            }
            
            // If just digits and 11 chars starting with 3, add +92
            if (/^\d{11}$/.test(normalized) && normalized.startsWith('3')) {
                normalized = '+92' + normalized;
            }
            
            return normalized;
        }
    },
    
    /**
     * Show success message (uses existing notification system if available)
     * @param {string} message - Success message
     */
    showSuccess: function(message) {
        if (typeof showSuccess === 'function') {
            showSuccess(message);
        } else if (typeof toastr !== 'undefined') {
            toastr.success(message);
        } else {
            console.log('SUCCESS:', message);
            // Fallback to temporary alert element
            this._showAlert(message, 'success');
        }
    },
    
    /**
     * Show error message (uses existing notification system if available)
     * @param {string} message - Error message
     */
    showError: function(message) {
        if (typeof showError === 'function') {
            showError(message);
        } else if (typeof toastr !== 'undefined') {
            toastr.error(message);
        } else {
            console.error('ERROR:', message);
            // Fallback to temporary alert element
            this._showAlert(message, 'danger');
        }
    },
    
    /**
     * Private method to show loading state
     * @private
     */
    _showLoading: function(target) {
        if (typeof target === 'string') {
            target = document.querySelector(target);
        }
        
        if (target) {
            target.style.opacity = '0.6';
            target.style.pointerEvents = 'none';
        }
    },
    
    /**
     * Private method to hide loading state
     * @private
     */
    _hideLoading: function(target) {
        if (typeof target === 'string') {
            target = document.querySelector(target);
        }
        
        if (target) {
            target.style.opacity = '';
            target.style.pointerEvents = '';
        }
    },
    
    /**
     * Private method to show temporary alert
     * @private
     */
    _showAlert: function(message, type) {
        // Create temporary alert element
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        alert.style.cssText = 'top: 20px; right: 20px; z-index: 9999; max-width: 400px;';
        alert.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(alert);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (alert.parentNode) {
                alert.parentNode.removeChild(alert);
            }
        }, 5000);
    }
};

// Make utilities globally available for backward compatibility
window.submitForm = CommonUtils.submitForm.bind(CommonUtils);
window.confirmDelete = CommonUtils.confirmDelete.bind(CommonUtils);
window.safeAlert = CommonUtils.showError.bind(CommonUtils);

// Auto-initialize on DOM ready
document.addEventListener('DOMContentLoaded', function() {
    // Set up global error handling for fetch requests
    window.addEventListener('unhandledrejection', function(event) {
        console.error('Unhandled promise rejection:', event.reason);
    });
});