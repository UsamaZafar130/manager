/**
 * Unified Excess Stock Modal Logic (Slim Version)
 * -----------------------------------------------
 * Relies on /assets/js/unified-modals.js for consistent modal show/hide if available.
 *
 * Responsibilities kept here:
 *  - Fetch excess stock data
 *  - Render table (with optional DataTables)
 *  - Copy-to-clipboard
 *  - Inline feedback / loading states
 *
 * Exposed API:
 *    window.ExcessStockModal.open()
 *    window.ExcessStockModal.refresh()
 */

(function(window, $){
    'use strict';
    if (!window || !$) return;

    const cfg = window.ExcessStockModalConfig || {
        modalId: 'excess-stock-modal',
        loadingId: 'excess-stock-loading',
        containerId: 'excess-stock-table-container',
        feedbackId: 'excess-stock-feedback',
        copyBtnId: 'copy-excess-btn',
        endpoint: '/entities/inventory/actions.php',
        actionParam: 'get_excess_stock',
        useDataTable: true
    };

    function el(id){ return document.getElementById(id); }

    function setLoading(isLoading) {
        const l = el(cfg.loadingId);
        if (l) l.classList.toggle('d-none', !isLoading);
    }

    function clearFeedback() {
        const fb = el(cfg.feedbackId);
        if (!fb) return;
        fb.className = 'alert d-none';
        fb.textContent = '';
    }

    function showFeedback(msg, ok) {
        const fb = el(cfg.feedbackId);
        if (!fb) return;
        fb.classList.remove('d-none');
        fb.className = 'alert ' + (ok ? 'alert-success' : 'alert-danger');
        fb.textContent = msg;
    }

    function escapeHtml(str) {
        return $('<div>').text(str || '').html();
    }

    function renderTable(data) {
        if (!Array.isArray(data) || !data.length) {
            return '<div class="alert alert-warning mb-0">No items have excess stock!</div>';
        }
        let totalValue = 0;
        const rows = data.map(row => {
            const name = escapeHtml(row.name);
            const category = escapeHtml(row.category || 'Uncategorized');
            const manufactured = +parseFloat(row.manufactured || 0);
            const required = +parseFloat(row.required || 0);
            const excess = +parseFloat(row.excess || 0);
            const ppu = +parseFloat(row.price_per_unit || 0);
            const value = row.excess_value != null ? parseFloat(row.excess_value) : (excess * ppu);
            totalValue += value;
            return `<tr>
                <td>${name}</td>
                <td>${category}</td>
                <td>${manufactured.toFixed(2)}</td>
                <td>${required.toFixed(2)}</td>
                <td><span class="badge badge-surplus">+${excess.toFixed(2)}</span></td>
                <td>Rs. ${ppu.toFixed(2)}</td>
                <td><strong>Rs. ${value.toFixed(2)}</strong></td>
            </tr>`;
        }).join('');

        return `<table class="entity-table table table-striped table-hover" id="excess-stock-table">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Category</th>
                    <th>Manufactured</th>
                    <th>Required</th>
                    <th>Excess</th>
                    <th>Price/Unit</th>
                    <th>Excess Value</th>
                </tr>
            </thead>
            <tbody>${rows}</tbody>
            <tfoot>
                <tr class="table-success">
                    <th colspan="6" class="text-end">Total Excess Stock Value:</th>
                    <th><strong>Rs. ${totalValue.toFixed(2)}</strong></th>
                </tr>
            </tfoot>
        </table>`;
    }

    function fetchAndRender() {
        const container = el(cfg.containerId);
        if (!container) {
            console.warn('[ExcessStockModal] Container not found.');
            return;
        }
        clearFeedback();
        container.innerHTML = '';
        setLoading(true);

        $.getJSON(cfg.endpoint, { action: cfg.actionParam }, function(resp){
            setLoading(false);
            if (!resp || !resp.success) {
                showFeedback((resp && resp.error) || 'Failed to fetch excess stock.', false);
                return;
            }
            container.innerHTML = renderTable(resp.data || []);
            if (cfg.useDataTable && $.fn.DataTable && resp.data && resp.data.length) {
                if ($.fn.DataTable.isDataTable('#excess-stock-table')) {
                    $('#excess-stock-table').DataTable().destroy();
                }
                $('#excess-stock-table').DataTable({
                    responsive: true,
                    paging: false,
                    searching: true,
                    info: false,
                    ordering: true
                });
            }
        }).fail(xhr => {
            setLoading(false);
            showFeedback('Server error (' + xhr.status + ') while loading excess stock.', false);
        });
    }

    function copyList() {
        const $rows = $('#excess-stock-table tbody tr');
        if (!$rows.length) {
            alert('No excess items to copy!');
            return;
        }
        const lines = [];
        $rows.each(function(){
            const item = $(this).find('td').eq(0).text().trim();
            const excess = $(this).find('td').eq(4).text().replace('+','').trim();
            if (item && excess) lines.push(item + ': ' + excess);
        });
        if (!lines.length) {
            alert('No excess items to copy!');
            return;
        }
        const text = lines.join('\n');
        navigator.clipboard.writeText(text).then(
            () => alert('Copied to clipboard!\n\n' + text),
            () => alert('Failed to copy!')
        );
    }

    function open() {
        const modalEl = el(cfg.modalId);
        if (!modalEl) {
            console.warn('[ExcessStockModal] Modal element #' + cfg.modalId + ' not found.');
            return;
        }
        if (window.UnifiedModals) {
            UnifiedModals.show(modalEl);
        } else {
            (bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl, {
                backdrop:'static', keyboard:true
            })).show();
        }
        fetchAndRender();
    }

    function refresh() {
        fetchAndRender();
    }

    function bind() {
        $(document).on('click', '#' + cfg.copyBtnId, function(e){
            e.preventDefault();
            copyList();
        });
    }

    window.ExcessStockModal = {
        open,
        refresh,
        config: cfg
    };

    $(bind);

})(window, window.jQuery);