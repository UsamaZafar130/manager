/**
 * Floating Action Button JavaScript
 * Handles inventory shortcuts menu functionality globally across all pages.
 *
 * Refactors:
 *  - Unified Add Stock modal (add_stock_modal.php + /assets/js/add-stock-modal.js)
 *    => #show-add-stock calls window.AddStockModal.open()
 *  - Unified Excess Stock modal (excess_stock_modal.php + /assets/js/excess-stock-modal.js)
 *    => #show-excess-stock calls window.ExcessStockModal.open()
 *
 * Removed:
 *  - Legacy floating Add Stock modal creation & submission logic
 *  - Inline Excess Stock AJAX/table-building & copy handlers (handled by ExcessStockModal module)
 */

$(document).on('keydown', function(e) {
    // If order modal is open, use order-specific shortcuts
    if ($('#orderModal').hasClass('show') || $('#orderModal').is(':visible')) {

        // Ctrl+Alt+C - focus customer
        if (e.ctrlKey && e.altKey && e.key === 'c') {
            e.preventDefault();
            const customerSelect = $('#customer-select');
            if (customerSelect.length && customerSelect[0].tomselect) {
                customerSelect[0].tomselect.focus();
            }
            return;
        }

        // Ctrl+Alt+I - focus empty item dropdown or add row
        if (e.ctrlKey && e.altKey && e.key === 'i') {
            e.preventDefault();
            const emptyItemSelect = $('#items-table tbody tr')
                .find('.item-select')
                .filter(function() { return !$(this).val(); })
                .first();
            if (emptyItemSelect.length && emptyItemSelect[0].tomselect) {
                emptyItemSelect[0].tomselect.focus();
            } else {
                $('#add-row').trigger('click');
            }
            return;
        }

        // Ctrl+Alt+M - focus empty meal dropdown or add meal row
        if (e.ctrlKey && e.altKey && e.key === 'm') {
            e.preventDefault();
            const emptyMealSelect = $('#meals-table tbody tr')
                .find('.meal-select')
                .filter(function() { return !$(this).val(); })
                .first();
            if (emptyMealSelect.length && emptyMealSelect[0].tomselect) {
                emptyMealSelect[0].tomselect.focus();
            } else {
                $('#add-meal-row').trigger('click');
            }
            return;
        }

        // Ctrl+Alt+1..9 - focus specific item rows
        if (e.ctrlKey && e.altKey && /^[1-9]$/.test(e.key)) {
            e.preventDefault();
            const rowIndex = parseInt(e.key) - 1;
            const itemRows = $('#items-table tbody tr');
            if (rowIndex < itemRows.length) {
                const itemSelect = itemRows.eq(rowIndex).find('.item-select');
                if (itemSelect.length && itemSelect[0].tomselect) {
                    itemSelect[0].tomselect.focus();
                }
            }
            return;
        }

        // Ctrl+Alt+Shift+1..9 - focus specific meal rows
        if (e.ctrlKey && e.altKey && e.shiftKey && /^[1-9]$/.test(e.key)) {
            e.preventDefault();
            const rowIndex = parseInt(e.key) - 1;
            const mealRows = $('#meals-table tbody tr');
            if (rowIndex < mealRows.length) {
                const mealSelect = mealRows.eq(rowIndex).find('.meal-select');
                if (mealSelect.length && mealSelect[0].tomselect) {
                    mealSelect[0].tomselect.focus();
                }
            }
            return;
        }

        return; // Stop global shortcuts while in order modal
    }

    // Global floating menu shortcuts

    // Ctrl+Alt+F - toggle floating menu
    if (e.ctrlKey && e.altKey && e.key === 'f') {
        e.preventDefault();
        if ($('#floating-inventory-btn').length) {
            $('#floating-inventory-btn').trigger('click');
        }
        return;
    }

    // Ctrl+Alt+1..9 - mapped actions
    if (e.ctrlKey && e.altKey && ['1','2','3','4','5','6','7','8','9'].includes(e.key)) {
        e.preventDefault();
        const actionMap = {
            '1': '#show-stock-required',
            '2': '#show-excess-stock',
            '3': '#show-add-stock',
            '4': '#show-add-order',
            '5': '#show-scan-packs',
            '6': '#show-add-customer',
            '7': '#show-add-purchase',
            '8': '#show-add-expense',
            '9': '#show-current-batch'
        };
        const target = actionMap[e.key];
        if (target && $(target).length) {
            if ($('#floating-inventory-actions').is(':visible')) {
                $('#floating-inventory-actions').hide();
            }
            $(target).trigger('click');
        }
        return;
    }
});

$(function(){
    if (!$('#floating-inventory-btn').length) return;

    let actionsVisible = false;

    // Toggle panel
    $('#floating-inventory-btn').on('click', function(e){
        e.preventDefault();
        actionsVisible = !actionsVisible;
        $('#floating-inventory-actions').toggle(actionsVisible);
    });

    // Click-away hide
    $(document).on('mousedown touchstart', function(e){
        if (!$(e.target).closest('#floating-inventory-btn, #floating-inventory-actions').length) {
            $('#floating-inventory-actions').hide();
            actionsVisible = false;
        }
    });

    // Stock Requirements glimpse modal
    $('#show-stock-required, #view-stock-requirements').on('click', function(){
        $('#floating-inventory-actions').hide();
        actionsVisible = false;

        if (window.location.pathname.includes('stock_requirements.php')) {
            window.scrollTo(0, 0);
            return;
        }

        const modalEl = document.getElementById('floating-inventory-modal');
        if (!modalEl) return;
        const modal = new bootstrap.Modal(modalEl, { backdrop: 'static', keyboard: true });
        modal.show();

        $('#floating-inventory-modal-body').html(
            '<div class="text-center p-4"><i class="fa fa-spinner fa-spin me-2"></i>Loading stock requirements...</div>'
        );

        $.get('/entities/batches/api_upcoming_batch_stock_glimpse.php', function(html){
            $('#floating-inventory-modal-body').html(html);
        });
    });

    // Excess Stock (unified)
    $('#show-excess-stock').on('click', function(){
        $('#floating-inventory-actions').hide();
        actionsVisible = false;

        if (window.ExcessStockModal && typeof window.ExcessStockModal.open === 'function') {
            window.ExcessStockModal.open();
            return;
        }
        // Fallback: trigger page button if available
        if ($('#btn-excess-stock').length) {
            $('#btn-excess-stock').trigger('click');
            return;
        }
        console.warn('[Floating Shortcuts] ExcessStockModal not available.');
    });

    // Add Stock (unified)
    $('#show-add-stock').on('click', function(){
        $('#floating-inventory-actions').hide();
        actionsVisible = false;

        if (window.AddStockModal && typeof window.AddStockModal.open === 'function') {
            window.AddStockModal.open();
            return;
        }
        if ($('#btn-add-stock').length) {
            $('#btn-add-stock').trigger('click');
            return;
        }
        console.warn('[Floating Shortcuts] AddStockModal not available and no page button found.');
    });

    // Add New Order
    $('#show-add-order').on('click', function(e){
        e.preventDefault();
        $('#floating-inventory-actions').hide(); actionsVisible = false;
        if (typeof window.showOrderModal === 'function') {
            showOrderModal();
        } else {
            window.location.href = '/entities/sales/new_order.php';
        }
    });

    // Add Customer
    $('#show-add-customer').on('click', function(e){
        e.preventDefault();
        $('#floating-inventory-actions').hide(); actionsVisible = false;
        if (typeof window.showCustomerModal === 'function') {
            showCustomerModal();
        } else {
            window.location.href = '/entities/customers/list.php';
        }
    });

    // Add Purchase
    $('#show-add-purchase').on('click', function(e){
        e.preventDefault();
        $('#floating-inventory-actions').hide(); actionsVisible = false;
        if (typeof window.showPurchaseModal === 'function') {
            const existing = document.querySelector('.modal.show');
            if (existing) {
                const inst = bootstrap.Modal.getInstance(existing);
                if (inst) inst.hide();
            }
            showPurchaseModal();
        } else {
            window.location.href = '/entities/purchases/list.php';
        }
    });

    // Add Expense
    $('#show-add-expense').on('click', function(e){
        e.preventDefault();
        $('#floating-inventory-actions').hide(); actionsVisible = false;
        if (typeof window.showExpenseModal === 'function') {
            const existing = document.querySelector('.modal.show');
            if (existing) {
                const inst = bootstrap.Modal.getInstance(existing);
                if (inst) inst.hide();
            }
            showExpenseModal();
        } else {
            window.location.href = '/entities/expenses/list.php';
        }
    });

    // Current Batch
    $('#show-current-batch').on('click', function(e){
        e.preventDefault();
        $('#floating-inventory-actions').hide(); actionsVisible = false;

        $.ajax({
            url: '/api/get_current_batch.php',
            method: 'GET',
            dataType: 'json',
            success: function(resp) {
                if (resp.success && resp.batch_id) {
                    window.open('/entities/batches/batch.php?id=' + resp.batch_id, '_blank');
                } else {
                    window.open('/entities/batches/list.php', '_blank');
                }
            },
            error: function() {
                window.open('/entities/batches/list.php', '_blank');
            }
        });
    });
});