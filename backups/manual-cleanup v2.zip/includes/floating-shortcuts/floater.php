<?php
/**
 * Floating Action Button for Inventory Shortcuts
 * Updated to use unified modal partials:
 *   - /entities/inventory/add_stock_modal.php
 *   - /entities/inventory/excess_stock_modal.php
 * And unified JS controllers:
 *   - /assets/js/add-stock-modal.js
 *   - /assets/js/excess-stock-modal.js
 *
 * Removed legacy inline injection for the excess stock modal.
 */
?>

<!-- Floating Action Button & Actions Menu -->
<button id="floating-inventory-btn" title="Inventory Shortcuts (CTRL + ALT + F)">
    <i class="fa fa-cubes"></i>
</button>
<div id="floating-inventory-actions" style="display:none;">
    <div class="floating-actions-menu">
        <button class="floating-action-item" id="show-stock-required" title="CTRL + ALT + 1">
            <i class="fa fa-list-alt"></i> Show Stock Required :1
        </button>
        <button class="floating-action-item" id="show-excess-stock" title="CTRL + ALT + 2">
            <i class="fa fa-boxes"></i> Show Excess Stock :2
        </button>
        <button class="floating-action-item" id="show-add-stock" title="CTRL + ALT + 3">
            <i class="fa fa-plus"></i> Add Stock :3
        </button>
        <button class="floating-action-item" id="show-add-order" title="CTRL + ALT + 4">
            <i class="fa fa-shopping-cart"></i> Add New Order :4
        </button>
        <a class="floating-action-item" id="show-scan-packs" href="/entities/inventory/packing_scan.php" target="_blank" title="CTRL + ALT + 5">
            <i class="fa fa-barcode"></i> Scan Packs :5
        </a>
        <button class="floating-action-item" id="show-add-customer" title="CTRL + ALT + 6">
            <i class="fa fa-user-plus"></i> Add Customer :6
        </button>
        <button class="floating-action-item" id="show-add-purchase" title="CTRL + ALT + 7">
            <i class="fa fa-shopping-cart"></i> Add Purchase :7
        </button>
        <button class="floating-action-item" id="show-add-expense" title="CTRL + ALT + 8">
            <i class="fa fa-credit-card"></i> Add Expense :8
        </button>
        <button class="floating-action-item" id="show-current-batch" title="CTRL + ALT + 9">
            <i class="fa fa-boxes"></i> Current Batch :9
        </button>
    </div>
</div>

<!-- Floating Stock Requirements Glimpse Modal -->
<div class="modal fade" id="floating-inventory-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="stockRequirementsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="stockRequirementsModalLabel">
                    <i class="fa fa-list-alt me-2"></i>Stock Requirements
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="floating-inventory-modal-body">
                <div class="text-center p-4">
                    <i class="fa fa-spinner fa-spin me-2"></i>Loading stock requirements...
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include unified Add Stock modal once
if (!isset($GLOBALS['__ADD_STOCK_MODAL_INCLUDED__'])) {
    $GLOBALS['__ADD_STOCK_MODAL_INCLUDED__'] = true;
    include_once __DIR__ . '/../../entities/inventory/add_stock_modal.php';
}

// Include unified Excess Stock modal once
if (!isset($GLOBALS['__EXCESS_STOCK_MODAL_INCLUDED__'])) {
    $GLOBALS['__EXCESS_STOCK_MODAL_INCLUDED__'] = true;
    include_once __DIR__ . '/../../entities/inventory/excess_stock_modal.php';
}

// Reusable other modals (only if they exist)
$modalIncludes = [
    '/../order_modal.php',
    '/../customer_modal.php',
    '/../purchase_modal.php',
    '/../expense_modal.php'
];
foreach ($modalIncludes as $inc) {
    $path = __DIR__ . $inc;
    if (file_exists($path)) {
        include_once $path;
    }
}
?>

<!-- Unified modal controllers (guard load if not already present) -->
<script>
(function(){
    if (!window.AddStockModal) {
        const s1 = document.createElement('script');
        s1.src = '/assets/js/add-stock-modal.js';
        document.head.appendChild(s1);
    }
    if (!window.ExcessStockModal) {
        const s2 = document.createElement('script');
        s2.src = '/../../assets/js/excess-stock-modal.js';
        document.head.appendChild(s2);
    }
})();
</script>

<!-- Floater behavior -->
<script src="/includes/floating-shortcuts/floater.js"></script>