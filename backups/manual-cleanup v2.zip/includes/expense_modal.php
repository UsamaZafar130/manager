<?php
// Reusable Expense Modal Component
// This can be included in any page that needs the Add/Edit Expense modal functionality
?>

<!-- Expense Modal (add/edit expense) -->
<div class="modal fade" id="globalExpenseModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="globalExpenseModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="globalExpenseModalLabel">New Expense</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="global-expense-modal-body">
                <div class="text-center p-4">Loading form...</div>
            </div>
        </div>
    </div>
</div>

<script>
// Global function to show the expense modal (reusable across pages)
// Only define if not already defined (to avoid conflicts)
if (typeof window.showExpenseModal === 'undefined') {
    window.showExpenseModal = function(expenseId = null) {
        // If a page exposes its own ExpenseUI, defer to it
        if (typeof window.ExpenseUI !== 'undefined' && typeof ExpenseUI.openAddModal === 'function') {
            if (expenseId && typeof ExpenseUI.openEditModal === 'function') {
                ExpenseUI.openEditModal(expenseId);
            } else {
                ExpenseUI.openAddModal();
            }
            return;
        }

        const modalId = 'globalExpenseModal';
        const modal = document.getElementById(modalId);
        const modalTitle = document.getElementById('globalExpenseModalLabel');
        const modalBody = document.getElementById('global-expense-modal-body');

        if (!modal || !modalTitle || !modalBody) {
            console.error('Expense modal elements not found');
            return;
        }

        // Set title and loading state
        modalTitle.textContent = expenseId ? 'Edit Expense' : 'New Expense';
        modalBody.innerHTML = '<div class="text-center p-4">Loading form...</div>';

        // Build URL for the expense form
        let url = '/entities/expenses/form.php';
        if (expenseId) url += '?id=' + encodeURIComponent(expenseId);

        // Use UnifiedModals for consistent behavior
        window.UnifiedModals.loadAndShow(modalId, url, {
            onLoaded: function(modalEl, bsModal) {
                if (typeof window.initExpenseFormJS === 'function') {
                    window.initExpenseFormJS(expenseId ? { expense_id: parseInt(expenseId, 10) } : null);
                }
            }
        });
    };
}
</script>