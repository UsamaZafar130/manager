<?php
/**
 * Canonical Excess Stock Modal
 * ------------------------------------------------------------------
 * Include this partial ONCE per request wherever the Excess Stock
 * feature is needed (inventory list, stock requirements, floater, etc).
 *
 * Logic for fetching / rendering lives in: /assets/js/excess-stock-modal.js
 * This file only supplies the static Bootstrap modal structure + target
 * container elements referenced by the JS module.
 *
 * IDs used by JS:
 *   excess-stock-modal            (modal root)
 *   excess-stock-loading          (loading spinner container)
 *   excess-stock-feedback         (alert area for errors / messages)
 *   excess-stock-table-container  (injection point for rendered table)
 *   copy-excess-btn               (copy list button)
 */
?>
<div class="modal fade" id="excess-stock-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="excessStockModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mb-0" id="excessStockModalLabel">
                    <i class="fa fa-boxes me-2"></i>Excess Stock (Surplus Items)
                </h5>
                <button type="button"
                        class="btn btn-outline-secondary btn-sm ms-auto me-2"
                        id="copy-excess-btn"
                        title="Copy Excess List">
                    <i class="fa fa-copy me-1"></i>Copy
                </button>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Loading Indicator -->
                <div id="excess-stock-loading" class="text-center p-4 d-none">
                    <i class="fa fa-spinner fa-spin me-2"></i>Loading...
                </div>

                <!-- Feedback / Errors -->
                <div id="excess-stock-feedback" class="alert d-none mb-3"></div>

                <!-- Table Injection Point -->
                <div id="excess-stock-table-container"></div>
            </div>
        </div>
    </div>
</div>