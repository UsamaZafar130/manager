<?php
/**
 * Canonical Add Stock Modal (shared across inventory pages & floating shortcuts trigger)
 * Ensure only ONE copy of this file is included globally to prevent duplicate IDs.
 */
?>
<div class="modal fade" id="add-stock-modal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="addStockModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addStockModalLabel">
                    <i class="fa fa-plus me-2"></i>Add Stock
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="add-stock-form" class="entity-form">
                    <div class="mb-3">
                        <label for="stock-item-select" class="form-label">Item</label>
                        <select id="stock-item-select" name="item_id" class="form-control tom-select"></select>
                    </div>
                    <div class="mb-3">
                        <label for="stock-qty" class="form-label">Quantity Manufactured</label>
                        <input type="number" id="stock-qty" name="qty" class="form-control" step="0.01" required>
                    </div>
                    <div class="mb-3 d-none-important" id="stock-comment-row">
                        <label for="stock-comment" class="form-label">Comment <span class="text-danger">*</span></label>
                        <input type="text" id="stock-comment" name="comment" class="form-control" maxlength="250">
                    </div>
                </form>
                <div id="add-stock-feedback" class="alert d-none-important"></div>
            </div>
            <div class="modal-footer">
                <button type="submit" form="add-stock-form" class="btn btn-primary">Add Stock</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            </div>
        </div>
    </div>
</div>