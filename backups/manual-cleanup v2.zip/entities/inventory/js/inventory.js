// Inventory Management JS
// Refactored to delegate Add Stock modal behavior to /assets/js/add-stock-modal.js (window.AddStockModal)
// Removed all inline (now duplicated) logic for:
//  - openAddStockModal()
//  - TomSelect population for Add Stock
//  - Add Stock form submission
//  - Negative quantity comment field toggling
//
// This file now only wires page buttons to the unified modal API and keeps
// inventory listing + excess stock + inline manufactured update features.

$(document).ready(function () {

    /* -------------------------------------------------------------
     * Order selection (table checkboxes)
     * ----------------------------------------------------------- */
    if (typeof CommonUtils !== 'undefined') {
        CommonUtils.TableSelection.init(
            'body',
            '#select-all-orders',
            '.order-checkbox'
        );
    } else {
        $('#select-all-orders').on('change', function() {
            $('.order-checkbox').prop('checked', this.checked);
        });
        $(document).on('change', '.order-checkbox', function() {
            let allChecked = $('.order-checkbox').length === $('.order-checkbox:checked').length;
            $('#select-all-orders').prop('checked', allChecked);
        });
    }

    function getSelectedOrderIds() {
        if (typeof CommonUtils !== 'undefined') {
            return CommonUtils.TableSelection.getSelected('body', '.order-checkbox');
        }
        return $('.order-checkbox:checked').map(function(){ return $(this).val(); }).get();
    }

    function requireSelection(ids, msg) {
        if (!ids.length) {
            alert(msg);
            return false;
        }
        return true;
    }

    /* -------------------------------------------------------------
     * Stock Requirements (open in new tab)
     * ----------------------------------------------------------- */
    $('#btn-stock-req').on('click', function() {
        const orderIds = getSelectedOrderIds();
        if (!requireSelection(orderIds, 'Please select at least one order!')) return;
        window.open('stock_requirements.php?order_ids=' + orderIds.join(','), '_blank');
    });

    /* -------------------------------------------------------------
     * Packing related buttons
     * ----------------------------------------------------------- */
    $('#btn-packing-log').on('click', function() {
        const orderIds = getSelectedOrderIds();
        if (!requireSelection(orderIds, 'Please select at least one order!')) return;
        window.open('packing.php?order_ids=' + orderIds.join(','), '_blank');
    });

    $('#btn-packing-labels').on('click', function() {
        const orderIds = getSelectedOrderIds();
        if (!requireSelection(orderIds, 'Please select at least one order!')) return;
        window.open('packing_labels.php?order_ids=' + orderIds.join(','), '_blank');
    });

    /* -------------------------------------------------------------
     * Add Stock (Unified modal now handled by AddStockModal)
     * ----------------------------------------------------------- */
    $('#btn-add-stock').on('click', function(e) {
        e.preventDefault();
        if (window.AddStockModal && typeof window.AddStockModal.open === 'function') {
            window.AddStockModal.open();
        } else {
            console.warn('AddStockModal not available. Ensure /assets/js/add-stock-modal.js is loaded and markup is included.');
        }
    });

    /* -------------------------------------------------------------
     * Excess Stock Modal
     * ----------------------------------------------------------- */
    $('#btn-excess-stock').on('click', function() {
        if (window.UnifiedModals && typeof window.UnifiedModals.show === 'function') {
            window.UnifiedModals.show('excess-stock-modal');
        } else {
            const modalEl = document.getElementById('excess-stock-modal');
            if (modalEl) {
                const inst = new bootstrap.Modal(modalEl, {backdrop: 'static', keyboard: true});
                inst.show();
            }
        }

        $('#excess-stock-table-container').html('<div class="p-3 text-center">Loading...</div>');

        $.get('/entities/inventory/actions.php', {action: 'get_excess_stock'}, function(resp) {
            if(!resp.success) {
                $('#excess-stock-table-container').html('<div class="alert alert-danger">'+(resp.error||'Could not fetch excess stock.')+'</div>');
                return;
            }
            if(!resp.data.length) {
                $('#excess-stock-table-container').html('<div class="alert alert-warning">No items have excess stock!</div>');
                return;
            }

            let totalExcessValue = 0;
            let rowsHtml = resp.data.map(function(row) {
                const excessValue = parseFloat(row.excess_value || 0);
                totalExcessValue += excessValue;
                return `<tr>
                    <td>${escapeHtml(row.name)}</td>
                    <td>${escapeHtml(row.category || 'Uncategorized')}</td>
                    <td>${parseFloat(row.manufactured).toFixed(2)}</td>
                    <td>${parseFloat(row.required).toFixed(2)}</td>
                    <td><span class="badge badge-surplus">+${parseFloat(row.excess).toFixed(2)}</span></td>
                    <td>Rs. ${parseFloat(row.price_per_unit || 0).toFixed(2)}</td>
                    <td><strong>Rs. ${excessValue.toFixed(2)}</strong></td>
                </tr>`;
            }).join('');

            const table = `<table class="entity-table" id="excess-stock-table">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Category</th>
                        <th>Manufactured</th>
                        <th>Required</th>
                        <th>Excess</th>
                        <th>Price/Unit</th>
                        <th>Excess Value</th>
                    </tr>
                </thead>
                <tbody>${rowsHtml}</tbody>
                <tfoot>
                    <tr class="table-success">
                        <th colspan="6" class="text-end">Total Excess Stock Value:</th>
                        <th><strong>Rs. ${totalExcessValue.toFixed(2)}</strong></th>
                    </tr>
                </tfoot>
            </table>`;

            $('#excess-stock-table-container').html(table);

            if(window.jQuery && $.fn.DataTable) {
                $('#excess-stock-table').DataTable({
                    responsive: true,
                    paging: false,
                    searching: true,
                    info: false,
                    ordering: true
                });
            }
        }, 'json');
    });

    // Copy excess list button
    $(document).on('click', '#copy-excess-btn', function() {
        const rows = $('#excess-stock-table tbody tr');
        if (!rows.length) {
            alert('No excess items to copy!');
            return;
        }
        const lines = [];
        rows.each(function() {
            const item = $(this).find('td').eq(0).text().trim();
            const excess = $(this).find('td').eq(4).text().replace('+','').trim();
            if (item && excess) {
                lines.push(item + ': ' + excess);
            }
        });
        if (lines.length) {
            const textToCopy = lines.join('\n');
            navigator.clipboard.writeText(textToCopy).then(function() {
                alert('Copied to clipboard!\n\n' + textToCopy);
            }, function() {
                alert('Failed to copy!');
            });
        } else {
            alert('No excess items to copy!');
        }
    });

    /* -------------------------------------------------------------
     * Inline manufactured update (Stock Requirements page only)
     * ----------------------------------------------------------- */
    $(document).on('click', '.btn-update-stock', function() {
        const $tr = $(this).closest('tr');
        const item_id = $tr.find('.row-item-id').val();
        const qty = parseFloat($tr.find('.manufactured-input').val());

        if (!item_id || isNaN(qty) || qty <= 0) {
            alert('Please enter a positive quantity.');
            return;
        }

        $.post('actions.php', {action:'update_manufactured', item_id, qty}, function(resp) {
            if (resp.success) {
                setTimeout(function() { location.reload(); }, 400);
            } else {
                alert(resp.error || 'Update failed');
            }
        }, 'json');
    });

    /* -------------------------------------------------------------
     * Utility
     * ----------------------------------------------------------- */
    function escapeHtml(text) {
        return $('<div>').text(text).html();
    }
});