<?php
require_once '../../includes/auth_check.php';
require_once '../../includes/db_connection.php';
$pageTitle = "Stock Requirements";
require_once '../../includes/header.php';

$order_ids = [];
if (!empty($_REQUEST['order_ids'])) {
    $order_ids = array_filter(array_map('intval', explode(',', $_REQUEST['order_ids'])));
}
if (!$order_ids) {
    echo "<div class='alert alert-danger'>No orders selected!</div>";
    require_once '../../includes/footer.php';
    exit;
}

$in  = str_repeat('?,', count($order_ids) - 1) . '?';
$stmt = $pdo->prepare("SELECT oi.item_id, i.name, c.name AS category, SUM(oi.qty) as total_qty
    FROM order_items oi
    JOIN items i ON oi.item_id = i.id
    LEFT JOIN categories c ON i.category_id = c.id
    WHERE oi.order_id IN ($in)
    GROUP BY oi.item_id, i.name, c.name
    ORDER BY i.name");
$stmt->execute($order_ids);
$req_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

$item_ids = array_column($req_items, 'item_id');
$stocked = [];
if ($item_ids) {
    $in_items = str_repeat('?,', count($item_ids) - 1) . '?';
    $st2 = $pdo->prepare("
        SELECT item_id, SUM(qty) AS total_stock
        FROM inventory_ledger
        WHERE item_id IN ($in_items)
        GROUP BY item_id
    ");
    $st2->execute($item_ids);
    foreach ($st2->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $stocked[$row['item_id']] = (float)$row['total_stock'];
    }
}
?>
<div class="orders-content">
    <div class="container mt-3">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2 class="text-primary"><i class="fa fa-list-ul me-2"></i> Stock Requirements</h2>
            </div>
            <div class="col-md-4 text-end">
                <button class="btn btn-success btn-3d me-2" id="btn-excess-stock">
                    <i class="fa fa-chart-bar me-1"></i> Show Excess Stock
                </button>
                <button class="btn btn-primary btn-3d" id="btn-add-stock">
                    <i class="fa fa-plus me-1"></i> Add Stock
                </button>
            </div>
        </div>
        <div class="alert alert-info max-width-700 mb-4">
            <strong>Track item manufacturing requirements.</strong> Use <strong>Add Stock</strong> to record manufactured quantities.
        </div>
        <div class="table-responsive">
            <table class="entity-table table table-striped table-hover table-consistent" id="stock-req-table" data-table-id="stock-requirements">
                <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Item</th>
                    <th>Category</th>
                    <th>Total Required</th>
                    <th>Manufactured</th>
                    <th>Surplus/Shortfall</th>
                    <th>Add/Update</th>
                </tr>
                </thead>
                <tbody>
                <?php
                $serial = 1;
                foreach ($req_items as $it):
                    $manufactured = $stocked[$it['item_id']] ?? 0;
                    $diff = (float)$it['total_qty'] - $manufactured;
                    $badgeClass = $diff < 0 ? 'badge-surplus' : ($diff > 0 ? 'badge-outstanding' : 'badge-settled');
                    $badgePrefix = $diff < 0 ? '+' : ($diff > 0 ? '-' : '');
                ?>
                    <tr>
                        <td><?= $serial++ ?></td>
                        <td><?= htmlspecialchars($it['name']) ?></td>
                        <td><?= htmlspecialchars($it['category'] ?? 'Uncategorized') ?></td>
                        <td><?= number_format($it['total_qty'], 2) ?></td>
                        <td><span class="manufactured-val"><?= number_format($manufactured, 2) ?></span></td>
                        <td>
                            <span class="badge <?= $badgeClass ?>">
                                <?= $diff == 0 ? '0.00' : $badgePrefix . number_format(abs($diff), 2) ?>
                            </span>
                        </td>
                        <td>
                            <input type="number"
                                   class="form-control manufactured-input"
                                   min="0" step="0.01"
                                   max="<?= htmlspecialchars($it['total_qty']) ?>"
                                   style="width:90px;display:inline-block;"
                                   value="0">
                            <input type="hidden" class="row-item-id" value="<?= (int)$it['item_id'] ?>">
                            <button type="button" class="btn btn-primary btn-update-stock" title="Update">
                                <i class="fa fa-check-circle"></i>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php
if (!isset($GLOBALS['__ADD_STOCK_MODAL_INCLUDED__'])) {
    $GLOBALS['__ADD_STOCK_MODAL_INCLUDED__'] = true;
    include_once __DIR__ . '/add_stock_modal.php';
}
if (!isset($GLOBALS['__EXCESS_STOCK_MODAL_INCLUDED__'])) {
    $GLOBALS['__EXCESS_STOCK_MODAL_INCLUDED__'] = true;
    include_once __DIR__ . '/excess_stock_modal.php';
}
?>
<script src="/assets/js/add-stock-modal.js"></script>
<script src="/assets/js/excess-stock-modal.js"></script>
<script src="/entities/inventory/js/inventory.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    if (window.UnifiedTables && document.getElementById('stock-req-table')) {
        UnifiedTables.init('#stock-req-table', 'stock-requirements');
    }
});
</script>
<?php require_once '../../includes/footer.php'; ?>