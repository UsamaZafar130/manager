// Meals management JavaScript (uses UnifiedModals for all modal handling)
window.MealUI = (function() {
    'use strict';
    
    function openAddModal() {
        loadModalForm('add');
    }
    
    function openEditModal(mealId) {
        loadModalForm('edit', mealId);
    }
    
    function openDetails(mealId) {
        if (typeof CommonUtils !== 'undefined') {
            const formData = new FormData();
            formData.append('action', 'load_details');
            formData.append('meal_id', mealId);
            
            CommonUtils.request({
                url: 'actions.php',
                method: 'POST',
                body: formData,
                onSuccess: (response) => {
                    if (response.success) {
                        $('#meal-details-modal .modal-content').html(response.html);
                        window.UnifiedModals.show('meal-details-modal');
                    } else {
                        if (typeof CommonUtils.showError === 'function') {
                            CommonUtils.showError('Error loading meal details: ' + (response.message || 'Unknown error'));
                        } else {
                            alert('Error loading meal details: ' + (response.message || 'Unknown error'));
                        }
                    }
                }
            });
        } else {
            // Fallback to jQuery AJAX (still using UnifiedModals to show)
            $.ajax({
                url: 'actions.php',
                method: 'POST',
                data: {
                    action: 'load_details',
                    meal_id: mealId
                },
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        $('#meal-details-modal .modal-content').html(response.html);
                        window.UnifiedModals.show('meal-details-modal');
                    } else {
                        alert('Error loading meal details: ' + (response.message || 'Unknown error'));
                    }
                },
                error: function(xhr, status, err) {
                    alert('AJAX Error: ' + err + "\n" + xhr.responseText);
                }
            });
        }
    }
    
    function loadModalForm(type, mealId = null) {
        const data = {
            action: 'load_form',
            type: type
        };
        
        if (type === 'edit' && mealId) {
            data.meal_id = mealId;
        }
        
        $.ajax({
            url: 'actions.php',
            method: 'POST',
            data: data,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    $('#meal-modal .modal-content').html(response.html);
                    window.UnifiedModals.show('meal-modal');
                } else {
                    alert('Error loading form: ' + (response.message || 'Unknown error'));
                }
            },
            error: function(xhr, status, err) {
                alert('AJAX Error: ' + err + "\n" + xhr.responseText);
            }
        });
    }
    
    // Delete functionality
    function initDeleteHandlers() {
        $(document).on('click', '.meal-delete-btn', function(e) {
            e.stopPropagation();
            const mealId = $(this).data('meal-id');
            const mealName = $(this).data('meal-name');
            
            $('#meal-delete-name').text(mealName);
            window.UnifiedModals.show('meal-delete-confirm-modal');
            
            $('#meal-delete-confirm-btn').off('click').on('click', function() {
                deleteMeal(mealId, mealName);
            });
        });
    }
    
    function deleteMeal(mealId, mealName) {
        $.ajax({
            url: '/api/meals.php?action=delete',
            method: 'POST',
            data: { id: mealId },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    window.UnifiedModals.hide('meal-delete-confirm-modal');
                    alert('Meal "' + mealName + '" deleted successfully!');
                    location.reload();
                } else {
                    $('#meal-delete-modal-error').removeClass('d-none').text(response.message || 'Unknown error');
                }
            },
            error: function(xhr, status, err) {
                $('#meal-delete-modal-error').removeClass('d-none').text('AJAX Error: ' + err);
            }
        });
    }
    
    // Initialize on document ready
    $(document).ready(function() {
        initDeleteHandlers();
        
        // Hide error on modal close
        $('#meal-delete-confirm-modal').on('hide.bs.modal', function() {
            $('#meal-delete-modal-error').addClass('d-none');
        });
        
        // Row click handler for details (if not clicking action buttons)
        $(document).on('click', '#meals-table tbody tr', function(e) {
            if (!$(e.target).closest('.action-icons').length) {
                const mealId = $(this).data('meal-id');
                if (mealId) {
                    openDetails(mealId);
                }
            }
        });
    });
    
    // Public API
    return {
        openAddModal: openAddModal,
        openEditModal: openEditModal,
        openDetails: openDetails
    };
})();