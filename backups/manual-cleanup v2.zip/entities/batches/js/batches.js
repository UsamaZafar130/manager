$(function(){
    // --- Batch status fix on page load ---
    var batchId = $('#batch-orders-table').data('batch-id') || $('[data-batch-id]').first().data('batch-id');
    if (batchId) {
        $.get('batch_orders_api.php', {action: 'fix_batch_status', batch_id: batchId}, function(resp){
            if (resp && typeof resp.batch_status !== 'undefined') {
                let badge = $("#batch-status-badge");
                if (resp.batch_status == 0) {
                    badge.text("Pending").removeClass().addClass("badge-order-status badge-order-status-pending");
                } else if (resp.batch_status == 1) {
                    badge.text("In Process").removeClass().addClass("badge-order-status badge-order-status-inprocess");
                } else if (resp.batch_status == 2) {
                    badge.text("Delivered").removeClass().addClass("badge-order-status badge-order-status-delivered");
                }
            }
        }, 'json');
    }

    // --- Print Invoice for Selected Orders ---
    $(document).on('click', '#print-invoice-selected-btn', function(e){
        e.preventDefault();
        let ids = $('.batch-order-checkbox:checked').map(function(){ return $(this).val(); }).get();
        if (!ids.length) {
            if (typeof safeAlert === 'function') safeAlert('Please select at least one order to print invoice.');
            else alert('Please select at least one order to print invoice.');
            return;
        }
        window.open('/entities/sales/print_invoice.php?ids=' + encodeURIComponent(ids.join(',')), '_blank');
    });

    // --- Move Order Modal ---
    $(document).on('click', '.btn-unlink-order', function(e){
        e.preventDefault();
        var $btn = $(this);
        var orderId = $btn.data('order-id');
        var batchId = $btn.data('batch-id');
        $('#moveOrderModal').data('order-id', orderId).data('batch-id', batchId);
        $('#moveOrderModal .move-error').hide();
        loadMoveBatchDropdown();
        window.UnifiedModals.show('moveOrderModal');
    });

    $(document).on('click', '#refresh-batch-list', function(e){
        e.preventDefault();
        loadMoveBatchDropdown();
    });

    function loadMoveBatchDropdown() {
        var $dropdown = $('#move-batch-dropdown');
        $dropdown.prop('disabled', true).html('<option>Loading...</option>');
        $.get('list.php', {ajax: 1, eligible: 1}, function(data){
            if (Array.isArray(data)) {
                var opts = data.map(function(batch){
                    let statusStr = batch.status == 0 ? 'Pending' : batch.status == 1 ? 'In Process' : batch.status == 2 ? 'Delivered' : batch.status;
                    return `<option value="${batch.id}">#${batch.id} - ${batch.batch_name} (${statusStr})</option>`;
                });
                if (opts.length === 0) opts = ['<option disabled>No eligible batches found</option>'];
                $dropdown.html(opts.join(''));
            } else {
                $dropdown.html('<option disabled>Error loading batches</option>');
            }
            $dropdown.prop('disabled', false);
        }, 'json');
    }

    $(document).on('submit', '#move-order-form', function(e){
        e.preventDefault();
        var newBatchId = $('#move-batch-dropdown').val();
        var orderId = $('#moveOrderModal').data('order-id');
        var batchId = $('#moveOrderModal').data('batch-id');
        if (!newBatchId) {
            $('#moveOrderModal .move-error').text('Please select a batch!').show();
            return;
        }
        $.post('batch_orders_api.php', {action:'move_order', batch_id:batchId, order_id:orderId, new_batch_id:newBatchId}, function(resp){
            if(resp.status==='success') {
                window.UnifiedModals.hide('moveOrderModal');
                location.reload();
            } else {
                $('#moveOrderModal .move-error').text(resp.message || 'Failed to move order').show();
            }
        },'json');
    });

    $(document).on('click', '#create-new-batch-btn', function(){
        window.open('list.php', '_blank');
    });

    // --- Link Orders Modal ---
    $(document).on('click', '.btn-link-orders', function(){
        var batchId = $('#batch-orders-table').data('batch-id') || $('[data-batch-id]').first().data('batch-id');
        $('#linkOrdersModal').data('batch-id', batchId);
        $('#link-orders-form .link-error').hide();
        $('#link-orders-form .link-success').hide();
        $('#link-orders-select').prop('disabled', true).html('');
        $('#link-orders-select').parent().append('<div id="orders-loading-spinner" style="margin-top:8px;text-align:center;"><span class="fa fa-spinner fa-spin"></span> Loading...</div>');
        $.get('batch_orders_api.php', {action:'get_unbatched_orders', batch_id: batchId}, function(data){
            $('#orders-loading-spinner').remove();
            if (data && Array.isArray(data.orders)) {
                var opts = data.orders.map(function(o){
                    return `<option value="${o.id}">${o.formatted_order_number} - ${o.customer_name} (${o.grand_total})</option>`;
                });
                if (opts.length === 0) opts = ['<option disabled>No eligible orders found</option>'];
                $('#link-orders-select').html(opts.join(''));
            } else {
                $('#link-orders-select').html('<option disabled>Error loading orders</option>');
            }
            $('#link-orders-select').prop('disabled', false);

            if ($('#link-orders-select')[0].tomselect) {
                $('#link-orders-select')[0].tomselect.destroy();
            }
            new TomSelect('#link-orders-select', {
                plugins: ['remove_button'],
                maxItems: null,
                create: false,
                sortField: {field: "text", direction: "asc"},
                render: {
                    no_results: function(data, escape) {
                        return '<div class="no-orders-message" style="padding:8px;color:#c0392b;">No eligible orders found</div>';
                    }
                }
            });
        }, 'json');
        window.UnifiedModals.show('linkOrdersModal');
    });

    $(document).on('submit', '#link-orders-form', function(e){
        e.preventDefault();
        var orderIds = $('#link-orders-select').val() || [];
        var batchId = $('#linkOrdersModal').data('batch-id');
        if (!orderIds.length) {
            $('#link-orders-form .link-error').text('Please select at least one order!').show();
            return;
        }
        $.post('batch_orders_api.php', {action:'add_orders', batch_id:batchId, order_ids:orderIds}, function(resp){
            if(resp.status==='success') {
                $('#link-orders-form .link-error').hide();
                $('#link-orders-form .link-success').text('Orders linked successfully.').show();
                setTimeout(function() {
                    window.UnifiedModals.hide('linkOrdersModal');
                    location.reload();
                }, 900);
            } else {
                $('#link-orders-form .link-success').hide();
                $('#link-orders-form .link-error').text(resp.message || 'Failed to link orders').show();
            }
        },'json');
    });

    // --- Checkbox logic using CommonUtils ---
    if (typeof CommonUtils !== 'undefined') {
        CommonUtils.TableSelection.init(
            '#batch-orders-table', 
            '.batch-select-all-checkbox', 
            '.batch-order-checkbox'
        );
    } else {
        // Fallback to existing implementation
        $(document).on('change', '.batch-select-all-checkbox', function() {
            var checked = this.checked;
            $('.batch-order-checkbox').prop('checked', checked);
        });
        $(document).on('change', '.batch-order-checkbox', function() {
            var $all = $('.batch-order-checkbox');
            var $checked = $('.batch-order-checkbox:checked');
            $('.batch-select-all-checkbox').prop('checked', $all.length && $all.length === $checked.length);
        });
    }

    // --- Bulk Mark Delivered ---
    $(document).on('click', '#batch-bulk-delivered-btn', function() {
        let ids;
        if (typeof CommonUtils !== 'undefined') {
            ids = CommonUtils.TableSelection.getSelected('#batch-orders-table', '.batch-order-checkbox');
            if (!CommonUtils.TableSelection.requireSelection(ids, 'No orders selected.')) {
                return;
            }
        } else {
            ids = $('.batch-order-checkbox:checked').map(function(){ return $(this).val(); }).get();
            if (ids.length === 0) {
                alert('No orders selected.');
                return;
            }
        }
        
        if (!confirm('Mark selected orders as delivered?')) return;

        var batchId = $('#batch-orders-table').data('batch-id') || $('[data-batch-id]').first().data('batch-id');
        
        if (typeof CommonUtils !== 'undefined') {
            CommonUtils.request({
                url: '/entities/sales/mark_delivered.php',
                method: 'POST',
                body: new URLSearchParams({order_ids: ids, source: 'batch-page'}),
                onSuccess: (resp) => {
                    if (resp.success) {
                        CommonUtils.showSuccess('Orders marked as delivered');
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        CommonUtils.showError('Some orders failed. Please check and try again.');
                        setTimeout(() => location.reload(), 2000);
                    }
                }
            });
        } else {
            $.post('/entities/sales/mark_delivered.php', {order_ids: ids, source: 'batch-page'}, function(resp){
                if(resp.success){
                    location.reload();
                } else {
                    alert('Some orders failed. Please check and try again.');
                    location.reload();
                }
            },'json');
        }
    });

    // --- Bulk Mark Payment (exclude fully paid orders) ---
    $(document).on('click', '#batch-bulk-paid-btn', function() {
        let $checked = $('.batch-order-checkbox:checked');
        if (!$checked.length) {
            if (typeof CommonUtils !== 'undefined') {
                CommonUtils.showError('No orders selected.');
            } else {
                alert('No orders selected.');
            }
            return;
        }

        // Filter out fully paid (data-paid="1")
        let paidExcluded = [];
        let payableIds = [];

        $checked.each(function(){
            const paidFlag = parseInt($(this).data('paid'), 10);
            const oid = $(this).val();
            if (paidFlag === 1) {
                paidExcluded.push(oid);
            } else {
                payableIds.push(oid);
            }
        });

        if (!payableIds.length) {
            if (typeof CommonUtils !== 'undefined') {
                CommonUtils.showError('All selected orders are already fully paid.');
            } else {
                alert('All selected orders are already fully paid.');
            }
            return;
        }

        // Load bulk payment form into modal and show
        const params = new URLSearchParams();
        payableIds.forEach(id => params.append('order_ids[]', id));
        window.UnifiedModals.loadAndShow('payment-modal', '/entities/sales/mark_payment.php?' + params.toString());
    });

    // Bulk Payment Form Submit Handler (delegated)
    $(document).on('submit', '#bulk-payment-form', function(e){
        e.preventDefault();
        var $form = $(this);
        $.post('/entities/sales/mark_payment.php', $form.serialize(), function(resp){
            if(resp.success) {
                location.reload();
            } else {
                alert(resp.message || 'Failed to mark payments.');
            }
        }, 'json');
    });

    // --- Single Mark Payment (only shown for unpaid / partial) ---
    $(document).on('click', '.batch-mark-paid-btn', function() {
        var orderId = $(this).data('order-id');
        if (!orderId) {
            alert('Order ID not found!');
            return;
        }
        window.UnifiedModals.loadAndShow('payment-modal', '/entities/sales/mark_payment.php?id=' + encodeURIComponent(orderId));
    });

    // --- Show Batch Summary Modal ---
    $(document).on('click', '.btn-show-summary', function() {
        var batchId = $('#batch-orders-table').data('batch-id');
        $.get('/entities/batches/batch_summary.php', {batch_id: batchId}, function(html) {
            $('#summary-modal-body').html(html);
            window.UnifiedModals.show('summary-modal');
        });
    });

    // --- Single Mark Delivered ---
    $(document).on('click', '.batch-mark-delivered-btn', function() {
        var orderId = $(this).data('order-id');
        var batchId = $('#batch-orders-table').data('batch-id') || $('[data-batch-id]').first().data('batch-id');
        if (!confirm('Mark this order as delivered?')) return;
        $.post('/entities/sales/mark_delivered.php', {order_ids: [orderId], source: 'batch-page'}, function(resp){
            if(resp.success){
                location.reload();
            } else {
                alert('Failed to mark order as delivered: ' + (resp.results && resp.results[0] && resp.results[0].message ? resp.results[0].message : 'Unknown error.'));
                location.reload();
            }
        },'json');
    });

    // Payment/summary modal close logic for custom cancel buttons
    $(document).on('click', '#pod-cancel, #bulk-pay-cancel', function(){
        window.UnifiedModals.hide('payment-modal');
    });
    $(document).on('click', '#summary-modal .btn-close', function() {
        window.UnifiedModals.hide('summary-modal');
    });
});