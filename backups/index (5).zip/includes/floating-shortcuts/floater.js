/**
 * Floating Action Button JavaScript
 * Handles inventory shortcuts menu functionality globally across all pages
 */

// Global keyboard shortcuts for floating actions - works on all pages
$(document).on('keydown', function(e) {
    // Check if we're in the order modal - if so, handle order-specific shortcuts
    if ($('#orderModal').hasClass('show') || $('#orderModal').is(':visible')) {
        // Order Modal Shortcuts
        
        // Ctrl+Alt+C - Focus customer dropdown
        if (e.ctrlKey && e.altKey && e.key === 'c') {
            e.preventDefault();
            const customerSelect = $('#customer-select');
            if (customerSelect.length && customerSelect[0].tomselect) {
                customerSelect[0].tomselect.focus();
            }
            return;
        }
        
        // Ctrl+Alt+I - Focus empty items dropdown or add new item row
        if (e.ctrlKey && e.altKey && e.key === 'i') {
            e.preventDefault();
            const emptyItemSelect = $('#items-table tbody tr').find('.item-select').filter(function() {
                return !$(this).val();
            }).first();
            
            if (emptyItemSelect.length && emptyItemSelect[0].tomselect) {
                emptyItemSelect[0].tomselect.focus();
            } else {
                // No empty item dropdown found, add a new row
                $('#add-row').trigger('click');
            }
            return;
        }
        
        // Ctrl+Alt+M - Focus empty meals dropdown or add new meal row
        if (e.ctrlKey && e.altKey && e.key === 'm') {
            e.preventDefault();
            const emptyMealSelect = $('#meals-table tbody tr').find('.meal-select').filter(function() {
                return !$(this).val();
            }).first();
            
            if (emptyMealSelect.length && emptyMealSelect[0].tomselect) {
                emptyMealSelect[0].tomselect.focus();
            } else {
                // No empty meal dropdown found, add a new row
                $('#add-meal-row').trigger('click');
            }
            return;
        }
        
        // Ctrl+Alt+1,2,3... - Focus specific item rows
        if (e.ctrlKey && e.altKey && /^[1-9]$/.test(e.key)) {
            e.preventDefault();
            const rowIndex = parseInt(e.key) - 1;
            const itemRows = $('#items-table tbody tr');
            if (rowIndex < itemRows.length) {
                const targetRow = itemRows.eq(rowIndex);
                const itemSelect = targetRow.find('.item-select');
                if (itemSelect.length && itemSelect[0].tomselect) {
                    itemSelect[0].tomselect.focus();
                }
            }
            return;
        }
        
        // Ctrl+Alt+Shift+1,2,3... - Focus specific meal rows
        if (e.ctrlKey && e.altKey && e.shiftKey && /^[1-9]$/.test(e.key)) {
            e.preventDefault();
            const rowIndex = parseInt(e.key) - 1;
            const mealRows = $('#meals-table tbody tr');
            if (rowIndex < mealRows.length) {
                const targetRow = mealRows.eq(rowIndex);
                const mealSelect = targetRow.find('.meal-select');
                if (mealSelect.length && mealSelect[0].tomselect) {
                    mealSelect[0].tomselect.focus();
                }
            }
            return;
        }
        
        // If we handled a modal shortcut, don't process global shortcuts
        return;
    }
    
    // Global floating menu shortcuts (only when not in order modal)
    
    // Ctrl+Alt+F - Toggle floating shortcuts menu
    if (e.ctrlKey && e.altKey && e.key === 'f') {
        e.preventDefault();
        if ($('#floating-inventory-btn').length) {
            $('#floating-inventory-btn').trigger('click');
        }
        return;
    }
    
    // Ctrl+Alt+1 through Ctrl+Alt+9 - Trigger specific floating actions
    if (e.ctrlKey && e.altKey && ['1', '2', '3', '4', '5', '6', '7', '8', '9'].includes(e.key)) {
        e.preventDefault();
        
        // Map keyboard shortcuts to floating action buttons (all 9 in menu order)
        const actionMap = {
            '1': '#show-stock-required',    // Show Stock Required
            '2': '#show-excess-stock',      // Show Excess Stock  
            '3': '#show-add-stock',         // Add Stock
            '4': '#show-add-order',         // Add New Order
            '5': '#show-scan-packs',        // Scan Packs
            '6': '#show-add-customer',      // Add Customer
            '7': '#show-add-purchase',      // Add Purchase
            '8': '#show-add-expense',       // Add Expense
            '9': '#show-current-batch'      // Current Batch
        };
        
        const targetButton = actionMap[e.key];
        if (targetButton && $(targetButton).length) {
            // Hide the floating menu if it's visible
            const actionsMenu = $('#floating-inventory-actions');
            if (actionsMenu.is(':visible')) {
                actionsMenu.hide();
            }
            // Trigger the corresponding action
            $(targetButton).trigger('click');
        }
        return;
    }
});

$(function(){
    // Only initialize if floating button exists on the page
    if ($('#floating-inventory-btn').length === 0) {
        return;
    }

    // Floating Actions Menu
    let actionsVisible = false;
    $('#floating-inventory-btn').on('click', function(e){
        e.preventDefault();
        if (actionsVisible) {
            $('#floating-inventory-actions').hide();
            actionsVisible = false;
        } else {
            $('#floating-inventory-actions').show();
            actionsVisible = true;
        }
    });
    
    // Hide actions if clicked elsewhere
    $(document).on('mousedown touchstart', function(e){
        if (!$(e.target).closest('#floating-inventory-btn, #floating-inventory-actions').length) {
            $('#floating-inventory-actions').hide();
            actionsVisible = false;
        }
    });

    // Show Stock Required (glimpse) - using Bootstrap modal
    $('#show-stock-required, #view-stock-requirements').on('click', function(){
        $('#floating-inventory-actions').hide();
        actionsVisible = false;

        // Check if we're on a page that already has stock requirements functionality
        if (window.location.pathname.includes('stock_requirements.php')) {
            // If already on stock requirements page, just scroll to top or refresh
            window.scrollTo(0, 0);
            return;
        }

        // Use Bootstrap modal API for the floating stock requirements modal
        const modal = new bootstrap.Modal(document.getElementById('floating-inventory-modal'), {
            backdrop: 'static',
            keyboard: true
        });
        modal.show();
        
        $('#floating-inventory-modal-body').html(
            '<div class="text-center p-4">' +
            '<i class="fa fa-spinner fa-spin me-2"></i>' +
            'Loading stock requirements...</div>'
        );
        // Use the new glimpse API endpoint for a summary
        $.get('/entities/batches/api_upcoming_batch_stock_glimpse.php', function(html){
            $('#floating-inventory-modal-body').html(html);
        });
    });

    // Show Excess Stock (Bootstrap modal)
    $('#show-excess-stock').on('click', function(){
        $('#floating-inventory-actions').hide();
        actionsVisible = false;

        // Check if the excess-stock-modal already exists on the page (from stock_requirements.php)
        let modalElement = document.getElementById('excess-stock-modal');
        
        if (modalElement) {
            // Use existing modal from the page
            const modal = new bootstrap.Modal(modalElement, {
                backdrop: 'static',
                keyboard: true
            });
            modal.show();
            
            // Trigger the same functionality as the page's button
            $('#btn-excess-stock').trigger('click');
        } else {
            // Use the floating modal (when not on stock_requirements.php page)
            const modal = new bootstrap.Modal(document.getElementById('excess-stock-modal'));
            modal.show();
            
            $('#excess-stock-table-container').html('<div class="text-center p-4">Loading...</div>');
            $.get('/entities/inventory/actions.php', {action: 'get_excess_stock'}, function(resp) {
                if(!resp.success) {
                    $('#excess-stock-table-container').html('<div class="alert alert-danger">'+(resp.error||'Could not fetch excess stock.')+'</div>');
                    return;
                }
                if(!resp.data.length) {
                    $('#excess-stock-table-container').html('<div class="alert alert-warning">No items have excess stock!</div>');
                    return;
                }
                // Build table
                let table = `<table class="table table-striped" id="excess-stock-table">
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Category</th>
                            <th>Manufactured</th>
                            <th>Required</th>
                            <th>Excess</th>
                        </tr>
                    </thead>
                    <tbody>`;
                resp.data.forEach(function(row){
                    table += `<tr>
                        <td>${escapeHtml(row.name)}</td>
                        <td>${escapeHtml(row.category || 'Uncategorized')}</td>
                        <td>${row.manufactured}</td>
                        <td>${row.required}</td>
                        <td><span class="badge bg-warning">+${row.excess}</span></td>
                    </tr>`;
                });
                table += '</tbody></table>';
                $('#excess-stock-table-container').html(table);
            }, 'json');
        }
    });

    // Copy excess list to clipboard for WhatsApp (modal)
    $(document).on('click', '#copy-excess-btn', function() {
        let rows = $('#excess-stock-table tbody tr');
        if (!rows.length) {
            alert('No excess items to copy!');
            return;
        }
        let lines = [];
        rows.each(function() {
            let item = $(this).find('td').eq(0).text().trim();
            let excess = $(this).find('td').eq(4).text().replace('+','').trim();
            if (item && excess) {
                lines.push(item + ': ' + excess);
            }
        });
        if (lines.length) {
            const textToCopy = lines.join('\n');
            navigator.clipboard.writeText(textToCopy).then(function() {
                alert('Copied to clipboard!\n\n' + textToCopy);
            }, function() {
                alert('Failed to copy!');
            });
        } else {
            alert('No excess items to copy!');
        }
    });

    // Show Add Stock Modal (Bootstrap modal)
    $('#show-add-stock').on('click', function(){
        $('#floating-inventory-actions').hide();
        actionsVisible = false;

        // Check if the add-stock-modal already exists on the page (from stock_requirements.php)
        let modalElement = document.getElementById('add-stock-modal');
        
        if (modalElement) {
            // Use existing modal from the page - trigger the page's button to ensure consistency
            $('#btn-add-stock').trigger('click');
        } else {
            // Use the floating modal (when not on stock_requirements.php page)
            modalElement = document.getElementById('floating-add-stock-modal');
            const modal = new bootstrap.Modal(modalElement, {
                backdrop: 'static',
                keyboard: true
            });
            modal.show();
            
            // Initialize the form when modal opens
            openFloatingAddStockModal();
        }
    });

    // Initialize TomSelect for floating Add Stock modal when opened
    function openFloatingAddStockModal() {
        let $sel = $('#floating-stock-item-select');

        // Destroy old TomSelect instance if exists (important for modal reuse)
        if ($sel[0].tomselect) {
            $sel[0].tomselect.destroy();
        }

        // Clear and show Loading...
        $sel.empty().append('<option value="">Loading...</option>');

        // Fetch items from the server
        $.getJSON('/entities/items/items_list.php', function(items) {
            $sel.empty().append('<option value="">Select Item</option>');
            items.forEach(function(it) {
                $sel.append('<option value="'+it.id+'">'+it.name+'</option>');
            });

            // Initialize TomSelect
            if (typeof TomSelect !== "undefined") {
                new TomSelect($sel[0], {
                    create: false,
                    sortField: 'text'
                });
            } else {
                console.warn("TomSelect not loaded!");
            }
        });
    }

    // Show/hide comment field for negative stock in floating modal
    $(document).on('input change', '#floating-stock-qty', function() {
        let qty = parseFloat($(this).val());
        if (!isNaN(qty) && qty < 0) {
            $('#floating-stock-comment-row').show();
            $('#floating-stock-comment').attr('required', true);
        } else {
            $('#floating-stock-comment-row').hide();
            $('#floating-stock-comment').removeAttr('required');
        }
    });

    // Handle floating Add Stock form submit
    $(document).on('submit', '#floating-add-stock-form', function(e) {
        e.preventDefault();
        let item_id = $('#floating-stock-item-select').val();
        let qty = $('#floating-stock-qty').val();
        let comment = $('#floating-stock-comment').val();
        
        if (!item_id || qty === "" || isNaN(qty) || parseFloat(qty) === 0) {
            $('#floating-add-stock-feedback').addClass('alert-danger').removeClass('alert-success').text('Please select an item and enter a non-zero quantity.').show();
            return;
        }
        if (parseFloat(qty) < 0 && (!comment || comment.trim() === "")) {
            $('#floating-add-stock-feedback').addClass('alert-danger').removeClass('alert-success').text('Please enter a comment for negative stock (reconciliation).').show();
            return;
        }
        
        $.post('/entities/inventory/actions.php', {action:'add_stock', item_id, qty, comment}, function(resp) {
            if (resp.success) {
                $('#floating-add-stock-feedback').removeClass('alert-danger').addClass('alert-success').text('Stock added successfully!').show();
                setTimeout(()=>{ 
                    const modalElement = document.getElementById('floating-add-stock-modal');
                    if (modalElement) {
                        const modal = bootstrap.Modal.getInstance(modalElement);
                        if (modal) {
                            modal.hide();
                        }
                    }
                    // Reset form
                    $('#floating-add-stock-form')[0].reset();
                    $('#floating-stock-comment-row').hide();
                    $('#floating-add-stock-feedback').hide();
                }, 1000);
            } else {
                $('#floating-add-stock-feedback').addClass('alert-danger').removeClass('alert-success').text(resp.error || 'Error adding stock!').show();
            }
        }, 'json');
    });

    // Add New Order floating action button - show modal on current page
    $('#show-add-order').on('click', function(e){
        e.preventDefault();
        $('#floating-inventory-actions').hide();
        actionsVisible = false;
        
        // Check if showOrderModal function exists (from order_modal.php)
        if (typeof window.showOrderModal === 'function') {
            showOrderModal();
        } else {
            // Fallback: redirect to new order page
            window.location.href = '/entities/sales/new_order.php';
        }
    });

    // Add Customer Modal shortcut
    $('#show-add-customer').on('click', function(e){
        e.preventDefault();
        $('#floating-inventory-actions').hide();
        actionsVisible = false;
        
        // Check if showCustomerModal function exists (from customer_modal.php)
        if (typeof window.showCustomerModal === 'function') {
            showCustomerModal();
        } else {
            // Fallback: redirect to customers page
            window.location.href = '/entities/customers/list.php';
        }
    });

    // Add Purchase Modal shortcut
    $('#show-add-purchase').on('click', function(e){
        e.preventDefault();
        $('#floating-inventory-actions').hide();
        actionsVisible = false;
        
        // Check if showPurchaseModal function exists (from purchase_modal.php)
        if (typeof window.showPurchaseModal === 'function') {
            // Ensure any existing purchase modals are properly handled before showing new one
            const existingModal = document.querySelector('.modal.show');
            if (existingModal) {
                const bsModal = bootstrap.Modal.getInstance(existingModal);
                if (bsModal) {
                    bsModal.hide();
                }
            }
            showPurchaseModal();
        } else {
            // Fallback: redirect to purchases page
            window.location.href = '/entities/purchases/list.php';
        }
    });

    // Add Expense Modal shortcut
    $('#show-add-expense').on('click', function(e){
        e.preventDefault();
        $('#floating-inventory-actions').hide();
        actionsVisible = false;
        
        // Check if showExpenseModal function exists (from expense_modal.php)
        if (typeof window.showExpenseModal === 'function') {
            // Ensure any existing expense modals are properly handled before showing new one
            const existingModal = document.querySelector('.modal.show');
            if (existingModal) {
                const bsModal = bootstrap.Modal.getInstance(existingModal);
                if (bsModal) {
                    bsModal.hide();
                }
            }
            showExpenseModal();
        } else {
            // Fallback: redirect to expenses page
            window.location.href = '/entities/expenses/list.php';
        }
    });

    // Current Batch shortcut - opens current batch page
    $('#show-current-batch').on('click', function(e){
        e.preventDefault();
        $('#floating-inventory-actions').hide();
        actionsVisible = false;
        
        // Get current batch ID using the same logic as index.php
        $.ajax({
            url: '/api/get_current_batch.php',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.success && response.batch_id) {
                    // Open current batch page in new tab
                    window.open('/entities/batches/batch.php?id=' + response.batch_id, '_blank');
                } else {
                    // Fallback: open batches list page
                    window.open('/entities/batches/list.php', '_blank');
                }
            },
            error: function() {
                // Fallback: open batches list page
                window.open('/entities/batches/list.php', '_blank');
            }
        });
    });

    // Utility to escape HTML in JS
    function escapeHtml(text) {
        return $('<div>').text(text).html();
    }
});