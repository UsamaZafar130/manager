<?php
// Reusable Purchase Modal Component
// This can be included in any page that needs the Add Purchase modal functionality
?>

<!-- Purchase Modal (add/edit purchase) -->
<div class="modal fade" id="globalPurchaseModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="globalPurchaseModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="globalPurchaseModalLabel">New Purchase</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="global-purchase-modal-body">
                <div class="text-center p-4">Loading form...</div>
            </div>
        </div>
    </div>
</div>

<script>
// Global function to show the purchase modal (reusable across pages)
// Only define if not already defined (to avoid conflicts)
if (typeof window.showPurchaseModal === 'undefined') {
    window.showPurchaseModal = function(purchaseId = null) {
        const modal = document.getElementById('globalPurchaseModal');
        const modalTitle = document.getElementById('globalPurchaseModalLabel');
        const modalBody = document.getElementById('global-purchase-modal-body');
        
        if (!modal || !modalTitle || !modalBody) {
            console.error('Purchase modal elements not found');
            return;
        }
        
        modalTitle.textContent = purchaseId ? 'Edit Purchase' : 'New Purchase';
        modalBody.innerHTML = '<div class="text-center p-4">Loading form...</div>';
        
        let url = '/entities/purchases/form.php';
        if(purchaseId) url += '?id=' + encodeURIComponent(purchaseId);

        // Use UnifiedModals for consistent behavior
        if (typeof window.UnifiedModals !== 'undefined') {
            window.UnifiedModals.loadAndShow('globalPurchaseModal', url, {
                onLoaded: function(modal, bsModal) {
                    // Setup form handlers if needed
                    if(typeof window.initPurchaseFormJS === 'function') {
                        window.initPurchaseFormJS(purchaseId ? { purchase_id: parseInt(purchaseId) } : null);
                    }
                }
            });
        } else {
            // Fallback implementation using fetch API
            fetch(url)
                .then(response => response.text())
                .then(html => {
                    modalBody.innerHTML = html;
                    
                    // Show modal using Bootstrap 5 API
                    const bootstrapModal = new bootstrap.Modal(modal, {
                        backdrop: 'static',
                        keyboard: true
                    });
                    bootstrapModal.show();
                    
                    // Setup form handlers if needed
                    if(typeof window.initPurchaseFormJS === 'function') {
                        window.initPurchaseFormJS(purchaseId ? { purchase_id: parseInt(purchaseId) } : null);
                    }
                })
                .catch(error => {
                    console.error('Error loading purchase form:', error);
                    modalBody.innerHTML = '<div class="alert alert-danger">Failed to load purchase form. Please try again.</div>';
                    
                    if (typeof showError === 'function') {
                        showError('Failed to load purchase form');
                    }
                });
        }
    };
}
</script>