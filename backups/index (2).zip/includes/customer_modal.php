<?php
// Reusable Customer Modal Component
// This can be included in any page that needs the Add Customer modal functionality
?>

<!-- Customer Modal (add/edit customer) -->
<div class="modal fade" id="globalCustomerModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="globalCustomerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="globalCustomerModalLabel">New Customer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="global-customer-modal-body">
                <div class="text-center p-4">Loading form...</div>
            </div>
        </div>
    </div>
</div>

<script>
// Global function to show the customer modal (reusable across pages)
// Only define if not already defined (to avoid conflicts)
if (typeof window.showCustomerModal === 'undefined') {
    window.showCustomerModal = function(customerId = null) {
        const modal = document.getElementById('globalCustomerModal');
        const modalTitle = document.getElementById('globalCustomerModalLabel');
        const modalBody = document.getElementById('global-customer-modal-body');
        
        if (!modal || !modalTitle || !modalBody) {
            console.error('Customer modal elements not found');
            return;
        }
        
        modalTitle.textContent = customerId ? 'Edit Customer' : 'New Customer';
        modalBody.innerHTML = '<div class="text-center p-4">Loading form...</div>';
        
        let url = '/entities/customers/form.php';
        if(customerId) url += '?id=' + encodeURIComponent(customerId);

        // Use UnifiedModals for consistent behavior
        if (typeof window.UnifiedModals !== 'undefined') {
            window.UnifiedModals.loadAndShow('globalCustomerModal', url, {
                onLoaded: function(modal, bsModal) {
                    // Setup form handlers if needed
                    if(typeof window.initCustomerFormJS === 'function') {
                        window.initCustomerFormJS(customerId ? { customer_id: parseInt(customerId) } : null);
                    }
                }
            });
        } else {
            // Fallback implementation using fetch API
            fetch(url)
                .then(response => response.text())
                .then(html => {
                    modalBody.innerHTML = html;
                    
                    // Show modal using Bootstrap 5 API
                    const bootstrapModal = new bootstrap.Modal(modal, {
                        backdrop: 'static',
                        keyboard: true
                    });
                    bootstrapModal.show();
                    
                    // Setup form handlers if needed
                    if(typeof window.initCustomerFormJS === 'function') {
                        window.initCustomerFormJS(customerId ? { customer_id: parseInt(customerId) } : null);
                    }
                })
                .catch(error => {
                    console.error('Error loading customer form:', error);
                    modalBody.innerHTML = '<div class="alert alert-danger">Failed to load customer form. Please try again.</div>';
                    
                    if (typeof showError === 'function') {
                        showError('Failed to load customer form');
                    }
                });
        }
    };
}
</script>