<?php
// Reusable Expense Modal Component
// This can be included in any page that needs the Add Expense modal functionality
?>

<!-- Expense Modal (add/edit expense) -->
<div class="modal fade" id="globalExpenseModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="true" aria-labelledby="globalExpenseModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="globalExpenseModalLabel">New Expense</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="global-expense-modal-body">
                <div class="text-center p-4">Loading form...</div>
            </div>
        </div>
    </div>
</div>

<script>
// Global function to show the expense modal (reusable across pages)
// Only define if not already defined (to avoid conflicts)
if (typeof window.showExpenseModal === 'undefined') {
    window.showExpenseModal = function(expenseId = null) {
        const modal = document.getElementById('globalExpenseModal');
        const modalTitle = document.getElementById('globalExpenseModalLabel');
        const modalBody = document.getElementById('global-expense-modal-body');
        
        if (!modal || !modalTitle || !modalBody) {
            console.error('Expense modal elements not found');
            return;
        }
        
        modalTitle.textContent = expenseId ? 'Edit Expense' : 'New Expense';
        modalBody.innerHTML = '<div class="text-center p-4">Loading form...</div>';
        
        let url = '/entities/expenses/form.php';
        if(expenseId) url += '?id=' + encodeURIComponent(expenseId);

        // Use UnifiedModals for consistent behavior
        if (typeof window.UnifiedModals !== 'undefined') {
            window.UnifiedModals.loadAndShow('globalExpenseModal', url, {
                onLoaded: function(modal, bsModal) {
                    // Setup form handlers if needed
                    if(typeof window.initExpenseFormJS === 'function') {
                        window.initExpenseFormJS(expenseId ? { expense_id: parseInt(expenseId) } : null);
                    }
                }
            });
        } else {
            // Fallback implementation using fetch API
            fetch(url)
                .then(response => response.text())
                .then(html => {
                    modalBody.innerHTML = html;
                    
                    // Show modal using Bootstrap 5 API
                    const bootstrapModal = new bootstrap.Modal(modal, {
                        backdrop: 'static',
                        keyboard: true
                    });
                    bootstrapModal.show();
                    
                    // Setup form handlers if needed
                    if(typeof window.initExpenseFormJS === 'function') {
                        window.initExpenseFormJS(expenseId ? { expense_id: parseInt(expenseId) } : null);
                    }
                })
                .catch(error => {
                    console.error('Error loading expense form:', error);
                    modalBody.innerHTML = '<div class="alert alert-danger">Failed to load expense form. Please try again.</div>';
                    
                    if (typeof showError === 'function') {
                        showError('Failed to load expense form');
                    }
                });
        }
    };
}
</script>